import React, { useState, useEffect } from "react";
import {
  Wallet,
  TrendingUp,
  Shield,
  Zap,
  Users,
  BarChart3,
  ArrowRight,
  Menu,
  X,
  ChevronDown,
  Bitcoin,
  Coins,
  CreditCard,
  Lock,
  Eye,
  EyeOff,
  User,
  Mail,
  Phone,
  Building,
  Star,
  CheckCircle,
  Smartphone,
  Globe,
  DollarSign,
  Activity,
  Layers,
} from "lucide-react";
import logo from "./assets/imgages/payglobal-logo.png";
import Footer from "./components/Footer/Footer";
import { Link } from "react-router-dom";
import img6 from "./assets/imgages/img6.png";
import { motion } from "framer-motion";
// Main App Component with Routing
const CryptoExchangeApp = () => {
  const [currentPage, setCurrentPage] = useState("home");
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const renderPage = () => {
    switch (currentPage) {
      default:
        return (
          <LandingPage
            setCurrentPage={setCurrentPage}
            isMenuOpen={isMenuOpen}
            setIsMenuOpen={setIsMenuOpen}
          />
        );
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {renderPage()}
    </div>
  );
};

// Floating Animation Component
const FloatingElement = ({ children, delay = 0, duration = 3 }) => {
  return (
    <div
      className="animate-bounce"
      style={{
        animationDelay: `${delay}s`,
        animationDuration: `${duration}s`,
      }}
    >
      {children}
    </div>
  );
};

// Crypto Icons Component
const CryptoIcon = ({ name, symbol, color, size = "w-12 h-12" }) => {
  const icons = {
    bitcoin: Bitcoin,
    ethereum: Coins,
    wallet: Wallet,
    chart: BarChart3,
    shield: Shield,
    zap: Zap,
  };
  const Icon = icons[name] || Bitcoin;

  return (
    <div
      className={`${size} ${color} rounded-full flex items-center justify-center shadow-lg backdrop-blur-sm border border-white/20`}
    >
      <Icon className="w-6 h-6 text-white" />
    </div>
  );
};

// Landing Page Component
const LandingPage = ({ setCurrentPage, isMenuOpen, setIsMenuOpen }) => {
  const [scrollY, setScrollY] = useState(0);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener("scroll", handleScroll);
    setIsVisible(true);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Animated Background Elements */}
      <div className="fixed inset-0 z-0">
        <div className="absolute top-20 left-10 opacity-20">
          <FloatingElement delay={0}>
            <CryptoIcon
              name="bitcoin"
              color="bg-gradient-to-r from-yellow-400 to-orange-500"
            />
          </FloatingElement>
        </div>
        <div className="absolute top-40 right-20 opacity-20">
          <FloatingElement delay={1}>
            <CryptoIcon
              name="ethereum"
              color="bg-gradient-to-r from-blue-400 to-purple-500"
            />
          </FloatingElement>
        </div>
        <div className="absolute bottom-40 left-20 opacity-20">
          <FloatingElement delay={2}>
            <CryptoIcon
              name="wallet"
              color="bg-gradient-to-r from-green-400 to-blue-500"
            />
          </FloatingElement>
        </div>
        <div className="absolute top-60 left-1/3 opacity-20">
          <FloatingElement delay={0.5}>
            <CryptoIcon
              name="chart"
              color="bg-gradient-to-r from-pink-400 to-red-500"
            />
          </FloatingElement>
        </div>
        <div className="absolute inset-0 pointer-events-none">
          <svg className="w-full h-full opacity-20">
            {/* Animated Lines */}
            <g className="animate-pulse">
              <line
                x1="10%"
                y1="20%"
                x2="30%"
                y2="40%"
                stroke="url(#gradient1)"
                strokeWidth="2"
                className="animate-draw"
              />
              <line
                x1="30%"
                y1="40%"
                x2="50%"
                y2="20%"
                stroke="url(#gradient1)"
                strokeWidth="2"
                className="animate-draw-delay-1"
              />
              <line
                x1="50%"
                y1="20%"
                x2="70%"
                y2="60%"
                stroke="url(#gradient1)"
                strokeWidth="2"
                className="animate-draw-delay-2"
              />
              <line
                x1="70%"
                y1="60%"
                x2="90%"
                y2="30%"
                stroke="url(#gradient1)"
                strokeWidth="2"
                className="animate-draw-delay-3"
              />
            </g>

            {/* Network Nodes */}
            <circle
              cx="10%"
              cy="20%"
              r="4"
              fill="#3B82F6"
              className="animate-ping-slow"
            >
              <animate
                attributeName="fill"
                values="#3B82F6;#06B6D4;#3B82F6"
                dur="2s"
                repeatCount="indefinite"
              />
            </circle>
            <circle
              cx="30%"
              cy="40%"
              r="4"
              fill="#06B6D4"
              className="animate-ping-slow animation-delay-500"
            >
              <animate
                attributeName="fill"
                values="#06B6D4;#3B82F6;#06B6D4"
                dur="2s"
                repeatCount="indefinite"
              />
            </circle>
            <circle
              cx="50%"
              cy="20%"
              r="4"
              fill="#3B82F6"
              className="animate-ping-slow animation-delay-1000"
            >
              <animate
                attributeName="fill"
                values="#3B82F6;#06B6D4;#3B82F6"
                dur="2s"
                repeatCount="indefinite"
              />
            </circle>
            <circle
              cx="70%"
              cy="60%"
              r="4"
              fill="#06B6D4"
              className="animate-ping-slow animation-delay-1500"
            >
              <animate
                attributeName="fill"
                values="#06B6D4;#3B82F6;#06B6D4"
                dur="2s"
                repeatCount="indefinite"
              />
            </circle>
            <circle
              cx="90%"
              cy="30%"
              r="4"
              fill="#3B82F6"
              className="animate-ping-slow animation-delay-2000"
            >
              <animate
                attributeName="fill"
                values="#3B82F6;#06B6D4;#3B82F6"
                dur="2s"
                repeatCount="indefinite"
              />
            </circle>

            {/* Gradient Definitions */}
            <defs>
              <linearGradient
                id="gradient1"
                x1="0%"
                y1="0%"
                x2="100%"
                y2="100%"
              >
                <stop offset="0%" stopColor="#3B82F6" stopOpacity="0.8" />
                <stop offset="100%" stopColor="#06B6D4" stopOpacity="0.4" />
              </linearGradient>
            </defs>
          </svg>
        </div>
      </div>

      {/* Header */}
      {/* <header className="top-0 w-full bg-transparant px-16 flex justify-between items-center py-6 z-20 relative">
        <div className="flex items-center space-x-2">
          <img src={logo} alt="Logo" className="h-10  mt-4" />
        </div>
        <div className="inline-flex items-center space-x-2 px-4 bg-gradient-to-r from-blue-100 to-purple-100 
        rounded-full text-sm font-medium text-blue-700 h-8">
          <Star className="w-4 h-4" />
          <span>Trusted by 2M+ traders worldwide</span>
        </div>
      </header> */}

      <header className="top-0 w-full px-4 sm:px-8 md:px-16 py-4 flex flex-col md:flex-row justify-between items-center bg-transparent z-20">
        {/* Logo */}
        <div className="flex items-center mb-2 md:mb-0">
          <img src={logo} alt="Logo" className="h-10 md:h-12" />
        </div>

        {/* Trust Badge */}
        <div className="inline-flex items-center space-x-2 px-3 sm:px-4 py-1 sm:py-2 bg-gradient-to-r from-blue-100 to-purple-100 rounded-full text-sm sm:text-base font-medium text-blue-700">
          <Star className="w-4 h-4 sm:w-5 sm:h-5" />
          <span>Trusted by 2M+ traders worldwide</span>
        </div>
      </header>

      {/* Hero Section */}
      <section className="pt-4 pb-20 px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div
              className={`space-y-8 transform transition-all duration-1000 ${
                isVisible
                  ? "translate-x-0 opacity-100"
                  : "-translate-x-20 opacity-0"
              }`}
            >
              <div className="space-y-6">
                {/* <div className="inline-flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-blue-100 to-purple-100 rounded-full text-sm font-medium text-blue-700">
                  <Star className="w-4 h-4" />
                  <span>Trusted by 2M+ traders worldwide</span>
                </div> */}

                <h1 className="text-5xl lg:text-7xl them-prime font-bold leading-tight">
                  Trade Crypto with
                  <span className="them-sec ml-3 text-4rem font-bold">
                    Confidence
                  </span>
                </h1>
                <p className="text-xl text-gray-600 leading-relaxed max-w-2xl">
                  Experience the future of cryptocurrency trading with our
                  secure, lightning-fast platform. Join millions of traders who
                  trust Payglobal.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link
                  to="/admin-login"
                  className="btn-them group px-4 py-2 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white rounded-xl text-lg font-semibold  flex 
                items-center space-x-2  hover:shadow-2xl transform hover:scale-105 transition-all duration-300 relative overflow-hidden"
                >
                  <span className="relative z-10 flex items-center">
                    Start Trading Now
                    <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                  </span>
                </Link>
              </div>

              <div className="grid grid-cols-3 gap-6 pt-8">
                <div className="text-center">
                  <div className="text-3xl font-bold text-gray-900 mb-1">
                    2M+
                  </div>
                  <div className="text-sm text-gray-600">Active Users</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-gray-900 mb-1">
                    $50B+
                  </div>
                  <div className="text-sm text-gray-600">Trading Volume</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-gray-900 mb-1">
                    99.9%
                  </div>
                  <div className="text-sm text-gray-600">Uptime</div>
                </div>
              </div>
            </div>

            <div
              className={`relative transform transition-all duration-1000 delay-500 ${
                isVisible
                  ? "translate-x-0 opacity-100"
                  : "translate-x-20 opacity-0"
              }`}
            >
              <div className="relative z-10">
                <motion.img
                  src={img6}
                  alt="animated"
                  animate={{ y: [0, -10, 0] }}
                  transition={{
                    duration: 4,
                    repeat: Infinity,
                    ease: "easeInOut",
                  }}
                  className="rounded-lg mt-4"
                  style={{ width: "500px", justifySelf: "center" }}
                />
              </div>
              {/* Floating Elements around Chart */}
              <div className="absolute -top-8 -left-8 opacity-60">
                <FloatingElement delay={0}>
                  <div className="w-16 h-16 bg-gradient-to-r from-green-400 to-blue-500 rounded-2xl flex items-center justify-center shadow-xl">
                    <TrendingUp className="w-8 h-8 text-white" />
                  </div>
                </FloatingElement>
              </div>
              <div className="absolute -bottom-8 -right-8 opacity-60">
                <FloatingElement delay={1}>
                  <div className="w-16 h-16 bg-gradient-to-r from-purple-400 to-pink-500 rounded-2xl flex items-center justify-center shadow-xl">
                    <DollarSign className="w-8 h-8 text-white" />
                  </div>
                </FloatingElement>
              </div>
              <div className="absolute inset-0 bg-gradient-to-r from-blue-500/10 to-purple-600/10 rounded-3xl blur-3xl transform -rotate-6"></div>
            </div>
          </div>
        </div>
      </section>

      {/* chart section */}
      {/* <section className="flex item-center justify-between bg-[#d4e6f882] backdrop-blur-lg rounded-3xl shadow-2xl p-6 border border-white/50 w-full">
        <CryptoChart pg={"PG"} />
        <CryptoChart pg={"ETH"} />
        <CryptoChart pg={"BTC"} />

      </section> */}

      <section className="flex flex-col md:flex-row items-center justify-between bg-[#d4e6f882] backdrop-blur-lg rounded-3xl shadow-2xl p-4 sm:p-6 border border-white/50 w-full gap-4">
        <CryptoChart pg={"PG"} className="w-full md:w-1/3" />
        <CryptoChart pg={"ETH"} className="w-full md:w-1/3" />
        <CryptoChart pg={"BTC"} className="w-full md:w-1/3" />
      </section>

      {/* Features Section */}
      <section
        id="features"
        className="py-20 px-4 sm:px-6 lg:px-8 bg-[#d4e6f84a] backdrop-blur-sm"
      >
        <div className="max-w-7xl mx-auto">
          <div className="text-center space-y-4 mb-16">
            <div className="inline-flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-blue-700 to-cyan-600 rounded-full text-sm font-medium text-white mb-4">
              <CheckCircle className="w-4 h-4" />
              <span>Why millions choose us</span>
            </div>
            <h2 className="text-4xl lg:text-5xl font-bold mb-4">
              Why Choose
              <span className="bg-gradient-to-r from-blue-700 to-cyan-600 bg-clip-text text-transparent">
                {" "}
                Payglobal?
              </span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Built with cutting-edge technology and security features to
              provide the most advanced trading experience.
            </p>
          </div>

          <div className="w-full gap-8">
            {features.map((feature, index) => (
              <FeatureCard key={index} {...feature} index={index} />
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-gray-800 via-blue-800 to-cyan-700 relative overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute top-10 left-10 opacity-20">
            <FloatingElement>
              <Bitcoin className="w-12 h-12 text-white" />
            </FloatingElement>
          </div>
          <div className="absolute top-20 right-20 opacity-20">
            <FloatingElement delay={1}>
              <Coins className="w-10 h-10 text-white" />
            </FloatingElement>
          </div>
          <div className="absolute bottom-20 left-1/4 opacity-20">
            <FloatingElement delay={2}>
              <Wallet className="w-8 h-8 text-white" />
            </FloatingElement>
          </div>
        </div>

        <div className="max-w-7xl mx-auto text-center text-white relative z-10">
          <h2 className="text-4xl lg:text-5xl font-bold mb-6">
            Trusted by Millions
          </h2>
          <p className="text-xl mb-12 opacity-90">
            Join the fastest growing crypto community worldwide
          </p>

          <div className="grid md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div
                key={index}
                className="transform hover:scale-110 transition-transform duration-300"
              >
                <div className="text-5xl font-bold mb-1">{stat.value}</div>
                <div className="text-lg opacity-90">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>
      <Footer />
    </div>
  );
};

// Feature Card Component
const FeatureCard = ({ icon: Icon, title, description, index }) => {
  return (
    // <div
    //   className="group gap-2 flex items-center mb-5 p-6 bg-white/70 backdrop-blur-sm rounded-3xl shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border border-white/50 hover:border-blue-200"
    //   style={{ animationDelay: `${index * 0.1}s` }}
    // >
    <div
      className="group flex items-center gap-2 mb-5 py-2 md:py-6 px-3 bg-white/70 backdrop-blur-sm rounded-3xl shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border border-white/50 hover:border-blue-200"
      style={{ animationDelay: `${index * 0.1}s` }}
    >
      <div className="w-14 h-14 bg-gradient-to-r px-1 md:px-0 from-blue-500 to-cyan-700 rounded-2xl flex items-center justify-center  group-hover:scale-110 transition-transform">
        <Icon className="w-7 h-7 text-white" />
      </div>

      <div>
        <h3 className="text-xl mb-0 font-semibold group-hover:text-blue-600 transition-colors block">
          {title}
        </h3>
        <p className="text-gray-600 leading-relaxed">{description}</p>
      </div>
    </div>
  );
};

// Crypto Chart Component
const CryptoChart = ({ pg }) => {
  return (
    <div className="bg-white backdrop-blur-lg rounded-3xl shadow-2xl p-6 border border-white/50  max-w-[430px] w-full">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold">{pg}/USD</h3>
          <p className="text-green-500 text-sm font-medium">+2.45% (24h)</p>
        </div>
        <div className="text-right">
          <div className="text-2xl font-bold">$45,230.50</div>
          <div className="text-sm text-gray-500">Current Price</div>
        </div>
      </div>

      <div className="h-48 bg-gradient-to-br from-blue-50 to-cyan-50 rounded-2xl flex items-center justify-center mb-6">
        <div className="space-y-4 w-full px-4">
          <div className="flex items-end space-x-2 h-24 justify-center">
            {[...Array(12)].map((_, i) => (
              <div
                key={i}
                className="bg-gradient-to-t from-blue-500 to-cyan-600 rounded-t-sm opacity-80 hover:opacity-100 transition-opacity"
                style={{
                  height: `${Math.random() * 60 + 20}px`,
                  width: "12px",
                }}
              />
            ))}
          </div>
          <div className="flex justify-between text-xs text-gray-500">
            <span>12:00</span>
            <span>15:00</span>
            <span>18:00</span>
            <span>21:00</span>
            <span>Now</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4 pt-6 border-t border-gray-100">
        <div className="text-center">
          <div className="text-sm text-gray-500 mb-1">Volume</div>
          <div className="font-semibold">$2.4B</div>
        </div>
        <div className="text-center">
          <div className="text-sm text-gray-500 mb-1">Market Cap</div>
          <div className="font-semibold">$850B</div>
        </div>
        <div className="text-center">
          <div className="text-sm text-gray-500 mb-1">Supply</div>
          <div className="font-semibold">19.8M</div>
        </div>
      </div>
    </div>
  );
};

// Data Arrays
const features = [
  {
    icon: Shield,
    title: "Bank-Grade Security",
    description:
      "Your funds are protected by military-grade encryption and multi-signature wallets with 24/7 monitoring and cold storage.",
  },
  {
    icon: Zap,
    title: "Lightning Fast Trading",
    description:
      "Execute trades in milliseconds with our optimized matching engine and global server network infrastructure.",
  },
  {
    icon: TrendingUp,
    title: "Advanced Trading Tools",
    description:
      "Professional trading tools, real-time charts, technical analysis, and advanced order types for experienced traders.",
  },
  {
    icon: Wallet,
    title: "Multi-Currency Wallet",
    description:
      "Store, send, and receive over 150+ cryptocurrencies in one secure, easy-to-use wallet with instant transfers.",
  },
  {
    icon: Users,
    title: "24/7 Expert Support",
    description:
      "Get help whenever you need it with our round-the-clock customer support team and comprehensive knowledge base.",
  },
  {
    icon: BarChart3,
    title: "Analytics & Insights",
    description:
      "Make informed decisions with comprehensive market data, professional trading insights, and portfolio analytics.",
  },
];

const stats = [
  { value: "2M+", label: "Active Users" },
  { value: "$50B+", label: "Trading Volume" },
  { value: "150+", label: "Cryptocurrencies" },
  { value: "99.9%", label: "Uptime" },
];

export default CryptoExchangeApp;
