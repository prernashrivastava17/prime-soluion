// import { Shield, Zap, Globe, Code, Users, TrendingUp, Discord, Reddit, Rss, Info, Briefcase, Newspaper, Mail } from 'lucide-react';

// import { FaFacebook, FaTwitter, FaLinkedin, FaInstagram, FaDiscord, FaReddit } from "react-icons/fa";
// export const COMPANY_NAME = 'Pay Global';

// export const NAVIGATION_ITEMS = [
//   { label: 'Features', href: '#features' },
//   { label: 'Roadmap', href: '#roadmap' },
//   { label: 'Developers', href: '#developers' },
//   { label: 'Community', href: '#community' },
// ];

// export const FEATURES = [
//   {
//     icon: Shield,
//     title: "Enterprise Security",
//     description: "Military-grade encryption with advanced consensus mechanisms ensuring maximum security for all transactions."
//   },
//   {
//     icon: Zap,
//     title: "Lightning Fast",
//     description: "Process thousands of transactions per second with sub-second finality and minimal gas fees."
//   },
//   {
//     icon: Code,
//     title: "EVM Compatible",
//     description: "Full Ethereum Virtual Machine compatibility. Deploy existing smart contracts without modification."
//   },
//   {
//     icon: Globe,
//     title: "Global Network",
//     description: "Decentralized infrastructure spanning multiple continents with 99.9% uptime guarantee."
//   },
//   {
//     icon: Users,
//     title: "Developer Friendly",
//     description: "Comprehensive SDKs, APIs, and documentation to accelerate your blockchain development."
//   },
//   {
//     icon: TrendingUp,
//     title: "Scalable Architecture",
//     description: "Built for the future with horizontal scaling capabilities and modular design principles."
//   }
// ];

// export const STATS = [
//   { number: "50M+", label: "Transactions Processed" },
//   { number: "10K+", label: "Active Validators" },
//   { number: "99.9%", label: "Network Uptime" },
//   { number: "<1s", label: "Block Time" }
// ];

// export const ROADMAP_ITEMS = [
//   {
//     phase: "Phase 1",
//     title: "Mainnet Launch",
//     status: "completed",
//     description: "Core blockchain infrastructure and basic functionality"
//   },
//   {
//     phase: "Phase 2",
//     title: "DeFi Integration",
//     status: "completed",
//     description: "DEX, lending protocols, and yield farming capabilities"
//   },
//   {
//     phase: "Phase 3",
//     title: "Cross-chain Bridges",
//     status: "active",
//     description: "Seamless interoperability with major blockchains"
//   },
//   {
//     phase: "Phase 4",
//     title: "Enterprise Solutions",
//     status: "upcoming",
//     description: "B2B blockchain solutions and enterprise partnerships"
//   }
// ];

// export const FOOTER_LINKS = {
//   socialmedia: [
//     { label: "Facebook", href: "#", icon: FaFacebook },
//     { label: "LinkedIn", href: "#", icon: FaLinkedin },
//     { label: "Instagram", href: "#", icon: FaInstagram },
//   ],
//   community: [
//     { label: "Discord", href: "https://discord.com", icon: FaDiscord },
//     { label: "Twitter", href: "https://twitter.com", icon: FaTwitter },
//     { label: "Reddit", href: "https://reddit.com", icon: FaReddit },
//     { label: "Blog", href: "/blog", icon: Rss },
//   ],
//   company: [
//     { label: "About", href: "/about", icon: Info },
//     { label: "Careers", href: "/careers", icon: Briefcase },
//     { label: "Press", href: "/press", icon: Rss },
//     { label: "Contact", href: "/contact", icon: Info },
//   ],
// };


import {
  Shield,
  Zap,
  Globe,
  Code,
  Users,
  TrendingUp,
  MessageCircle,
  ArrowRight,
  Info,
  Briefcase,
  Rss,
  Mail
} from 'lucide-react';

import { FaFacebook, FaTwitter, FaLinkedin, FaInstagram, FaDiscord, FaReddit } from "react-icons/fa";

export const COMPANY_NAME = 'Pay Global';

export const NAVIGATION_ITEMS = [
  { label: 'Features', href: '#features' },
  { label: 'Roadmap', href: '#roadmap' },
  { label: 'Developers', href: '#developers' },
  { label: 'Community', href: '#community' },
];

export const FEATURES = [
  {
    icon: Shield,
    title: "Enterprise Security",
    description: "Military-grade encryption with advanced consensus mechanisms ensuring maximum security for all transactions."
  },
  {
    icon: Zap,
    title: "Lightning Fast",
    description: "Process thousands of transactions per second with sub-second finality and minimal gas fees."
  },
  {
    icon: Code,
    title: "EVM Compatible",
    description: "Full Ethereum Virtual Machine compatibility. Deploy existing smart contracts without modification."
  },
  {
    icon: Globe,
    title: "Global Network",
    description: "Decentralized infrastructure spanning multiple continents with 99.9% uptime guarantee."
  },
  {
    icon: Users,
    title: "Developer Friendly",
    description: "Comprehensive SDKs, APIs, and documentation to accelerate your blockchain development."
  },
  {
    icon: TrendingUp,
    title: "Scalable Architecture",
    description: "Built for the future with horizontal scaling capabilities and modular design principles."
  }
];

export const STATS = [
  { number: "50M+", label: "Transactions Processed" },
  { number: "10K+", label: "Active Validators" },
  { number: "99.9%", label: "Network Uptime" },
  { number: "<1s", label: "Block Time" }
];

export const ROADMAP_ITEMS = [
  {
    phase: "Phase 1",
    title: "Mainnet Launch",
    status: "completed",
    description: "Core blockchain infrastructure and basic functionality"
  },
  {
    phase: "Phase 2",
    title: "DeFi Integration",
    status: "completed",
    description: "DEX, lending protocols, and yield farming capabilities"
  },
  {
    phase: "Phase 3",
    title: "Cross-chain Bridges",
    status: "active",
    description: "Seamless interoperability with major blockchains"
  },
  {
    phase: "Phase 4",
    title: "Enterprise Solutions",
    status: "upcoming",
    description: "B2B blockchain solutions and enterprise partnerships"
  }
];

export const FOOTER_LINKS = {
  socialmedia: [
    { label: "Facebook", href: "#", icon: FaFacebook },
    { label: "LinkedIn", href: "#", icon: FaLinkedin },
    { label: "Instagram", href: "#", icon: FaInstagram },
  ],
  community: [
    { label: "Discord", href: "https://discord.com", icon: FaDiscord },
    { label: "Twitter", href: "https://twitter.com", icon: FaTwitter },
    { label: "Reddit", href: "https://reddit.com", icon: FaReddit },
    { label: "Blog", href: "/blog", icon: Rss },
  ],
  company: [
    { label: "About", href: "/about", icon: Info },
    { label: "Careers", href: "/careers", icon: Briefcase },
    { label: "Press", href: "/press", icon: Rss },
    { label: "Contact", href: "/contact", icon: Mail },
  ],
};