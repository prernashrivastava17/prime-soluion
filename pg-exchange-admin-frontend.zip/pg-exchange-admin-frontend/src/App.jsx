import "./App.css";
import CryptoExchangeApp from "./ExchangeLeanding";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
} from "react-router-dom";
import AdminLogin from "./components/auth/AdminLogin";
import Dashboard from "./components/Dashboard/Dashboard";
import Home from "./components/Home/Home";
import Profile from "./components/Profile/Profile";
import BuyTransactionHistory from "./components/TransactionHistory/BuyTransactionHistory";
import WithdrawTransactionHistory from "./components/TransactionHistory/WithdrawTransactionHistory";
import ForgatePass from "./components/auth/ForgatePass";
import UserTable from "./components/userTable/UserTable";
import KYCValidationTable from "./components/Dashboard/KYCValidationForm";

// Auth check function
const isAuthenticated = () => {
  try {
    const adminData = localStorage.getItem("adminData");
    return !!adminData;
  } catch {
    return false;
  }
};

// Protected route wrapper
const RequireAuth = ({ children }) => {
  return isAuthenticated() ? children : <Navigate to="/admin-login" replace />;
};

// Public route wrapper (redirect to dashboard if already authenticated)
const PublicRoute = ({ children }) => {
  return !isAuthenticated() ? children : <Navigate to="/dashboard" replace />;
};

function App() {
  return (
    <Router>
      <Routes>
        {/* Public Routes */}
        <Route
          path="/"
          element={
            <PublicRoute>
              {/* <CryptoExchangeApp /> */}
              <AdminLogin />
            </PublicRoute>
          }
        />
        <Route
          path="/forgot-password"
          element={
            <PublicRoute>
              <ForgatePass />
            </PublicRoute>
          }
        />
        <Route
          path="/admin-login"
          element={
            <PublicRoute>
              <AdminLogin />
            </PublicRoute>
          }
        />

        {/* Protected Routes */}
        <Route
          path="/dashboard"
          element={
            <RequireAuth>
              <Home>
                <Dashboard />
              </Home>
            </RequireAuth>
          }
        />
        <Route
          path="/profile"
          element={
            <RequireAuth>
              <Home>
                <Profile />
              </Home>
            </RequireAuth>
          }
        />
        <Route
          path="/UserTable"
          element={
            <RequireAuth>
              <Home>
                <UserTable />
              </Home>
            </RequireAuth>
          }
        />
        <Route
          path="/KYCValidationForm"
          element={
            <RequireAuth>
              <Home>
                <KYCValidationTable />
              </Home>
            </RequireAuth>
          }
        />

        {/* Buy Transaction History */}
        <Route
          path="/transaction-history/buy"
          element={
            <RequireAuth>
              <Home>
                <BuyTransactionHistory />
              </Home>
            </RequireAuth>
          }
        />

        {/* Withdraw Transaction History */}
        <Route
          path="/transaction-history/withdraw"
          element={
            <RequireAuth>
              <Home>
                <WithdrawTransactionHistory />
              </Home>
            </RequireAuth>
          }
        />

        {/* Catch-All Route */}
        <Route
          path="*"
          element={
            isAuthenticated() ? (
              <Navigate to="/dashboard" replace />
            ) : (
              <Navigate to="/" replace />
            )
          }
        />
      </Routes>
    </Router>
  );
}

export default App;
