// export const fetchApi = async (url, data = null, method = "POST", options = {}) => {
//     try {
//         const defaultOptions = {
//             method: method.toUpperCase(),
//             headers: {
//                 'Content-Type': 'application/json',
//                 ...options.headers,
//             },
//             ...options,
//         };

//         let fullUrl = `/api/user/${url}`;

//         // Handle GET requests with query parameters
//         if (data && method.toUpperCase() === 'GET') {
//             const queryParams = new URLSearchParams(data).toString();
//             fullUrl = `${fullUrl}?${queryParams}`;
//         }
//         // Handle other methods with request body
//         else if (data && ['POST', 'PUT', 'PATCH', 'DELETE'].includes(method.toUpperCase())) {
//             defaultOptions.body = JSON.stringify(data);
//         }

//         console.log("Making API call to:", fullUrl, "with data:", data, "method:", method);

//         const response = await fetch(fullUrl, defaultOptions);

//         // Handle different response types
//         const contentType = response.headers.get('content-type');

//         let responseData;

//         if (contentType && contentType.includes('application/json')) {
//             responseData = await response.json();
//         } else if (contentType && contentType.includes('text/')) {
//             responseData = await response.text();
//         } else if (contentType && contentType.includes('multipart/form-data')) {
//             responseData = await response.formData();
//         } else if (contentType && contentType.includes('blob')) {
//             responseData = await response.blob();
//         } else if (contentType && contentType.includes('arraybuffer')) {
//             responseData = await response.arrayBuffer();
//         } else {
//             responseData = await response.text();
//         }

//         // Return as [result, response] array
//         return [
//             {
//                 success: response.ok,
//                 status: response.status,
//                 statusText: response.statusText,
//                 data: responseData,
//                 headers: response.headers,
//                 url: response.url
//             },
//             responseData // Direct response data for easy access
//         ];

//     } catch (error) {
//         console.error('API call failed:', error);

//         // Return structured error response in the same array format
//         return [
//             {
//                 success: false,
//                 status: 0,
//                 statusText: 'Network Error',
//                 data: null,
//                 error: error.message,
//                 isNetworkError: true
//             },
//             null
//         ];
//     }
// };



export const fetchApi = async (url, body, method) => {

    let data = body ? JSON.stringify(body) : {};
    console.log("url, body, method---", url, body, method)
    try {
        let settings = {
            method: method,
            headers: { 'Accept': 'application/json', 'Content-Type': 'application/json' },
            body: data
        }

        let response = await fetch(`/api/${url}`, settings)
        if (response) {
            console.log("response in fetchApi---", response)
        } else {
            console.log("No response---in FetchApi")
        }
        let result = await response?.json();
        return [response, result];
    } catch (error) {
        console.log(error)
    }
}