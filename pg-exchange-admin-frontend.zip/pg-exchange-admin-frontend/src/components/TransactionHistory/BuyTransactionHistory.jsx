import React, { useState, useMemo, useEffect } from "react";
import {
  ArrowUpRight,
  Search,
  ChevronLeft,
  ChevronRight,
  Download,
  Filter,
  RefreshCw,
} from "lucide-react";
import {
  Table,
  Button,
  Select,
  Input,
  Card,
  Statistic,
  Row,
  Col,
  Tag,
  Space,
  message,
  Spin,
} from "antd";
import * as XLSX from "xlsx";
import toast from "react-hot-toast";

const { Option } = Select;

const TransactionHistory = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);

  // Token icons data
  const tokens = [
    { symbol: "BTC", icon: "₿", name: "Bitcoin", color: "text-orange-500" },
    { symbol: "ETH", icon: "Ξ", name: "Ethereum", color: "text-purple-500" },
    { symbol: "MATIC", icon: "🔷", name: "Polygon", color: "text-blue-500" },
    {
      symbol: "BNB",
      icon: "🟡",
      name: "Binance Coin",
      color: "text-yellow-500",
    },
    { symbol: "ABIX", icon: "⚡", name: "Abix", color: "text-green-500" },
    { symbol: "USD", icon: "$", name: "US Dollar", color: "text-gray-500" },
    { symbol: "USDT", icon: "💵", name: "Tether", color: "text-green-400" },
    { symbol: "PGL", icon: "🔶", name: "PGL", color: "text-blue-400" },
  ];

  // Fetch transaction data
  useEffect(() => {
    const fetchTransactionData = async () => {
      setLoading(true);
      try {
        const response = await fetch("/api/admin/get-txn-history", {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
          },
        });

        if (!response.ok) {
          throw new Error("Failed to fetch transaction data");
        }

        const result = await response.json();
        console.log("Transaction API result:", result);

        if (result?.success && result?.allTxns) {
          setData(result.allTxns);
          message.success("Transaction data loaded successfully");
        } else {
          throw new Error("No transaction data found");
        }
      } catch (error) {
        console.error("Error fetching transactions:", error);
        message.error("Failed to load transaction data");
        setData([]);
      } finally {
        setLoading(false);
      }
    };

    fetchTransactionData();
  }, []);

  // Refresh data function
  const refreshData = async () => {
    setLoading(true);
    try {
      const response = await fetch("/api/admin/get-txn-history", {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        throw new Error("Failed to fetch transaction data");
      }

      const result = await response.json();

      if (result?.success && result?.allTxns) {
        setData(result.allTxns);
        toast.success("Data refreshed successfully");
      }
    } catch (error) {
      console.error("Error refreshing data:", error);
      toast.error("Failed to refresh data");
    } finally {
      setLoading(false);
    }
  };

  // Filter and search logic
  const filteredData = useMemo(() => {
    return data.filter((transaction) => {
      const matchesSearch =
        transaction.currency
          ?.toLowerCase()
          .includes(searchTerm.toLowerCase()) ||
        transaction.transactionType
          ?.toLowerCase()
          .includes(searchTerm.toLowerCase()) ||
        transaction.status?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        transaction.transactionId
          ?.toLowerCase()
          .includes(searchTerm.toLowerCase()) ||
        transaction.toAddress?.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesStatus =
        statusFilter === "all" ||
        transaction.status === statusFilter ||
        (statusFilter === "success" && transaction.status === "success") ||
        (statusFilter === "completed" && transaction.status === "completed");

      const matchesType =
        typeFilter === "all" || transaction.transactionType === typeFilter;

      return matchesSearch && matchesStatus && matchesType;
    });
  }, [data, searchTerm, statusFilter, typeFilter]);

  // Pagination logic
  const totalPages = Math.ceil(filteredData.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const currentItems = filteredData.slice(startIndex, endIndex);

  // Handle page change
  const goToPage = (page) => {
    setCurrentPage(Math.max(1, Math.min(page, totalPages)));
  };

  // Stats calculations
  const stats = useMemo(
    () => ({
      total: data.length,
      completed: data.filter(
        (t) => t.status === "completed" || t.status === "success"
      ).length,
      pending: data.filter((t) => t.status === "pending").length,
      failed: data.filter((t) => t.status === "failed").length,
      totalVolume: data.reduce(
        (sum, t) => sum + (parseFloat(t.amount) || 0),
        0
      ),
      buyCount: data.filter((t) => t.transactionType === "buy").length,
      sellCount: data.filter((t) => t.transactionType === "sell").length,
      withdrawCount: data.filter((t) => t.transactionType === "withdraw")
        .length,
      depositCount: data.filter((t) => t.transactionType === "deposit").length,
    }),
    [data]
  );

  // Export to Excel function
  const exportToExcel = () => {
    try {
      const worksheet = XLSX.utils.json_to_sheet(
        filteredData.map((item) => ({
          "Transaction ID": item.transactionId,
          Date: new Date(item.createdAt).toLocaleString(),
          Type: item.transactionType,
          Currency: item.currency,
          Amount: parseFloat(item.amount).toFixed(2),
          Fee: parseFloat(item.fee || 0).toFixed(6),
          Status: item.status,
          "To Address": item.toAddress,
          "Wallet Address": item.walletAddress,
          Chain: item.chain,
          Network: item.network,
          "Contract Address": item.contracktAddress,
          "User ID": item.userId,
        }))
      );

      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, "Transactions");
      XLSX.writeFile(
        workbook,
        `transactions_${new Date().toISOString().split("T")[0]}.xlsx`
      );
      message.success("Excel file downloaded successfully");
    } catch (error) {
      console.error("Error exporting to Excel:", error);
      message.error("Failed to export Excel file");
    }
  };

  // Table columns for Ant Design Table
  const columns = [
    {
      title: "Date",
      dataIndex: "createdAt",
      key: "createdAt",
      render: (date) => new Date(date).toLocaleString(),
      sorter: (a, b) => new Date(a.createdAt) - new Date(b.createdAt),
      width: 180,
    },
    {
      title: "Transaction ID",
      dataIndex: "transactionId",
      key: "transactionId",
      render: (id) => (
        <span
          className="font-mono text-xs cursor-pointer"
          title={id}
          onClick={() => {
            navigator.clipboard.writeText(id);
            message.success("Transaction ID copied to clipboard");
          }}
        >
          {id}
        </span>
      ),
      width: 140,
    },
    {
      title: "User ID",
      dataIndex: "userId",
      key: "userId",
      render: (id) => <span className="font-mono text-xs">{id}</span>,
      width: 120,
    },
    {
      title: "Type",
      dataIndex: "transactionType",
      key: "transactionType",
      render: (type) => (
        <Tag
          color={
            type === "buy"
              ? "green"
              : type === "sell"
              ? "red"
              : type === "withdraw"
              ? "orange"
              : type === "deposit"
              ? "blue"
              : "purple"
          }
        >
          {type?.toUpperCase()}
        </Tag>
      ),
      filters: [
        { text: "Buy", value: "buy" },
        { text: "Sell", value: "sell" },
        { text: "Withdraw", value: "withdraw" },
        { text: "Deposit", value: "deposit" },
      ],
      onFilter: (value, record) => record.transactionType === value,
      width: 120,
    },
    {
      title: "Token",
      dataIndex: "token",
      key: "token",
      render: (token, record) => (
        <span className="font-semibold">
          {parseFloat(token).toLocaleString()} {record.currency}
        </span>
      ),
      sorter: (a, b) => parseFloat(a.token) - parseFloat(b.token),
      width: 130,
    },
    {
      title: "Currency",
      dataIndex: "currency",
      key: "currency",
      render: (currency) => {
        const token = tokens.find((t) => t.symbol === currency);
        return (
          <Space>
            <span className={`text-lg ${token?.color || "text-gray-500"}`}>
              {token?.icon || "$"}
            </span>
            <span>{currency}</span>
          </Space>
        );
      },
      width: 120,
    },
    {
      title: "Amount",
      dataIndex: "amount",
      key: "amount",
      render: (amount, record) => (
        <span className="font-semibold">
          ₹ {parseFloat(amount).toLocaleString()}
        </span>
      ),
      sorter: (a, b) => parseFloat(a.amount) - parseFloat(b.amount),
      width: 130,
    },
    {
      title: "Fee",
      dataIndex: "fee",
      key: "fee",
      render: (fee) => `$${parseFloat(fee || 0).toFixed(6)}`,
      width: 100,
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      render: (status) => (
        <Tag
          color={
            status === "completed" || status === "success"
              ? "green"
              : status === "pending"
              ? "orange"
              : "red"
          }
        >
          {status?.toUpperCase()}
        </Tag>
      ),
      filters: [
        { text: "Completed", value: "completed" },
        { text: "Success", value: "success" },
        { text: "Pending", value: "pending" },
        { text: "Failed", value: "failed" },
      ],
      onFilter: (value, record) => record.status === value,
      width: 120,
    },
    {
      title: "To Address",
      dataIndex: "toAddress",
      key: "toAddress",
      render: (address) => (
        <span
          className="font-mono text-xs cursor-pointer"
          title={address}
          onClick={() => {
            navigator.clipboard.writeText(address);
            message.success("Address copied to clipboard");
          }}
        >
          {address}
        </span>
      ),
      width: 140,
    },
    {
      title: "Chain",
      dataIndex: "chain",
      key: "chain",
      render: (chain) => <Tag color="blue">{chain}</Tag>,
      width: 100,
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-cyan-50 p-4 sm:p-6">
      <div className="max-w-7xl mx-auto">
        <div className="bg-gradient-to-br from-white to-purple-50 rounded-2xl p-4 sm:p-6 shadow-2xl border border-purple-200">
          {/* Header */}
          <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-6 gap-4">
            <div className="flex items-center gap-3">
              <div className="bg-gradient-to-r from-[#1e2746] to-purple-600 p-3 rounded-xl">
                <ArrowUpRight className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">
                  Transaction History
                </h1>
                <p className="text-gray-600">
                  View all user transaction activities
                </p>
              </div>
            </div>

            <Space>
              <Button
                icon={<RefreshCw />}
                onClick={refreshData}
                loading={loading}
              >
                Refresh
              </Button>
              <Button
                type="primary"
                icon={<Download />}
                onClick={exportToExcel}
              >
                Export Excel
              </Button>
            </Space>
          </div>

          {/* Stats Cards using Ant Design */}
          <Row gutter={[16, 16]} className="mb-6">
            <Col xs={24} sm={12} md={6}>
              <Card>
                <Statistic
                  title="Completed"
                  value={stats.completed}
                  valueStyle={{ color: "#52c41a" }}
                />
              </Card>
            </Col>

            <Col xs={24} sm={12} md={6}>
              <Card>
                <Statistic
                  title="Pending"
                  value={stats.pending}
                  valueStyle={{ color: "#faad14" }}
                />
              </Card>
            </Col>

            <Col xs={24} sm={12} md={6}>
              <Card>
                <Statistic
                  title="Failed"
                  value={stats.failed}
                  valueStyle={{ color: "#f5222d" }}
                />
              </Card>
            </Col>

            <Col xs={24} sm={12} md={6}>
              <Card>
                <Statistic
                  title="Withdrawals"
                  value={stats.withdrawCount}
                  valueStyle={{ color: "#fa8c16" }}
                />
              </Card>
            </Col>
          </Row>

          {/* Filters */}
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            {/* Search */}
            <Input
              placeholder="Search by currency, type, status, TXN ID or address..."
              prefix={<Search className="text-gray-400" />}
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setCurrentPage(1);
              }}
              style={{ width: 300 }}
            />

            {/* Status Filter */}
            <Select
              value={statusFilter}
              onChange={(value) => {
                setStatusFilter(value);
                setCurrentPage(1);
              }}
              style={{ width: 150 }}
            >
              <Option value="all">All Status</Option>
              <Option value="success">Success</Option>
              <Option value="completed">Completed</Option>
              <Option value="pending">Pending</Option>
              <Option value="failed">Failed</Option>
            </Select>

            {/* Type Filter */}
            <Select
              value={typeFilter}
              onChange={(value) => {
                setTypeFilter(value);
                setCurrentPage(1);
              }}
              style={{ width: 150 }}
            >
              <Option value="all">All Types</Option>
              <Option value="buy">Buy</Option>
              <Option value="sell">Sell</Option>
              <Option value="deposit">Deposit</Option>
              <Option value="withdraw">Withdraw</Option>
            </Select>
          </div>

          {/* Table */}
          <Card>
            <Spin spinning={loading}>
              <Table
                columns={columns}
                dataSource={currentItems}
                rowKey="_id"
                pagination={false}
                scroll={{ x: 1200 }}
                size="middle"
              />
            </Spin>
          </Card>

          {/* Custom Pagination */}
          {filteredData.length > 0 && (
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mt-6">
              <div className="text-sm text-gray-600">
                Showing {startIndex + 1}-
                {Math.min(endIndex, filteredData.length)} of{" "}
                {filteredData.length} transactions
              </div>

              <div className="flex items-center gap-2">
                <Button
                  onClick={() => goToPage(currentPage - 1)}
                  disabled={currentPage === 1}
                  icon={<ChevronLeft className="w-4 h-4" />}
                />

                {/* Page Numbers */}
                {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                  let pageNum;
                  if (totalPages <= 5) {
                    pageNum = i + 1;
                  } else if (currentPage <= 3) {
                    pageNum = i + 1;
                  } else if (currentPage >= totalPages - 2) {
                    pageNum = totalPages - 4 + i;
                  } else {
                    pageNum = currentPage - 2 + i;
                  }

                  return (
                    <Button
                      key={pageNum}
                      onClick={() => goToPage(pageNum)}
                      type={currentPage === pageNum ? "primary" : "default"}
                    >
                      {pageNum}
                    </Button>
                  );
                })}

                <Button
                  onClick={() => goToPage(currentPage + 1)}
                  disabled={currentPage === totalPages}
                  icon={<ChevronRight className="w-4 h-4" />}
                />

                <Select
                  value={itemsPerPage}
                  onChange={(value) => {
                    setItemsPerPage(value);
                    setCurrentPage(1);
                  }}
                  style={{ width: 120 }}
                >
                  <Option value={10}>Show 10</Option>
                  <Option value={20}>Show 20</Option>
                  <Option value={50}>Show 50</Option>
                  <Option value={100}>Show 100</Option>
                </Select>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default TransactionHistory;
