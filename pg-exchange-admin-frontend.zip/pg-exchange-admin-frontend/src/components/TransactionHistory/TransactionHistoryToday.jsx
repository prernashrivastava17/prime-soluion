import React, { useState, useEffect, useMemo } from "react";
import {
  ArrowUpRight,
  Search,
  ChevronLeft,
  ChevronRight,
  Download,
  RefreshCw,
} from "lucide-react";
import {
  Table,
  Button,
  Select,
  Input,
  Card,
  Space,
  Tag,
  Spin,
  message,
} from "antd";
import * as XLSX from "xlsx";
import toast from "react-hot-toast";

const { Option } = Select;

const TransactionHistoryToday = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [buyAssets, setBuyAssets] = useState(true);

  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");

  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);

  // =========================
  // Fetch Transactions
  // =========================
  const fetchTransactionData = async (isBuy) => {
    setLoading(true);
    try {
      const response = await fetch("/api/admin/get-txn-byToday", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ buyAssets: isBuy }),
      });

      if (!response.ok) throw new Error("API Error");

      const result = await response.json();

      if (result?.data) {
        setData(result.data);
        toast.success("Transactions loaded");
      } else {
        setData([]);
      }
    } catch (err) {
      console.error(err);
      message.error("Failed to fetch transactions");
      setData([]);
    } finally {
      setLoading(false);
    }
  };

  // Load Buy History by default
  useEffect(() => {
    fetchTransactionData(true);
  }, []);

  // =========================
  // Filters
  // =========================
  const filteredData = useMemo(() => {
    return data.filter((t) => {
      const search =
        t.transactionId?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        t.currency?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        t.status?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        t.name?.toLowerCase().includes(searchTerm.toLowerCase());

      const statusMatch = statusFilter === "all" || t.status === statusFilter;

      const typeMatch =
        typeFilter === "all" || t.transactionType === typeFilter;
      return search && statusMatch && typeMatch;
    });
  }, [data, searchTerm, statusFilter, typeFilter]);

  // =========================
  // Pagination
  // =========================
  const totalPages = Math.ceil(filteredData.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const currentItems = filteredData.slice(startIndex, endIndex);

  const goToPage = (page) => {
    setCurrentPage(Math.max(1, Math.min(page, totalPages)));
  };

  // =========================
  // Export Excel
  // =========================
  const exportToExcel = () => {
    const worksheet = XLSX.utils.json_to_sheet(
      filteredData.map((t) => ({
        "Transaction ID": t.transactionId,
        Date: new Date(t.createdAt).toLocaleString(),
        Type: t.transactionType,
        User: t.name,
        Currency: t.currency,
        Amount: t.amount,
        Fee: t.fee,
        Status: t.status,
        Chain: t.chain,
        Network: t.network,
      }))
    );

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Transactions");
    XLSX.writeFile(workbook, "transactions.xlsx");
    message.success("Excel downloaded");
  };

  // =========================
  // Table Columns
  // =========================
  const columns = [
    {
      title: "Date",
      dataIndex: "createdAt",
      render: (d) => new Date(d).toLocaleString(),
      width: 170,
    },
    {
      title: "Transaction ID",
      dataIndex: "transactionId",
      render: (id) => (
        <span
          className="font-mono text-xs cursor-pointer"
          onClick={() => {
            navigator.clipboard.writeText(id);
            message.success("Copied");
          }}
        >
          {id}
        </span>
      ),
      width: 160,
    },
    {
      title: "User",
      dataIndex: "name",
      width: 120,
    },
    {
      title: "Type",
      dataIndex: "transactionType",
      render: (type) => (
        <Tag color={type === "buy" ? "green" : "orange"}>
          {type?.toUpperCase()}
        </Tag>
      ),
      width: 110,
    },
    {
      title: "Currency",
      dataIndex: "currency",
      width: 100,
    },
    {
      title: "Amount",
      dataIndex: "amount",
      render: (a) => `₹ ${a}`,
      width: 120,
    },
    {
      title: "Fee",
      dataIndex: "fee",
      render: (f) => f?.toFixed(4),
      width: 100,
    },
    {
      title: "Status",
      dataIndex: "status",
      render: (s) => (
        <Tag
          color={
            s === "success" || s === "completed"
              ? "green"
              : s === "pending"
              ? "orange"
              : "red"
          }
        >
          {s?.toUpperCase()}
        </Tag>
      ),
      width: 120,
    },
    {
      title: "Chain",
      dataIndex: "chain",
      width: 100,
    },
  ];

  // =========================
  // UI
  // =========================
  return (
    <div className=" bg-gray-50 min-h-screen">
      <Card className="shadow-lg rounded-xl">
        {/* Header */}
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center gap-3">
            <div className="bg-indigo-600 p-2 rounded-lg">
              <ArrowUpRight className="text-white" />
            </div>
            <h2 className="text-xl font-bold">Today's Transaction</h2>
          </div>

          <Space>
            <Button
              icon={<RefreshCw />}
              onClick={() => fetchTransactionData(buyAssets)}
            >
              Refresh
            </Button>
            <Button type="primary" icon={<Download />} onClick={exportToExcel}>
              Export Excel
            </Button>
          </Space>
        </div>

        {/* Buy / Withdraw Toggle */}
        <Space className="mb-4">
          <Button
            type={buyAssets ? "primary" : "default"}
            onClick={() => {
              setBuyAssets(true);
              fetchTransactionData(true);
            }}
          >
            Buy History
          </Button>
          <Button
            type={!buyAssets ? "primary" : "default"}
            onClick={() => {
              setBuyAssets(false);
              fetchTransactionData(false);
            }}
          >
            Withdraw History
          </Button>
        </Space>

        {/* Filters */}
        <div className="flex gap-3 mb-4">
          <Input
            placeholder="Search transaction, user, status..."
            prefix={<Search />}
            value={searchTerm}
            onChange={(e) => {
              setSearchTerm(e.target.value);
              setCurrentPage(1);
            }}
            style={{ width: 280 }}
          />

          <Select
            value={statusFilter}
            onChange={setStatusFilter}
            style={{ width: 150 }}
          >
            <Option value="all">All Status</Option>
            <Option value="success">Success</Option>
            <Option value="pending">Pending</Option>
            <Option value="failed">Failed</Option>
          </Select>
        </div>

        {/* Table */}
        <Spin spinning={loading}>
          <Table
            columns={columns}
            dataSource={currentItems}
            rowKey="transactionId"
            pagination={false}
            scroll={{ x: 1000 }}
          />
        </Spin>

        {/* Pagination */}
        {filteredData.length > 0 && (
          <div className="flex justify-between items-center mt-4">
            <span>
              Showing {startIndex + 1}-{Math.min(endIndex, filteredData.length)}{" "}
              of {filteredData.length}
            </span>

            <Space>
              <Button
                onClick={() => goToPage(currentPage - 1)}
                disabled={currentPage === 1}
              >
                <ChevronLeft />
              </Button>
              <span>{currentPage}</span>
              <Button
                onClick={() => goToPage(currentPage + 1)}
                disabled={currentPage === totalPages}
              >
                <ChevronRight />
              </Button>

              <Select
                value={itemsPerPage}
                onChange={(v) => {
                  setItemsPerPage(v);
                  setCurrentPage(1);
                }}
                style={{ width: 120 }}
              >
                <Option value={10}>10</Option>
                <Option value={20}>20</Option>
                <Option value={50}>50</Option>
              </Select>
            </Space>
          </div>
        )}
      </Card>
    </div>
  );
};

export default TransactionHistoryToday;
