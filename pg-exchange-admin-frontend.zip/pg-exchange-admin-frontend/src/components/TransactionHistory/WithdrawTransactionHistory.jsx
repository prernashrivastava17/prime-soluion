import React, { useState, useMemo, useEffect } from "react";
import {
  ArrowUpRight,
  Search,
  ChevronLeft,
  ChevronRight,
  Download,
  RefreshCw,
} from "lucide-react";
import {
  Table,
  Button,
  Select,
  Input,
  Card,
  Statistic,
  Row,
  Col,
  Tag,
  Space,
  message,
  Spin,
} from "antd";
import * as XLSX from "xlsx";
import toast from "react-hot-toast";
import axios from "axios";

const { Option } = Select;

const WithdrawTransactionHistory = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);

  // Token icons data
  const tokens = [
    { symbol: "BTC", icon: "₿", name: "Bitcoin", color: "text-orange-500" },
    { symbol: "ETH", icon: "Ξ", name: "Ethereum", color: "text-purple-500" },
    { symbol: "MATIC", icon: "🔷", name: "Polygon", color: "text-blue-500" },
    { symbol: "BNB", icon: "🟡", name: "Binance Coin", color: "text-yellow-500" },
    { symbol: "ABIX", icon: "⚡", name: "Abix", color: "text-green-500" },
    { symbol: "USD", icon: "$", name: "US Dollar", color: "text-gray-500" },
    { symbol: "USDT", icon: "💵", name: "Tether", color: "text-green-400" },
    { symbol: "PGL", icon: "🔶", name: "PGL", color: "text-blue-400" },
  ];

  // Fetch WITHDRAW transaction data
  useEffect(() => {
    const fetchTransactionData = async () => {
      setLoading(true);
      try {
        const response = await fetch("/api/admin/get-withdraw-txn-data", {
          method: "GET",
          headers: { "Content-Type": "application/json" },
        });

        if (!response.ok) {
          throw new Error("Failed to fetch transaction data");
        }

        const result = await response.json();

        if (response?.ok && result?.data) {
            console.log("result---",result.data)
          setData(
            result.data.filter(
              (txn) => txn.transactionType === "withdraw"
            )
          );
          message.success("Withdraw transactions loaded successfully");
        } else {
          throw new Error("No withdraw transaction data found");
        }
      } catch (error) {
        console.error("Error fetching withdraw transactions:", error);
        message.error("Failed to load withdraw transactions");
        setData([]);
      } finally {
        setLoading(false);
      }
    };

    fetchTransactionData();
  }, []);

  // Refresh data
  const refreshData = async () => {
    setLoading(true);
    try {
      const response = await fetch("/api/admin/get-txn-history");
      const result = await response.json();

      if (result?.success && result?.allTxns) {
        setData(
          result.allTxns.filter(
            (txn) => txn.transactionType === "withdraw"
          )
        );
        toast.success("Withdraw data refreshed");
      }
    } catch (error) {
      console.error("Refresh error:", error);
      toast.error("Failed to refresh data");
    } finally {
      setLoading(false);
    }
  };

  // Search + status filter
  const filteredData = useMemo(() => {
    return data.filter((transaction) => {
      const matchesSearch =
        transaction.currency?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        transaction.transactionId?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        transaction.status?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        transaction.toAddress?.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesStatus =
        statusFilter === "all" || transaction.status === statusFilter;

      return matchesSearch && matchesStatus;
    });
  }, [data, searchTerm, statusFilter]);

  // Pagination
  const totalPages = Math.ceil(filteredData.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const currentItems = filteredData.slice(startIndex, endIndex);

  const goToPage = (page) => {
    setCurrentPage(Math.max(1, Math.min(page, totalPages)));
  };

  // Stats
  const stats = useMemo(
    () => ({
      total: data.length,
      completed: data.filter(
        (t) => t.status === "completed" || t.status === "success"
      ).length,
      pending: data.filter((t) => t.status === "pending").length,
      failed: data.filter((t) => t.status === "failed").length,
      totalVolume: data.reduce(
        (sum, t) => sum + (parseFloat(t.amount) || 0),
        0
      ),
    }),
    [data]
  );

  // Export to Excel
  const exportToExcel = () => {
    const worksheet = XLSX.utils.json_to_sheet(
      filteredData.map((item) => ({
        "Transaction ID": item.transactionId,
        Date: new Date(item.createdAt).toLocaleString(),
        Currency: item.currency,
        Amount: item.amount,
        Fee: item.fee,
        Status: item.status,
        "To Address": item.toAddress,
        "User ID": item.userId,
      }))
    );

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Withdraw Transactions");
    XLSX.writeFile(
      workbook,
      `withdraw_transactions_${new Date().toISOString().split("T")[0]}.xlsx`
    );
    message.success("Excel downloaded successfully");
  };

  // Table columns
  // Table columns
const columns = [
  {
    title: "Date",
    dataIndex: "createdAt",
    render: (date) => new Date(date).toLocaleString(),
    width: 180,
  },
  {
    title: "Transaction Type",
    dataIndex: "transactionType",
    width: 140,
    render: (type) => <span className="capitalize">{type}</span>,
  },
  {
    title: "User ID",
    dataIndex: "userId",
    width: 120,
  },
  {
    title: "Currency",
    dataIndex: "currency",
    render: (currency) => {
      const token = tokens.find((t) => t.symbol === currency);
      return (
        <Space>
          <span className={token?.color}>{token?.icon}</span>
          {currency}
        </Space>
      );
    },
    width: 120,
  },
  {
    title: "Amount",
    dataIndex: "amount",
    render: (amount) => `₹ ${Number(amount).toLocaleString()}`,
    width: 130,
  },
  {
    title: "Chain",
    dataIndex: "chain",
    width: 100,
  },
  {
    title: "Network",
    dataIndex: "network",
    width: 120,
  },
  {
    title: "Token",
    dataIndex: "token",
    width: 100,
  },
  {
    title: "To Address",
    dataIndex: "toAddress",
    render: (address) => (
      <span
        className="font-mono text-xs cursor-pointer"
        onClick={() => {
          navigator.clipboard.writeText(address);
          message.success("To Address copied");
        }}
      >
        {address}
      </span>
    ),
    width: 180,
  },
  {
    title: "Wallet Address",
    dataIndex: "walletAddress",
    render: (address) => (
      <span
        className="font-mono text-xs cursor-pointer"
        onClick={() => {
          navigator.clipboard.writeText(address);
          message.success("Wallet Address copied");
        }}
      >
        {address}
      </span>
    ),
    width: 180,
  },
  {
    title: "Status",
    dataIndex: "status",
    render: (status) => (
      <Tag
        color={
          status === "completed" || status === "success"
            ? "green"
            : status === "pending"
            ? "orange"
            : "red"
        }
      >
        {status?.toUpperCase()}
      </Tag>
    ),
    width: 120,
  },
  {
    title: "Transaction ID",
    dataIndex: "transactionId",
    render: (id) => (
      <span
        className="font-mono text-xs cursor-pointer"
        onClick={() => {
          navigator.clipboard.writeText(id);
          message.success("Transaction ID copied");
        }}
      >
        {id}
      </span>
    ),
    width: 160,
  },
 {
  title: "TxHash",
  dataIndex: "txHash",
  width: 180,
  render: (text, record) => (
    <Input
      placeholder={text}
      style={{ width: 250 }}  // increased height
      onChange={(e) => {
        record.txHash = e.target.value;
      }}
    />
  ),
},
{
  title: "Remark",
  dataIndex: "remark",
  width: 200,
  render: (text, record) => (
    <Input
      placeholder={text}
      style={{ width: 250 }}  // increased height
      onChange={(e) => {
        record.remark = e.target.value;
      }}
    />
  ),
},

  {
    title: "Action",
    dataIndex: "action",
    width: 200,
    render: (_, record) => (
      <Space>
        <Button
          type="primary"
          size="small"
          onClick={async () => {
            if(record.remark === "Pending for approval"){
              toast.error("Enter the Remark")
               return false;
            }
            if(record.txHash === "n/a"){
              toast.error("Enter the transaction Hash")
              return false;
            }

            try {
              const response = await axios.post(
                "/api/admin/withdraw-txns-action",
                {
                  txnId: record.transactionId,
                  txHash: record.txHash,
                  remark: record.remark,
                  action:"approve"
                }
              );

           console.log("data----",response)

              if (response.status === 200){
                toast.success(`Transaction ${record.transactionId} approved!`);
                refreshData();
              } else {
                toast.error(response.data.message)
                message.error(response.data.message || "Failed to approve transaction");
              }
            } catch (error) {
              console.error("Approve error:", error);
              toast.error("Something went wrong while approving");
            }
          }}
        >
          Approve 
        </Button>

        <Button
          type="primary"
          danger
          size="small"
          onClick={async () => {                                                 
             if(record.remark === "Pending for approval"){
              toast.error("Enter the Remark")
               return false;
            }
            if(record.txHash === "n/a"){
              toast.error("Enter the transaction Hash")
              return false;
            }
            try {
              console.log("reject");
              const { data: result } = await axios.post(
                "/api/admin/withdraw-txns-action",
                {
                  txnId: record.transactionId,
                  txHash: record.txHash,
                  remark: record.remark,
                   action:"reject"  
                }
              );
              console.log("data---",result)
              if (result) {
                toast.success(`Transaction ${record.transactionId} rejected!`);
                refreshData();
              } else {
                toast.error(result.message || "Failed to reject transaction");
              }
            } catch (error) {
              console.error("Reject error:", error);
              toast.error("Something went wrong while rejecting");
            }
          }}
        >
          Reject
        </Button>
      </Space>
    ),
  },
];


  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <Card>
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold">
            Withdraw Transaction History
          </h1>
          <Space>
            <Button icon={<RefreshCw />} onClick={refreshData}>
              Refresh
            </Button>
            <Button type="primary" icon={<Download />} onClick={exportToExcel}>
              Export
            </Button>
          </Space>
        </div>

        <Row gutter={16} className="mb-6">
          <Col span={6}>
            <Statistic title="Total Withdrawals" value={stats.total} />
          </Col>
          <Col span={6}>
            <Statistic title="Completed" value={stats.completed} />
          </Col>
          <Col span={6}>
            <Statistic title="Pending" value={stats.pending} />
          </Col>
          <Col span={6}>
            <Statistic title="Failed" value={stats.failed} />
          </Col>
        </Row>

        <Space className="mb-4">
          <Input
            placeholder="Search transactions..."
            prefix={<Search />}
            value={searchTerm}
            onChange={(e) => {
              setSearchTerm(e.target.value);
              setCurrentPage(1);
            }}
          />

          <Select
            value={statusFilter}
            onChange={(value) => {
              setStatusFilter(value);
              setCurrentPage(1);
            }}
            style={{ width: 150 }}
          >
            <Option value="all">All Status</Option>
            <Option value="completed">Completed</Option>
            <Option value="success">Success</Option>
            <Option value="pending">Pending</Option>
            <Option value="failed">Failed</Option>
          </Select>
        </Space>

        <Spin spinning={loading}>
          <Table
            columns={columns}
            dataSource={currentItems}
            rowKey="_id"
            pagination={false}
            scroll={{ x: 1100 }}
          />
        </Spin>

        <div className="flex justify-between items-center mt-6">
          <div>
            Showing {startIndex + 1}–
            {Math.min(endIndex, filteredData.length)} of{" "}
            {filteredData.length}
          </div>

          <Space>
            <Button
              disabled={currentPage === 1}
              onClick={() => goToPage(currentPage - 1)}
              icon={<ChevronLeft />}
            />
            <Button
              disabled={currentPage === totalPages}
              onClick={() => goToPage(currentPage + 1)}
              icon={<ChevronRight />}
            />
            <Select
              value={itemsPerPage}
              onChange={(value) => {
                setItemsPerPage(value);
                setCurrentPage(1);
              }}
              style={{ width: 120 }}
            >
              <Option value={10}>10</Option>
              <Option value={20}>20</Option>
              <Option value={50}>50</Option>
              <Option value={100}>100</Option>
            </Select>
          </Space>
        </div>
      </Card>
    </div>
  );
};

export default WithdrawTransactionHistory;
