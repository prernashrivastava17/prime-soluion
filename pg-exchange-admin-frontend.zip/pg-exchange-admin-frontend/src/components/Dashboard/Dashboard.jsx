import React, { useState, useRef, useEffect } from "react";
import { Coins, Sparkles, LogOut, RefreshCw, Menu, X } from "lucide-react";
import { useNavigate } from "react-router-dom";

// Import components
import BalanceCards from "./BalanceCards";

// Import token data and icons
import tron from "../../assets/svg/tron.svg";
import bix from "../../assets/svg/bix.svg";
import matic from "../../assets/svg/matic.svg";
import { LiaEthereum } from "react-icons/lia";
import { SiBinance, SiTether } from "react-icons/si";
import { GiCircleCage } from "react-icons/gi";
import { fetchApi } from "../../assets/js/function";
import TransactionHistoryToday from "../TransactionHistory/TransactionHistoryToday";

const initialTokens = [
  {
    id: 2,
    name: "Ethereum",
    symbol: "ETH",
    token_standard: "ERC-20",
    price: 3000,
    available: true,
    change: 1.8,
    color: "from-purple-500 to-blue-500",
    icon: <LiaEthereum className="text-2xl" style={{ color: "black" }} />,
    networks: ["ERC-20 Ethereum"],
  },
  {
    id: 10,
    name: "Tron",
    symbol: "TRX",
    token_standard: "TRC-20",
    price: 0.12,
    available: true,
    change: -1.2,
    color: "from-red-500 to-orange-500",
    icon: (
      <div className="text-2xl">
        <img src={tron} alt="Tron" className="w-6 h-6" />
      </div>
    ),
    networks: ["TRON"],
  },
  {
    id: 5,
    name: "Polygon",
    symbol: "PGL",
    token_standard: "POLYGON",
    price: 1.2,
    available: true,
    change: 4.1,
    color: "from-purple-600 to-pink-500",
    icon: <GiCircleCage className="text-2xl text-purple-500" />,
    networks: ["POLYGON"],
  },
  {
    id: 7,
    name: "Binance Coin",
    symbol: "BNB",
    token_standard: "BEP-20",
    price: 350,
    available: true,
    change: 2.3,
    color: "from-yellow-500 to-orange-500",
    icon: <SiBinance className="text-2xl text-yellow-500" />,
    networks: ["BEP-20 Binance"],
  },
  {
    id: 8,
    name: "Matic",
    symbol: "MATIC",
    token_standard: "POLYGON",
    price: 0.85,
    available: true,
    change: 5.7,
    color: "from-blue-400 to-purple-400",
    icon: (
      <div className="text-2xl">
        <img src={matic} className="w-6 h-6" alt="Matic" />
      </div>
    ),
    networks: ["POLYGON"],
  },
  {
    id: 9,
    name: "Abix",
    symbol: "ABIX",
    price: 0.25,
    available: true,
    change: 12.5,
    color: "from-green-500 to-teal-500",
    icon: (
      <div className="text-2xl">
        <img src={bix} alt="Abix" className="w-6 h-6" />
      </div>
    ),
    networks: ["AVALANCHE"],
  },
  {
    id: 11,
    name: "Tether",
    symbol: "USDT",
    token_standard: ["ERC-20", "TRC-20"],
    price: 1.0,
    available: true,
    change: 0.1,
    color: "from-green-400 to-emerald-500",
    icon: <SiTether className="text-2xl text-green-500" />,
    networks: ["ERC-20", "TRC-20"],
  },
];

export default function Dashboard() {
  const [balances, setBalances] = useState({
    evmData: {},
    tronData: {},
    pglData: {},
  });
  const [updateBalances, setUpdateBalances] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navigate = useNavigate();
  const dropdownRef = useRef(null);
  const user = JSON.parse(localStorage.getItem("adminData"));
  useEffect(() => {
    function handleClickOutside(event) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        closeAllDropdowns();
      }
    }

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const [tokens] = useState(initialTokens);

  // Centralized dropdown state management
  const [dropdownStates, setDropdownStates] = useState({
    assetDropdown: false,
    buyCryptoDropdown: false,
    buyNetworkDropdown: false,
    transferCryptoDropdown: false,
    transferNetworkDropdown: false,
  });

  // QR Payment Modal State
  const [showQRPayment, setShowQRPayment] = useState(false);
  const [qrPaymentData, setQrPaymentData] = useState(null);
  const [isProcessingPayment, setIsProcessingPayment] = useState(false);

  // Helper functions to manage dropdowns
  const closeAllDropdowns = () => {
    setDropdownStates({
      assetDropdown: false,
      buyCryptoDropdown: false,
      buyNetworkDropdown: false,
      transferCryptoDropdown: false,
      transferNetworkDropdown: false,
    });
  };

  const [transactionMessage, setTransactionMessage] = useState("");

  const handleLogout = () => {
    localStorage.removeItem("adminData");
    navigate("/");
  };

  const refreshBalances = () => {
    setUpdateBalances((prev) => !prev);
  };

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  return (
    <div
      className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-cyan-50 p-4 md:p-6"
      ref={dropdownRef}
    >
      <div className="max-w-7xl mx-auto">
        {/* Header - Made Responsive */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6 md:mb-8">
          {/* Left Section - Logo and Title */}
          <div className="flex items-center justify-between w-full md:w-auto">
            <div className="flex items-center gap-3 md:gap-4">
              <div className="bg-gradient-to-r from-blue-700 to-cyan-500 p-2 md:p-3 rounded-xl md:rounded-2xl shadow-lg md:shadow-2xl relative">
                <Coins className="w-6 h-6 md:w-8 md:h-8 text-white" />
                <div className="absolute -top-1 -right-1 w-2 h-2 md:w-3 md:h-3 bg-green-400 rounded-full border-2 border-white"></div>
              </div>
              <div>
                <h1 className="text-xl md:text-2xl lg:text-3xl font-bold bg-gradient-to-r from-blue-700 to-cyan-500 bg-clip-text text-transparent">
                  Token Exchange
                </h1>
                <p className="text-gray-600 text-xs md:text-sm flex items-center gap-1">
                  <Sparkles className="w-3 h-3 md:w-4 md:h-4 text-yellow-500" />
                  <span className="hidden sm:inline">
                    Professional Trading Platform
                  </span>
                  <span className="sm:hidden">Trading Platform</span>
                </p>
              </div>
            </div>

            {/* Mobile Menu Toggle Button */}
            <button
              onClick={toggleMobileMenu}
              className="md:hidden flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-r from-blue-500 to-cyan-600 text-white shadow-lg hover:shadow-xl transition-all"
              aria-label="Toggle menu"
            >
              {isMobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>

          {/* Right Section - Action Buttons */}
          <div
            className={`
            flex flex-col md:flex-row items-stretch md:items-center gap-2 md:gap-3 
            w-full md:w-auto 
            transition-all duration-300 ease-in-out
            ${
              isMobileMenuOpen
                ? "max-h-64 opacity-100"
                : "max-h-0 opacity-0 md:max-h-full md:opacity-100 overflow-hidden md:overflow-visible"
            }
          `}
          >
            <button
              onClick={refreshBalances}
              disabled={isLoading}
              className="flex items-center justify-center gap-2 bg-gradient-to-r from-blue-500 to-cyan-600 hover:from-blue-600 hover:to-cyan-700 text-white px-4 py-2 md:py-3 rounded-xl transition-all font-semibold shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed text-sm md:text-base w-full md:w-auto"
            >
              <RefreshCw
                className={`w-4 h-4 ${isLoading ? "animate-spin" : ""}`}
              />
              <span className="whitespace-nowrap">
                {isLoading ? "Refreshing..." : "Refresh Balances"}
              </span>
            </button>
            <button
              onClick={handleLogout}
              className="flex items-center justify-center gap-2 bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white px-4 md:px-6 py-2 md:py-3 rounded-xl transition-all font-semibold shadow-lg hover:shadow-xl transform hover:scale-105 text-sm md:text-base w-full md:w-auto"
            >
              <LogOut className="w-4 h-4 md:w-5 md:h-5" />
              <span className="whitespace-nowrap">Logout</span>
            </button>
          </div>
        </div>

        {/* Success Message */}
        {transactionMessage && (
          <div className="bg-gradient-to-r from-green-500 to-emerald-600 text-white p-3 md:p-4 rounded-xl md:rounded-2xl mb-4 md:mb-6 flex items-center gap-3 border border-green-300">
            <div className="bg-white/20 p-1 md:p-2 rounded-lg">
              <Coins className="w-4 h-4 md:w-5 md:h-5" />
            </div>
            <span className="font-semibold text-sm md:text-base">
              {transactionMessage}
            </span>
          </div>
        )}

        {/* Loading State */}
        {/* {isLoading && (
          <div className="bg-gradient-to-r from-blue-500 to-cyan-600 text-white p-3 md:p-4 rounded-xl md:rounded-2xl mb-4 md:mb-6 flex items-center gap-3">
            <div className="animate-spin rounded-full h-5 w-5 md:h-6 md:w-6 border-b-2 border-white"></div>
            <span className="font-semibold text-sm md:text-base">
              Loading balances...
            </span>
          </div>
        )}*/}

        {/* Main Content */}
        <div className="flex flex-col lg:flex-row gap-4 md:gap-6 mb-4">
          <BalanceCards
            data={balances}
            isLoading={isLoading}
            setIsLoading={setIsLoading}
          />
        </div>
        <TransactionHistoryToday />
      </div>
    </div>
  );
}
