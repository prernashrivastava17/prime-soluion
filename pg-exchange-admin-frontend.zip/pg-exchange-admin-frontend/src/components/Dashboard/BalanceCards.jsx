import React, { useState, useRef, useEffect } from "react";
import {
  DollarSign,
  Activity,
  TrendingUp,
  Zap,
  ChevronDown,
  IndianRupee,
} from "lucide-react";

// Import token data and icons
import { GiCircleCage } from "react-icons/gi";
import { SiTether } from "react-icons/si";
import { fetchApi } from "../../assets/js/function";
import toast from "react-hot-toast";

export default function BalanceCards({ data, setIsLoading }) {
  const initialTokens = [
    {
      id: 5,
      name: "Polygon",
      symbol: "PGL",
      token_standard: "POLYGON",
      price: 1.2,
      balance: data?.pglData?.balance || 0,
      available: true,
      change: 4.1,
      color: "from-purple-600 to-pink-500",
      icon: <GiCircleCage className="text-2xl text-purple-500" />,
      networks: ["POLYGON"],
    },
    {
      id: 12,
      name: "Tether",
      symbol: "USDT EVM",
      token_standard: ["ERC-20", "TRC-20"],
      price: 1.0,
      balance: data?.evmData?.balance || 0,
      available: true,
      change: 0.1,
      color: "from-green-400 to-emerald-500",
      icon: <SiTether className="text-2xl text-green-500" />,
      networks: ["ERC-20", "TRC-20"],
    },
    {
      id: 11,
      name: "Tether",
      symbol: "USDT TRON",
      token_standard: ["ERC-20", "TRC-20"],
      price: 1.0,
      balance: data?.tronData?.balance || 0,
      available: true,
      change: 0.1,
      color: "from-green-400 to-emerald-500",
      icon: <SiTether className="text-2xl text-green-500" />,
      networks: ["ERC-20", "TRC-20"],
    },
  ];

  // Local state for tokens
  const [tokens, setTokens] = useState(initialTokens);

  // Local state for selected asset token
  const [selectedAssetToken, setSelectedAssetToken] = useState("PGL");

  // Local state for dropdown
  const [assetDropdownOpen, setAssetDropdownOpen] = useState(false);
  const [isBalanceLoading, setIsBalanceLoading] = useState(false);
  const [adminData, setAdminData] = useState({
    balance: 0,
    transactions: [],
    email: "",
  });
  const [fee, setFee] = useState(0);

  // Ref for click outside detection
  const dropdownRef = useRef(null);

  // Update tokens when data changes
  useEffect(() => {
    const updatedTokens = initialTokens.map((token) => ({
      ...token,
      balance:
        data?.[
          token.symbol === "PGL"
            ? "pglData"
            : token.symbol === "USDT EVM"
            ? "evmData"
            : "tronData"
        ]?.balance || 0,
    }));
    setTokens(updatedTokens);
  }, [data]);

  // Click outside handler
  useEffect(() => {
    function handleClickOutside(event) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setAssetDropdownOpen(false);
      }
    }

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  // Local function to calculate asset value
  const calculateAssetValue = () => {
    const selectedTokenData = tokens.find(
      (token) => token.symbol === selectedAssetToken
    );
    if (!selectedTokenData) return "0.00";
    return (selectedTokenData?.balance || 0).toFixed(2);
  };

  // Local function to toggle dropdown
  const toggleAssetDropdown = () => {
    setAssetDropdownOpen(!assetDropdownOpen);
  };

  // Local function to select token and close dropdown
  const handleTokenSelect = (tokenSymbol) => {
    setSelectedAssetToken(tokenSymbol);
    setAssetDropdownOpen(false);
  };

  // Fetch admin data
  useEffect(() => {
    let isMounted = true;

    const fetchBalance = async () => {
      try {
        setIsBalanceLoading(true);

        const response = await fetch("/api/admin/get-admin-data", {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
          },
        });

        if (!response.ok) {
          throw new Error("Failed to fetch admin data");
        }

        const result = await response.json();
        console.log("Balance API result:", result);

        if (isMounted && result?.success) {
          setAdminData((prev) => ({
            ...prev,
            balance: result.balance || 0,
            transactions: result.transactions || [],
            email: result.email,
          }));
          setFee(result.fees || 0);
        }
      } catch (error) {
        console.error("Error fetching balance:", error);
      } finally {
        if (isMounted) {
          setIsBalanceLoading(false);
          setIsLoading(false);
        }
      }
    };

    fetchBalance();

    return () => {
      isMounted = false;
    };
  }, []);

  // Handle fee update
  const handleFeeUpdate = async () => {
    if (!fee || isNaN(fee) || parseFloat(fee) < 0) {
      alert("Please enter a valid fee amount");
      return;
    }

    try {
      setIsBalanceLoading(true);
      setIsLoading(true);
      // Add your fee update API call here
      console.log("Updating fee to:", fee);
      // await updateFeeAPI(fee);
      const [response, result] = await fetchApi(
        "admin/set-fees",
        {
          email: adminData?.email,
          fees: fee,
        },
        "POST"
      );

      if (result.success) {
        toast.success(result.message);
        setFee(result.data.fees);
      }
    } catch (error) {
      console.error("Error updating fee:", error);
      alert("Failed to update fee");
    } finally {
      setIsBalanceLoading(false);
      setIsLoading(false);
    }
  };

  // Handle fee input change
  const handleFeeChange = (e) => {
    const value = e.target.value;
    // Allow only numbers and decimal point
    if (value === "" || /^\d*\.?\d*$/.test(value)) {
      setFee(value);
    }
  };

  if (isBalanceLoading) {
    return (
      <div className="flex gap-5">
        {/* USD Balance Skeleton */}
        <div className="w-[300px] bg-gradient-to-br from-emerald-500 to-green-600 rounded-2xl p-6 text-white">
          <div className="animate-pulse">
            <div className="h-4 bg-emerald-400 rounded w-1/2 mb-4"></div>
            <div className="h-8 bg-emerald-400 rounded w-3/4 mb-2"></div>
            <div className="h-3 bg-emerald-400 rounded w-1/3"></div>
          </div>
        </div>

        {/* Token Balance Skeleton */}
        <div className="w-[300px] bg-gradient-to-br from-purple-500 to-indigo-600 rounded-2xl p-6 text-white">
          <div className="animate-pulse">
            <div className="h-4 bg-purple-400 rounded w-1/2 mb-4"></div>
            <div className="h-8 bg-purple-400 rounded w-3/4 mb-2"></div>
            <div className="h-3 bg-purple-400 rounded w-1/3"></div>
          </div>
        </div>

        {/* Fee Card Skeleton */}
        <div className="w-[450px] bg-gradient-to-br from-emerald-500 to-green-600 rounded-2xl p-6 text-white">
          <div className="animate-pulse">
            <div className="h-4 bg-emerald-400 rounded w-1/2 mb-4"></div>
            <div className="h-10 bg-emerald-400 rounded w-full mb-2"></div>
            <div className="h-3 bg-emerald-400 rounded w-1/3"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex gap-5" ref={dropdownRef}>
      {/* USD Balance */}
      <div className="w-[300px] bg-gradient-to-br from-emerald-500 to-green-600 rounded-2xl p-6 text-white hover:shadow-2xl transition-all duration-300 transform hover:scale-105 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-20 h-20 bg-white/10 rounded-full -mr-6 -mt-6"></div>
        <div className="flex items-center justify-between mb-2">
          <p className="text-emerald-100 text-sm font-semibold">
            Available Balance
          </p>
          <div className="bg-white/20 p-2 rounded-lg">
            <DollarSign className="w-5 h-5 text-emerald-200" />
          </div>
        </div>
        <p className="text-4xl font-bold">
          ${adminData?.balance?.toLocaleString() || "0"}
        </p>
        <p className="text-emerald-100 text-xs mt-2 flex items-center gap-1">
          <TrendingUp className="w-3 h-3" />
          Ready to invest
        </p>
      </div>

      {/* Token Balance */}
      <div className="w-[300px] bg-gradient-to-br from-purple-500 to-indigo-600 rounded-2xl px-6 py-4 text-white shadow-2xl hover:shadow-2xl transition-all duration-300 transform hover:scale-105 relative">
        <div className="absolute top-0 right-0 w-20 h-20 bg-white/10 rounded-full -mr-6 -mt-6"></div>
        <div className="flex items-center justify-between mb-2">
          <p className="text-purple-100 text-sm font-semibold">
            Available Assets
          </p>
          <div className="bg-white/20 p-2 rounded-lg">
            <Activity className="w-5 h-5 text-purple-200" />
          </div>
        </div>

        {/* Dropdown for token selection */}
        <div className="relative mb-3">
          <button
            onClick={toggleAssetDropdown}
            className="w-full bg-white/20 hover:bg-white/30 transition-all duration-200 rounded-xl p-2 flex items-center justify-between text-white font-semibold"
          >
            <span className="flex items-center gap-2">
              {tokens.find((t) => t.symbol === selectedAssetToken)?.icon}
              {selectedAssetToken}
            </span>
            <ChevronDown
              className={`w-4 h-4 transition-transform ${
                assetDropdownOpen ? "rotate-180" : ""
              }`}
            />
          </button>

          {assetDropdownOpen && (
            <div className="absolute top-full left-0 right-0 mt-2 bg-white/95 backdrop-blur-sm rounded-2xl shadow-2xl border border-white/20 z-10 max-h-[210px] overflow-y-auto">
              {tokens.map((token) => (
                <button
                  key={token.id}
                  onClick={() => handleTokenSelect(token.symbol)}
                  className={`w-full p-3 text-left hover:bg-white/30 transition-all duration-200 flex items-center gap-3 ${
                    selectedAssetToken === token.symbol ? "bg-white/30" : ""
                  }`}
                >
                  {token.icon}
                  <div className="flex-1">
                    <div className="font-semibold text-gray-800">
                      {token.symbol}
                    </div>
                    <div className="text-xs text-gray-600">{token.name}</div>
                    <div className="text-xs text-green-600 font-medium">
                      Balance: {token.balance.toFixed(2)}
                    </div>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>

        <p className="text-4xl font-bold">
          {calculateAssetValue()} {selectedAssetToken.split(" ")[0]}
        </p>
        <p className="text-purple-100 text-xs mt-2 flex items-center gap-1">
          <Zap className="w-3 h-3" />
          Portfolio value increasing
        </p>
      </div>

      {/* Set Fees Card */}
      <div className="w-[450px] bg-gradient-to-br from-emerald-500 to-green-600 rounded-2xl p-6 text-white hover:shadow-2xl transition-all duration-300 transform hover:scale-105 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-20 h-20 bg-white/10 rounded-full -mr-6 -mt-6"></div>
        <div className="flex items-center justify-between mb-2">
          <p className="text-emerald-100 text-sm font-semibold">Set Fees</p>
          <div className="bg-white/20 p-2 rounded-lg">
            <IndianRupee className="w-5 h-5 text-emerald-200" />
          </div>
        </div>
        <div className="relative overflow-hidden my-4">
          <div className="flex">
            <IndianRupee className="w-5 h-5 text-gray-600 absolute left-3 top-3" />
            <input
              type="text"
              required
              value={fee}
              onChange={handleFeeChange}
              className="w-full pl-10 pr-24 py-3 border border-gray-300 rounded-xl transition-all bg-white text-gray-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
              placeholder="Enter fee amount"
              disabled={isBalanceLoading}
            />
            <button
              type="button"
              onClick={handleFeeUpdate}
              disabled={isBalanceLoading || !fee}
              className="absolute right-0 top-0 hover:scale-105 transition-transform bg-blue-600 hover:bg-blue-700 w-20 h-full rounded-r-xl text-white font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isBalanceLoading ? "..." : "Update"}
            </button>
          </div>
        </div>
        <p className="text-emerald-100 text-xs mt-2 flex items-center gap-1">
          <TrendingUp className="w-3 h-3" />
          Current fee: {fee}%
        </p>
      </div>
    </div>
  );
}
