import React, { useState, useEffect } from "react";
import { CheckCircle, XCircle, Eye, Loader, ZoomIn } from "lucide-react";
import { fetchApi } from "../../assets/js/function";
import toast from "react-hot-toast";

export default function KYCValidationTable() {
  const [pendingKycs, setPendingKycs] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(null);
  const [selectedImage, setSelectedImage] = useState(null);
  const [showImageModal, setShowImageModal] = useState(false);

  // Fetch pending KYCs
  useEffect(() => {
    const fetchPendingKycs = async () => {
      try {
        setIsLoading(true);
        const [response, result] = await fetchApi(
          "admin/get-pending-kycs",
          {},
          "POST"
        );

        console.log("KYC API response:", result);

        if (result?.success) {
          setPendingKycs(result.data || []);
        } else {
          toast.error(result?.message || "Failed to fetch pending KYCs");
          setPendingKycs([]);
        }
      } catch (error) {
        console.error("Error fetching pending KYCs:", error);
        toast.error("Error fetching pending KYCs");
        setPendingKycs([]);
      } finally {
        setIsLoading(false);
      }
    };

    fetchPendingKycs();
  }, []);

  // Handle KYC approval
  const handleApprove = async (kycId) => {
    try {
      setActionLoading(kycId);
      const [response, result] = await fetchApi(
        `admin/approve-kyc/${kycId}`,
        {},
        "PATCH"
      );

      if (result?.success) {
        toast.success("KYC approved successfully!");
        setPendingKycs((prev) => prev.filter((kyc) => kyc._id !== kycId));
      } else {
        toast.error(result?.message || "Failed to approve KYC");
      }
    } catch (error) {
      console.error("Error approving KYC:", error);
      toast.error("Error approving KYC");
    } finally {
      setActionLoading(null);
    }
  };

  // Handle KYC rejection
  const handleReject = async (kycId) => {
    try {
      setActionLoading(kycId);
      const [response, result] = await fetchApi(
        `admin/reject-kyc/${kycId}`,
        {},
        "PATCH"
      );

      if (result?.success) {
        toast.success("KYC rejected successfully!");
        setPendingKycs((prev) => prev.filter((kyc) => kyc._id !== kycId));
      } else {
        toast.error(result?.message || "Failed to reject KYC");
      }
    } catch (error) {
      console.error("Error rejecting KYC:", error);
      toast.error("Error rejecting KYC");
    } finally {
      setActionLoading(null);
    }
  };

  // Handle image click to show in modal
  const handleImageClick = (imageUrl) => {
    setSelectedImage(imageUrl);
    setShowImageModal(true);
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString("en-IN", {
      day: "2-digit",
      month: "short",
      year: "numeric",
    });
  };

  // Small image component
  const SmallImage = ({ src, alt, onClick }) => (
    <div
      className="relative group cursor-pointer transition-transform hover:scale-105"
      onClick={onClick}
    >
      <img
        src={src}
        alt={alt}
        className="w-16 h-16 object-cover rounded-lg border border-gray-300 shadow-sm"
      />
      <div
        className="absolute inset-0 group-hover:bg-opacity-30 rounded-lg transition-opacity flex items-center justify-center"
        style={{ border: "2px solid black" }}
      >
        <ZoomIn
          className="text-white opacity-0 group-hover:opacity-100 transition-opacity"
          size={16}
        />
      </div>
    </div>
  );

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6 flex items-center justify-center">
        <div className="bg-white rounded-xl shadow-lg p-8 flex flex-col items-center">
          <Loader className="w-8 h-8 animate-spin text-blue-600 mb-4" />
          <p className="text-gray-600">Loading pending KYCs...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="bg-gradient-to-r from-blue-600 to-indigo-600 px-6 py-4">
            <h1 className="text-2xl font-bold text-white">
              Pending KYC Validations
            </h1>
            <p className="text-blue-100 text-sm mt-1">
              {pendingKycs.length} pending KYC
              {pendingKycs.length !== 1 ? "s" : ""} for review
            </p>
          </div>

          <div className="p-6">
            {pendingKycs.length === 0 ? (
              <div className="text-center py-12">
                <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-700 mb-2">
                  No Pending KYCs
                </h3>
                <p className="text-gray-500">
                  All KYC applications have been processed.
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="bg-gray-50 border-b">
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        User Details
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        KYC Details
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Documents
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Submitted On
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {pendingKycs.map((kyc) => (
                      <tr key={kyc._id} className="hover:bg-gray-50">
                        <td className="px-4 py-4">
                          <div>
                            <p className="font-medium text-gray-900">
                              {kyc.userId?.name || "N/A"}
                            </p>
                            <p className="text-sm text-gray-500">
                              {kyc.userId?.email}
                            </p>
                            <p className="text-sm text-gray-500">
                              {kyc.userId?.mobileNo}
                            </p>
                          </div>
                        </td>
                        <td className="px-4 py-4">
                          <div>
                            <p className="font-medium text-gray-900">
                              {kyc.FullName}
                            </p>
                            <p className="text-sm text-gray-500">
                              DOB: {formatDate(kyc.DoB)}
                            </p>
                            <p className="text-sm text-gray-500 capitalize">
                              Gender: {kyc.Gender}
                            </p>
                            <p className="text-sm text-gray-500">
                              KYC Mobile: {kyc.mobileNo}
                            </p>
                          </div>
                        </td>
                        <td className="px-4 py-4">
                          <div className="flex flex-wrap gap-2">
                            <div className="text-center">
                              <SmallImage
                                src={kyc.passportSizePhoto}
                                alt="Passport Photo"
                                onClick={() =>
                                  handleImageClick(kyc.passportSizePhoto)
                                }
                              />
                              <p className="text-xs text-gray-500 mt-1">
                                Photo
                              </p>
                            </div>
                            <div className="text-center">
                              <SmallImage
                                src={kyc.pancardImage}
                                alt="PAN Card"
                                onClick={() =>
                                  handleImageClick(kyc.pancardImage)
                                }
                              />
                              <p className="text-xs text-gray-500 mt-1">PAN</p>
                            </div>
                            <div className="text-center">
                              <SmallImage
                                src={kyc.aadharFrontImage}
                                alt="Aadhar Front"
                                onClick={() =>
                                  handleImageClick(kyc.aadharFrontImage)
                                }
                              />
                              <p className="text-xs text-gray-500 mt-1">
                                Aadhar F
                              </p>
                            </div>
                            <div className="text-center">
                              <SmallImage
                                src={kyc.aadharBackImage}
                                alt="Aadhar Back"
                                onClick={() =>
                                  handleImageClick(kyc.aadharBackImage)
                                }
                              />
                              <p className="text-xs text-gray-500 mt-1">
                                Aadhar B
                              </p>
                            </div>
                            <div className="text-center">
                              <SmallImage
                                src={kyc.passbookFrontImage}
                                alt="Passbook"
                                onClick={() =>
                                  handleImageClick(kyc.passbookFrontImage)
                                }
                              />
                              <p className="text-xs text-gray-500 mt-1">
                                Passbook
                              </p>
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-4 text-sm text-gray-500">
                          {formatDate(kyc.createdAt)}
                        </td>
                        <td className="px-4 py-4">
                          <div className="flex flex-col gap-2">
                            <button
                              onClick={() => handleApprove(kyc._id)}
                              disabled={actionLoading === kyc._id}
                              className="flex items-center justify-center gap-1 px-3 py-2 bg-green-600 text-white hover:bg-green-700 disabled:bg-green-300 rounded-lg transition-colors text-sm"
                            >
                              {actionLoading === kyc._id ? (
                                <Loader size={14} className="animate-spin" />
                              ) : (
                                <CheckCircle size={14} />
                              )}
                              Approve
                            </button>
                            <button
                              onClick={() => handleReject(kyc._id)}
                              disabled={actionLoading === kyc._id}
                              className="flex items-center justify-center gap-1 px-3 py-2 bg-red-600 text-white hover:bg-red-700 disabled:bg-red-300 rounded-lg transition-colors text-sm"
                            >
                              {actionLoading === kyc._id ? (
                                <Loader size={14} className="animate-spin" />
                              ) : (
                                <XCircle size={14} />
                              )}
                              Reject
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Image Modal */}
      {showImageModal && selectedImage && (
        <div
          className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center p-4 z-50"
          onClick={() => setShowImageModal(false)}
        >
          <div
            className="bg-white rounded-xl shadow-2xl max-w-2xl w-full mx-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-center p-4 border-b">
              <h3 className="text-lg font-semibold text-gray-800">
                Document Preview
              </h3>
              <button
                onClick={() => setShowImageModal(false)}
                className="text-gray-500 hover:text-gray-700 p-1 rounded-full hover:bg-gray-100"
              >
                <XCircle size={24} />
              </button>
            </div>
            <div className="p-6 flex justify-center">
              <img
                src={selectedImage}
                alt="Document Preview"
                className="max-w-full max-h-[70vh] object-contain rounded-lg shadow-md"
              />
            </div>
            <div className="p-4 border-t bg-gray-50 flex justify-end">
              <button
                onClick={() => setShowImageModal(false)}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
