import React from 'react';
import { Code, Twitter, Github, MessageCircle } from 'lucide-react';
import { COMPANY_NAME, FOOTER_LINKS } from '../../data/constants';
import logo from "../../assets/imgages/payglobal-logo.png"

const Footer = () => {
  return (
    <footer className="pt-12 pb-4 px-4 sm:px-6 lg:px-8 bg-white text-black">
      <div className="max-w-10xl mx-auto">
        <div className="grid md:grid-cols-12 gap-2 mb-8">
          <div className='col-span-12 md:col-span-5'>
            <div className="flex items-center space-x-2 mb-4">
              <div className="flex items-center space-x-2">
                <img src={logo} alt="Logo" className="h-10  mt-4" />
              </div>
            </div>
            <p className="text-black text-sm">
              Empowering secure and seamless digital asset trading through next-generation blockchain infrastructure. Our exchange is built for speed, transparency, and scalability  driving the future of decentralized finance.            </p>
          </div>



          <div className='col-span-12 md:col-span-3'>
            <h3 className="text-black font-semibold mb-4">Community</h3>
            <div className="space-y-2 text-sm">
              {/* {FOOTER_LINKS.community.map((link, index) => (
                <a key={index} href={link.href} className="block text-gray-600 hover:text-white transition-colors">
                  {link.label}
                </a>
              ))} */}

              {FOOTER_LINKS.community.map((link, index) => (
                <p
                  key={index}
                  className="flex items-center gap-2 text-gray-600 hover:text-white transition-colors"
                >
                  <link.icon className="w-4 h-4" />
                  <span>{link.label}</span>
                </p>
              ))}

            </div>
          </div>

          <div className='col-span-12 md:col-span-2'>
            <h3 className="text-black font-semibold mb-4">Company</h3>
            <div className="space-y-2 text-sm">
              {FOOTER_LINKS.company.map((link, index) => (
                // <a key={index} href={link.href} className="block text-gray-600 hover:text-white transition-colors">
                //   {link.label}
                // </a>
                <p
                  key={index}
                  className="flex items-center gap-2 text-gray-600 hover:text-white transition-colors"
                >
                  <link.icon className="w-4 h-4" />
                  <span>{link.label}</span>
                </p>
              ))}
            </div>
          </div>

          <div className='col-span-12 md:col-span-2'>
            <h3 className="text-black font-semibold mb-4">Social Media</h3>
            <div className="space-y-2 text-sm">
              {FOOTER_LINKS.socialmedia.map((link, index) => (
                <p
                  key={index}
                  className="flex items-center gap-2 text-gray-600 hover:text-white transition-colors"
                >
                  <link.icon className="w-4 h-4" />
                  <span>{link.label}</span>
                </p>
              ))}
            </div>
          </div>
        </div>

        <div className="border-t border-purple-500/20 pt-4 flex flex-col justify-between items-center">
          <p className="text-gray-700 text-sm mb-4 md:mb-0 justify-center">
            © {new Date().getFullYear()} Payglobal. All rights reserved.
          </p>


        </div>
      </div>
    </footer>
  );
};

export default Footer;