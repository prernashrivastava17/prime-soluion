import React, { useEffect, useState } from "react";
import {
  User,
  Mail,
  Shield,
  CreditCard,
  Coins,
  Wallet,
  TrendingUp,
  Activity,
  CheckCircle,
  XCircle,
  Star,
  Zap,
  Target,
  BarChart3,
  Calendar,
} from "lucide-react";
import userImage from "../../assets/imgages/user.png";
import { fetchApi } from "../../assets/js/function";

export default function Profile() {
  const [selectedWalletType, setSelectedWalletType] = useState("evm");
  const [userData, setUserData] = useState({
    firstName: "",
    lastName: "",
    emailId: "",
    accountStatus: "",
    tradingLevel: "Advanced",
    totalBalance: 0,
    portfolioValue: "$598.99",
    totalTrades: 0,
    successRate: 0,
    joinDate: "",
    verificationStatus: "",
    securityLevel: "High",
    favoritePairs: "BTC/USD, ETH/USD, PG/USD",
    weeklyProfit: "+$2,845.30",
    riskLevel: "Medium",
    preferredAssets: "PGL, USDT",
    tokens: 0,
    walletAddresses: {
      evm: "",
      trx: "",
      pgl: "",
    },
    walletBalances: {
      evm: 0,
      tron: 0,
      pgl: 0,
    },
  });

  const [isLoading, setIsLoading] = useState(true);
  const [localUserData, setLocalUserData] = useState(null);

  useEffect(() => {
    // Get data from localStorage
    const storedUserData = localStorage.getItem("adminData");
    if (storedUserData) {
      setLocalUserData(JSON.parse(storedUserData));
    }
  }, []);

  useEffect(() => {
    let isMounted = true;

    const fetchUserProfile = async () => {
      try {
        setIsLoading(true);
        const storedUserData = localStorage.getItem("adminData");
        const userData = storedUserData ? JSON.parse(storedUserData) : null;

        if (!userData?.email) {
          console.error("No email found in localStorage");
          return;
        }

        const [response, result] = await fetchApi(
          "user/user-profile",
          {
            email: userData.email,
          },
          "POST"
        );

        console.log("User Profile API result:", result);

        if (isMounted && result?.success) {
          const { userInfo, financials, verification, wallets } = result.data;

          setUserData((prevData) => ({
            ...prevData,
            // User Info
            firstName: userInfo?.firstName || "",
            lastName: userInfo?.lastName || "",
            emailId: userInfo?.emailId || "",
            joinDate: userInfo?.joinDate || "",

            // Financials
            totalBalance: financials?.totalBalance || 0,
            totalTrades: financials?.totalTrades || 0,
            successRate: financials?.successRate || 0,
            tokens: financials?.tokens || 0,

            // Verification
            accountStatus: verification?.status || "",
            verificationStatus: verification?.status || "",

            // Wallets - Addresses
            walletAddresses: {
              evm: wallets?.addresses?.evm || "",
              trx: wallets?.addresses?.trx || "",
              pgl: wallets?.addresses?.pgl || "",
            },

            // Wallets - Balances
            walletBalances: {
              evm: wallets?.balances?.evm || 0,
              tron: wallets?.balances?.tron || 0,
              pgl: wallets?.balances?.pgl || 0,
            },

            // Update portfolio value based on actual total balance
            portfolioValue: `$${financials?.totalBalance || 0}`,
          }));
        } else {
          console.error("API response not successful:", result);
        }
      } catch (error) {
        console.error("Error fetching user profile:", error);
      } finally {
        if (isMounted) {
          setIsLoading(false);
        }
      }
    };

    fetchUserProfile();

    return () => {
      isMounted = false;
    };
  }, []);

  const InfoField = ({ label, value, icon: Icon, color = "blue" }) => (
    <div className="mb-5 p-4 bg-white rounded-xl border border-gray-200 hover:border-blue-300 hover:shadow-md transition-all duration-300 group">
      <div className="flex items-center mb-3">
        {Icon && (
          <div
            className={`p-2 rounded-lg bg-${color}-100 mr-3 group-hover:scale-110 transition-transform`}
          >
            <Icon className={`w-4 h-4 text-${color}-600`} />
          </div>
        )}
        <label className="text-sm font-medium text-gray-600 group-hover:text-gray-800 transition-colors">
          {label}
        </label>
      </div>
      <p className="text-gray-900 font-semibold text-lg group-hover:text-blue-700 transition-colors">
        {value || "N/A"}
      </p>
    </div>
  );

  const StatCard = ({ icon: Icon, label, value, change, color = "blue" }) => (
    <div className="bg-white border border-gray-200 rounded-2xl p-6 hover:border-blue-300 hover:shadow-lg transition-all duration-300 group">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-gray-600 group-hover:text-gray-800 transition-colors">
            {label}
          </p>
          <p className="text-2xl font-bold text-gray-900 mt-2 group-hover:text-blue-700 transition-colors">
            {value}
          </p>
          {change && (
            <p
              className={`text-sm font-medium mt-1 ${
                change.startsWith("+") ? "text-green-600" : "text-red-600"
              }`}
            >
              {change}
            </p>
          )}
        </div>
        <div
          className={`p-3 rounded-xl bg-${color}-100 group-hover:bg-${color}-200 transition-colors`}
        >
          <Icon
            className={`w-7 h-7 text-${color}-600 group-hover:scale-110 transition-transform`}
          />
        </div>
      </div>
    </div>
  );

  const ProgressBar = ({ label, percentage, color = "blue" }) => (
    <div className="mb-4">
      <div className="flex justify-between items-center mb-2">
        <span className="text-sm font-medium text-gray-600">{label}</span>
        <span className="text-sm font-semibold text-gray-900">
          {percentage}%
        </span>
      </div>
      <div className="w-full bg-gray-200 rounded-full h-2">
        <div
          className={`h-2 rounded-full bg-gradient-to-r from-[#1e2746] to-cyan-500`}
          style={{ width: `${percentage}%` }}
        ></div>
      </div>
    </div>
  );

  // Format date for display
  const formatJoinDate = (dateString) => {
    if (!dateString) return "N/A";
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-cyan-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading profile data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-cyan-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header Section */}
        <div className="bg-white rounded-3xl shadow-lg border border-gray-100 overflow-hidden mb-8 relative">
          {/* Background Pattern */}
          <div className="absolute inset-0 opacity-5">
            <div className="absolute top-10 left-10 w-20 h-20 bg-blue-500 rounded-full blur-xl"></div>
            <div className="absolute bottom-10 right-10 w-24 h-24 bg-cyan-500 rounded-full blur-xl"></div>
          </div>

          <div className="relative px-8 py-12 bg-gradient-to-r from-cyan-700 via-blue-800 to-gray-800">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
              <div className="flex items-center mb-8 lg:mb-0">
                <div className="relative mr-8">
                  <div className="absolute inset-0 bg-white/20 rounded-[50%] blur-md"></div>
                  <img
                    src={userImage}
                    alt="Profile"
                    className="relative w-28 h-28 rounded-[50%] border-4 border-white/80 object-cover shadow-2xl"
                  />
                  <div
                    className={`absolute bottom-3 right-3 w-6 h-6 rounded-full border-2 border-white ${
                      userData.verificationStatus === "verified"
                        ? "bg-green-500 shadow-lg"
                        : "bg-yellow-500 shadow-lg"
                    }`}
                  />
                </div>
                <div>
                  <h1 className="text-4xl font-bold text-white mb-3">
                    {userData.firstName} {userData.lastName}
                  </h1>
                  <p className="text-blue-100 text-xl mb-4 font-medium">
                    {userData.emailId}
                  </p>
                  <div className="flex flex-wrap gap-3">
                    <span
                      className={`px-5 py-2.5 rounded-2xl text-sm font-semibold border backdrop-blur-sm flex items-center ${
                        userData.verificationStatus === "verified"
                          ? "bg-green-500/20 text-green-100 border-green-500/30"
                          : "bg-yellow-500/20 text-yellow-100 border-yellow-500/30"
                      }`}
                    >
                      {userData.verificationStatus === "verified" ? (
                        <CheckCircle className="w-4 h-4 mr-2" />
                      ) : (
                        <XCircle className="w-4 h-4 mr-2" />
                      )}
                      {userData.verificationStatus || "Not Verified"}
                    </span>
                    <span className="bg-cyan-500/20 text-cyan-100 px-5 py-2.5 rounded-2xl text-sm font-semibold border border-cyan-500/30 backdrop-blur-sm flex items-center">
                      <Star className="w-4 h-4 mr-2" />
                      {userData.tradingLevel} Trader
                    </span>
                  </div>
                </div>
              </div>

              {/* Wallet Address Section */}
              <div className="bg-gradient-to-br from-cyan-500 to-blue-600 rounded-2xl p-6 text-white shadow-2xl hover:shadow-2xl transition-all duration-300">
                <div className="flex items-center gap-2 mb-3">
                  <div className="bg-white/20 p-2 rounded-lg">
                    <Wallet className="w-5 h-5 text-cyan-200" />
                  </div>
                  <p className="text-cyan-100 text-sm font-semibold">
                    Wallet Address
                  </p>
                </div>

                {/* Wallet Type Buttons */}
                <div className="flex gap-2 mb-4">
                  {["evm", "trx", "pgl"].map((type) => (
                    <button
                      key={type}
                      onClick={() => setSelectedWalletType(type)}
                      className={`flex-1 py-2 px-3 rounded-xl transition-all duration-200 font-semibold ${
                        selectedWalletType === type
                          ? "bg-white text-cyan-600 shadow-lg"
                          : "bg-white/20 hover:bg-white/30"
                      }`}
                    >
                      {type.toUpperCase()}
                    </button>
                  ))}
                </div>

                <p className="text-xs bg-white/20 p-3 rounded-lg font-mono text-cyan-100 break-all border border-cyan-300/30">
                  {userData.walletAddresses[selectedWalletType] ||
                    "No address available"}
                </p>
                <p className="text-cyan-100 text-xs mt-2 flex items-center gap-1">
                  <Shield className="w-3 h-3" />
                  Balance: $
                  {userData.walletBalances[
                    selectedWalletType === "trx" ? "tron" : selectedWalletType
                  ] || 0}
                </p>
              </div>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="relative px-8 pb-8 pt-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <StatCard
                icon={Wallet}
                label="Total Balance"
                value={`$${userData.totalBalance}`}
                change={userData.weeklyProfit}
                color="blue"
              />
              <StatCard
                icon={TrendingUp}
                label="Portfolio Value"
                value={userData.portfolioValue}
                change="+12.4%"
                color="green"
              />
              <StatCard
                icon={Activity}
                label="Total Trades"
                value={userData.totalTrades}
                change="+24 this week"
                color="purple"
              />
              <StatCard
                icon={Coins}
                label="Success Rate"
                value={`${userData.successRate}%`}
                change="+2.1%"
                color="orange"
              />
            </div>
          </div>
        </div>

        {/* Detailed Information Grid */}
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-8 mb-8">
          {/* Personal Information */}
          <div className="bg-white rounded-3xl shadow-lg border border-gray-200 p-8 hover:border-blue-300 hover:shadow-xl transition-all duration-300">
            <div className="flex items-center mb-8">
              <div className="w-14 h-14 bg-blue-100 rounded-2xl flex items-center justify-center mr-4 border border-blue-200">
                <User className="w-7 h-7 text-blue-600" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900">
                Personal Information
              </h3>
            </div>
            <div className="space-y-4">
              <InfoField
                label="Full Name"
                value={`${userData.firstName} ${userData.lastName}`}
                icon={User}
                color="blue"
              />
              <InfoField
                label="Email Address"
                value={userData.emailId}
                icon={Mail}
                color="blue"
              />
              <InfoField
                label="Mobile Number"
                value={localUserData?.mobileNo || "N/A"}
                icon={CreditCard}
                color="blue"
              />
              <InfoField
                label="Join Date"
                value={formatJoinDate(userData.joinDate)}
                icon={Calendar}
                color="blue"
              />
            </div>
          </div>

          {/* Account Status */}
          <div className="bg-white rounded-3xl shadow-lg border border-gray-200 p-8 hover:border-cyan-300 hover:shadow-xl transition-all duration-300">
            <div className="flex items-center mb-8">
              <div className="w-14 h-14 bg-cyan-100 rounded-2xl flex items-center justify-center mr-4 border border-cyan-200">
                <Shield className="w-7 h-7 text-cyan-600" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900">
                Account Status
              </h3>
            </div>
            <div className="space-y-4">
              <InfoField
                label="Account Status"
                value={userData.accountStatus || "Active"}
                icon={
                  userData.verificationStatus === "verified"
                    ? CheckCircle
                    : XCircle
                }
                color="cyan"
              />
              <InfoField
                label="Verification Status"
                value={userData.verificationStatus || "Pending"}
                icon={Shield}
                color="cyan"
              />
              <InfoField
                label="Security Level"
                value={userData.securityLevel}
                icon={Zap}
                color="cyan"
              />
              <InfoField
                label="Risk Level"
                value={userData.riskLevel}
                icon={Target}
                color="cyan"
              />
            </div>
          </div>

          {/* Trading Performance */}
          <div className="bg-white rounded-3xl shadow-lg border border-gray-200 p-8 hover:border-purple-300 hover:shadow-xl transition-all duration-300">
            <div className="flex items-center mb-8">
              <div className="w-14 h-14 bg-purple-100 rounded-2xl flex items-center justify-center mr-4 border border-purple-200">
                <BarChart3 className="w-7 h-7 text-purple-600" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900">
                Trading Performance
              </h3>
            </div>
            <div className="space-y-6">
              <InfoField
                label="Total Tokens"
                value={userData.tokens}
                icon={Coins}
                color="purple"
              />
              <InfoField
                label="Success Rate"
                value={`${userData.successRate}%`}
                icon={TrendingUp}
                color="purple"
              />
              <InfoField
                label="Preferred Assets"
                value={userData.preferredAssets}
                icon={Activity}
                color="purple"
              />

              <div className="mt-6">
                <ProgressBar
                  label="Trading Performance"
                  percentage={userData.successRate || 0}
                  color="blue"
                />
                <ProgressBar
                  label="Risk Management"
                  percentage={78}
                  color="cyan"
                />
                <ProgressBar
                  label="Portfolio Diversity"
                  percentage={85}
                  color="purple"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
