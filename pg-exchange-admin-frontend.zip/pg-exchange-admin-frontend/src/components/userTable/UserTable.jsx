import React, { useState, useMemo, useEffect } from "react";
import { Modal, Descriptions, Image } from "antd";

import { IoEye } from "react-icons/io5";
import {
  ArrowUpRight,
  Search,
  Download,
  RefreshCw,
  User,
  Mail,
  Phone,
  Shield,
  ShieldOff,
  Wallet,
  Calendar,
  Copy,
  Hash,
} from "lucide-react";
import {
  Table,
  Button,
  Select,
  Input,
  Card,
  Statistic,
  Row,
  Col,
  
  Tag,

  Space,
  message,
  Spin,
  Tooltip,
  Avatar,
  Popconfirm,
} from "antd";
import axios from "axios";

const { Option } = Select;

const UserTable = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchText, setSearchText] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [kycFilter, setKycFilter] = useState("all");
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [processingId, setProcessingId] = useState(null);
  const [viewModalOpen, setViewModalOpen] = useState(false);
  const [viewLoading, setViewLoading] = useState(false);
  const [viewUser, setViewUser] = useState(null);
  const [viewKyc, setViewKyc] = useState(null);


  // Statistics
  const stats = useMemo(() => {
    const total = users.length;
    const active = users.filter((u) => u.isActive).length;
    const verified = users.filter((u) => u.isVerified).length;
    const kycVerified = users.filter((u) => u.kycStatus === "verified").length;

    return { total, active, verified, kycVerified };
  }, [users]);

  // Fetch users
  const fetchUserDetails = async (email) => {
    try {
      setViewLoading(true);
      setViewModalOpen(true);

      const response = await axios.post("/api/admin/get-user", { email });

      if (response.data?.data) {
        setViewUser(response.data.data.userData);
        setViewKyc(response.data.data.userKycData);
      } else {
        message.error("User data not found");
      }
    } catch (error) {
      message.error("Failed to fetch user details");
    } finally {
      setViewLoading(false);
    }
  };

  const fetchUsers = async () => {
    try {
      setLoading(true);
      const response = await axios.get("/api/admin/get-all-users");

      if (response.data.success) {
        setUsers(response.data.userData);
        message.success("Users loaded successfully");
      } else {
        message.error(response.data.message || "Failed to load users");
      }
    } catch (error) {
      message.error(error.response?.data?.message || "Error fetching users");
      console.error("Error:", error);
    } finally {
      setLoading(false);
    }
  };

  // Handle block/unblock
  const handleBlockToggle = async (email) => {
    try {
      setProcessingId(email);

      const response = await axios.post("/api/admin/action-on-user", {
        email: email,
      });

      if (response.data.success) {
        // Update local state
        setUsers((prevUsers) =>
          prevUsers.map((user) =>
            user.email === email ? { ...user, isActive: !user.isActive } : user
          )
        );

        message.success(
          response.data.message || "Action completed successfully"
        );
      } else {
        message.error(response.data.message || "Action failed");
      }
    } catch (error) {
      message.error(error.response?.data?.message || "Error performing action");
      console.error("Error:", error);
    } finally {
      setProcessingId(null);
    }
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    message.success("Copied to clipboard");
  };

  // Filter users based on search and filters
  const filteredUsers = useMemo(() => {
    return users.filter((user) => {
      // Search filter - now includes _id
      const matchesSearch =
        searchText === "" ||
        user.name?.toLowerCase().includes(searchText.toLowerCase()) ||
        user.email?.toLowerCase().includes(searchText.toLowerCase()) ||
        user.mobileNo?.includes(searchText) ||
        user._id?.toLowerCase().includes(searchText.toLowerCase()) ||
        user.userId?.toLowerCase().includes(searchText.toLowerCase());

      // Status filter
      const matchesStatus =
        statusFilter === "all" ||
        (statusFilter === "active" && user.isActive) ||
        (statusFilter === "blocked" && !user.isActive);

      // KYC filter
      const matchesKyc = kycFilter === "all" || user.kycStatus === kycFilter;

      return matchesSearch && matchesStatus && matchesKyc;
    });
  }, [users, searchText, statusFilter, kycFilter]);

  // Table columns
  const columns = [
    {
      title: "ID",
      dataIndex: "_id",
      key: "_id",
      width: 100,
      render: (id) => (
        <div className="flex items-center gap-1">
          <Hash size={12} className="text-gray-400" />
          <Tooltip title={id}>
            <code className="font-mono text-xs text-gray-600 truncate max-w-[80px] block">
              {id}
            </code>
          </Tooltip>
          <Tooltip title="Copy ID">
            <Button
              type="text"
              size="small"
              icon={<Copy size={10} />}
              onClick={() => copyToClipboard(id)}
              className="opacity-50 hover:opacity-100"
            />
          </Tooltip>
        </div>
      ),
      sorter: (a, b) => a._id.localeCompare(b._id),
      filters: [
        { text: 'Starts with "usr"', value: "usr" },
        { text: 'Starts with "user"', value: "user" },
        { text: "Custom Filter", value: "custom" },
      ],
      onFilter: (value, record) => {
        if (value === "custom") {
          // Add your custom filter logic here
          return record._id.length > 20;
        }
        return record._id.toLowerCase().startsWith(value.toLowerCase());
      },
    },
    {
      title: "User",
      dataIndex: "name",
      key: "user",
      width: 250,
      render: (text, record) => (
        <div className="flex items-center gap-3">
          <Avatar
            size="large"
            className="bg-gradient-to-r from-blue-500 to-purple-600"
          >
            {record.name?.charAt(0).toUpperCase()}
          </Avatar>
          <div>
            <div className="font-medium">{record.name}</div>
            <div className="text-sm text-gray-500 flex items-center gap-1">
              <Mail size={12} />
              {record.email}
              <div>
                <IoEye
                  size={18}
                  className="cursor-pointer"
                  onClick={() => fetchUserDetails(record.email)}
                />
              </div>

            </div>

            {/*<div className="text-sm text-gray-500 flex items-center gap-1">
              <Phone size={12} />
              {record.mobileNo}
            </div>*/}
          </div>
        </div>
      ),
      sorter: (a, b) => a.name.localeCompare(b.name),
    },

    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      width: 150,
      render: (_, record) => (
        <Space direction="vertical" size="small">
          <Tag
            color={record.isVerified ? "success" : "error"}
            icon={
              record.isVerified ? <Shield size={12} /> : <ShieldOff size={12} />
            }
          >
            {record.isVerified ? "Verified" : "Not Verified"}
          </Tag>
          <Tag color={record.isActive ? "green" : "red"}>
            {record.isActive ? "Active" : "Blocked"}
          </Tag>
        </Space>
      ),
      filters: [
        { text: "Verified", value: "verified" },
        { text: "Not Verified", value: "not-verified" },
        { text: "Active", value: "active" },
        { text: "Blocked", value: "blocked" },
      ],
      onFilter: (value, record) => {
        if (value === "verified") return record.isVerified;
        if (value === "not-verified") return !record.isVerified;
        if (value === "active") return record.isActive;
        if (value === "blocked") return !record.isActive;
        return true;
      },
    },
    {
      title: "KYC Status",
      dataIndex: "kycStatus",
      key: "kycStatus",
      width: 120,
      render: (status) => (
        <Tag
          color={
            status === "verified"
              ? "success"
              : status === "pending"
                ? "warning"
                : status === "rejected"
                  ? "error"
                  : "default"
          }
        >
          {status?.toUpperCase()}
        </Tag>
      ),
      filters: [
        { text: "Verified", value: "verified" },
        { text: "Pending", value: "pending" },
        { text: "Rejected", value: "rejected" },
      ],
      onFilter: (value, record) => record.kycStatus === value,
    },
    {
      title: "Wallets",
      dataIndex: "wallets",
      key: "wallets",
      width: 350,
      render: (wallets) => (
        <div className="space-y-2">
          {wallets?.map((wallet, index) => (
            <div key={index} className="flex items-start gap-2">
              <div className="flex-shrink-0">
                <Tag color="blue" className="min-w-[60px] text-center">
                  {wallet.chain}
                </Tag>
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between group">
                  <code className="text-xs font-mono break-all text-gray-700">
                    {wallet.address}
                  </code>
                  <Tooltip title="Copy address">
                    <Button
                      type="text"
                      size="small"
                      icon={<Copy size={12} />}
                      onClick={() => copyToClipboard(wallet.address)}
                      className="opacity-0 group-hover:opacity-100 transition-opacity"
                    />
                  </Tooltip>
                </div>
              </div>
            </div>
          ))}
        </div>
      ),
    },
    {
      title: "Created",
      dataIndex: "createdAt",
      key: "createdAt",
      width: 150,
      render: (date) => (
        <div className="flex items-center gap-1 text-gray-600">
          <Calendar size={12} />
          <span>{new Date(date).toLocaleDateString()}</span>
        </div>
      ),
      sorter: (a, b) => new Date(a.createdAt) - new Date(b.createdAt),
    },
    {
      title: "Actions",
      key: "actions",
      width: 150,
      render: (_, record) => (
        <Popconfirm
          title={`Are you sure you want to ${record.isActive ? "block" : "unblock"
            } this user?`}
          onConfirm={() => handleBlockToggle(record.email)}
          okText="Yes"
          cancelText="No"
          okButtonProps={{
            danger: record.isActive,
            type: "primary",
          }}
        >
          <Button
            type={record.isActive ? "default" : "primary"}
            danger={record.isActive}
            loading={processingId === record.mobileNo}
            icon={
              record.isActive ? <ShieldOff size={16} /> : <Shield size={16} />
            }
          >
            {record.isActive ? "Block" : "Unblock"}
          </Button>
        </Popconfirm>
      ),
    },
  ];

  // Export data - now includes _id
  const handleExport = () => {
    const dataToExport = filteredUsers;

    // Convert to CSV
    const csvContent = [
      [
        "ID",
        "Name",
        "Email",
        "Mobile",
        "Status",
        "KYC Status",
        "EVM Address",
        "TRON Address",
        "PGL Address",
        "Created Date",
      ],
      ...dataToExport.map((user) => {
        const evmWallet = user.wallets?.find((w) => w.chain === "EVM");
        const tronWallet = user.wallets?.find((w) => w.chain === "TRON");
        const pglWallet = user.wallets?.find((w) => w.chain === "PGL");

        return [
          user._id,
          user.name,
          user.email,
          user.mobileNo,
          user.isActive ? "Active" : "Blocked",
          user.kycStatus,
          evmWallet?.address || "",
          tronWallet?.address || "",
          pglWallet?.address || "",
          new Date(user.createdAt).toLocaleDateString(),
        ];
      }),
    ]
      .map((row) => row.join(","))
      .join("\n");

    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "users_export.csv";
    a.click();

    message.success(`Exported ${dataToExport.length} users`);
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  return (
    <div className="p-6 bg-gray-50 min-h-screen">

      <Row gutter={[16, 16]} className="mb-6">
        <Col xs={24} sm={12} md={6}>
          <Card>
            <Statistic
              title="Total Users"
              value={stats.total}
              prefix={<User className="text-blue-500" size={20} />}
              valueStyle={{ color: "#1890ff" }}
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} md={6}>
          <Card>
            <Statistic
              title="Active Users"
              value={stats.active}
              suffix={`/ ${stats.total}`}
              prefix={<ArrowUpRight className="text-green-500" size={20} />}
              valueStyle={{ color: "#3f8600" }}
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} md={6}>
          <Card>
            <Statistic
              title="Verified Users"
              value={stats.verified}
              suffix={`/ ${stats.total}`}
              prefix={<Shield className="text-purple-500" size={20} />}
              valueStyle={{ color: "#722ed1" }}
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} md={6}>
          <Card>
            <Statistic
              title="KYC Verified"
              value={stats.kycVerified}
              suffix={`/ ${stats.total}`}
              prefix={<Shield className="text-orange-500" size={20} />}
              valueStyle={{ color: "#fa8c16" }}
            />
          </Card>
        </Col>
      </Row>

      <Card className="mb-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex flex-col sm:flex-row gap-4 flex-1">
            <Input
              placeholder="Search by ID, name, email, phone, or user ID..."
              prefix={<Search size={16} />}
              value={searchText}
              onChange={(e) => setSearchText(e.target.value)}
              style={{ width: 300 }}
              allowClear
            />

            <Select
              placeholder="Filter by Status"
              value={statusFilter}
              onChange={setStatusFilter}
              style={{ width: 150 }}
              allowClear
            >
              <Option value="all">All Status</Option>
              <Option value="active">Active Only</Option>
              <Option value="blocked">Blocked Only</Option>
            </Select>

            <Select
              placeholder="Filter by KYC"
              value={kycFilter}
              onChange={setKycFilter}
              style={{ width: 150 }}
              allowClear
            >
              <Option value="all">All KYC</Option>
              <Option value="verified">Verified</Option>
              <Option value="pending">Pending</Option>
              <Option value="rejected">Rejected</Option>
            </Select>
          </div>

          <Space>
            <Button
              icon={<RefreshCw size={16} />}
              onClick={fetchUsers}
              loading={loading}
            >
              Refresh
            </Button>

            <Button
              icon={<Download size={16} />}
              onClick={handleExport}
              disabled={filteredUsers.length === 0}
            >
              Export
            </Button>
          </Space>
        </div>
      </Card>

      <Card>
        <Spin spinning={loading}>
          <Table
            columns={columns}
            dataSource={filteredUsers.map((user) => ({
              ...user,
              key: user._id,
            }))}
            pagination={{
              current: currentPage,
              pageSize: pageSize,
              total: filteredUsers.length,
              showSizeChanger: true,
              showQuickJumper: true,
              showTotal: (total, range) =>
                `${range[0]}-${range[1]} of ${total} users`,
              pageSizeOptions: ["10", "20", "50", "100"],
              onChange: (page, size) => {
                setCurrentPage(page);
                setPageSize(size);
              },
            }}
            scroll={{ x: 1400 }}
            size="middle"
            locale={{
              emptyText: (
                <div className="py-12 text-center">
                  <User size={48} className="mx-auto text-gray-400 mb-4" />
                  <h3 className="text-lg font-medium text-gray-900">
                    No users found
                  </h3>
                  <p className="text-gray-500">
                    Try adjusting your search or filters
                  </p>
                </div>
              ),
            }}
          />
        </Spin>
      </Card>
      <Modal
  title="User Details"
  open={viewModalOpen}
  onCancel={() => {
    setViewModalOpen(false);
    setViewUser(null);
    setViewKyc(null);
  }}
  footer={null}
  width={850}
>
  <Spin spinning={viewLoading}>

 
    {viewKyc && (
      <Descriptions
        bordered
        column={3}
        size="small"
        className="mt-4 mb-4"
        title="KYC Documents"
      >
        <Descriptions.Item label="Aadhar Front">
          <Image width={120} src={viewKyc.aadharFrontImage} />
        </Descriptions.Item>

        <Descriptions.Item label="Aadhar Back">
          <Image width={120} src={viewKyc.aadharBackImage} />
        </Descriptions.Item>

        <Descriptions.Item label="Passport Photo">
          <Image width={120} src={viewKyc.passportSizePhoto} />
        </Descriptions.Item>

        <Descriptions.Item label="PAN Card">
          <Image width={120} src={viewKyc.pancardImage} />
        </Descriptions.Item>

        <Descriptions.Item label="Passbook">
          <Image width={120} src={viewKyc.passbookFrontImage} />
        </Descriptions.Item>
      </Descriptions>
    )}

    {viewUser && (
      <>
        <Descriptions bordered column={2} size="small" title="User Info">
          <Descriptions.Item label="Name">{viewUser.name}</Descriptions.Item>
          <Descriptions.Item label="Email">{viewUser.email}</Descriptions.Item>
          <Descriptions.Item label="User ID">{viewUser._id}</Descriptions.Item>
          <Descriptions.Item label="Verified">
            <Tag color={viewUser.isVerified ? "green" : "red"}>
              {viewUser.isVerified ? "YES" : "NO"}
            </Tag>
          </Descriptions.Item>
          <Descriptions.Item label="KYC Status">
            <Tag color="orange">{viewUser.kycStatus}</Tag>
          </Descriptions.Item>
          <Descriptions.Item label="Created At">
            {new Date(viewUser.createdAt).toLocaleString()}
          </Descriptions.Item>
        </Descriptions>

     
        <Descriptions
          bordered
          column={1}
          size="small"
          className="mt-4"
          title="Wallets"
        >
          {viewUser.wallets?.map((wallet, i) => (
            <Descriptions.Item key={i} label={wallet.chain}>
              <code>{wallet.address}</code>
            </Descriptions.Item>
          ))}
        </Descriptions>
      </>
    )}

  </Spin>
</Modal>


    </div>
  );
};

export default UserTable;
