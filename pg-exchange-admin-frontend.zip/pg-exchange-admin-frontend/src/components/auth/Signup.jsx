import {
  Wallet,
  TrendingUp,
  Shield,
  Bitcoin,
  Lock,
  Eye,
  EyeOff,
  User,
  Mail,
  Phone,
  CheckCircle,
} from "lucide-react";
import { useEffect, useState } from "react";
import logoLight from "../../assets/imgages/payglobal-logo-light.png";
import logodark from "../../assets/imgages/payglobal-logo.png";
import { Link, useNavigate } from "react-router-dom";
import Captchacomponent from "./Captchacomponent";
import img3 from "../../assets/imgages/img3.png";
import { motion } from "framer-motion";
import OtpValidation from "./OtpValidition";
import { fetchApi } from "../../assets/js/function";
import toast from "react-hot-toast";

const FloatingElement = ({ children, delay = 0, duration = 3 }) => {
  return (
    <div
      className="animate-bounce"
      style={{
        animationDelay: `${delay}s`,
        animationDuration: `${duration}s`,
      }}
    >
      {children}
    </div>
  );
};

const Signup = ({ setCurrentPage }) => {
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [verified, setVerified] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [reset, setReset] = useState(false);
  const [userId, setUserId] = useState();
  const navigate = useNavigate();
  const [showOtpModal, setShowOtpModal] = useState(false);

  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    name: "",
    email: "",
    mobileNo: "",
    password: "",
    confirmPassword: "",
  });

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Combine first name and last name
    const updatedName = {
      ...formData,
      name: `${formData.firstName} ${formData.lastName}`.trim(),
    };

    setFormData(updatedName);
    setIsLoading(true);

    try {
      const [response, result] = await fetchApi(
        "user/signup",
        updatedName,
        "POST"
      );

      if (result.success) {
        toast.success(result.message); // Changed from toast.loading to toast.success
        setUserId(result.userId);
        setShowOtpModal(true);
        console.log("Signup successful - User ID:", result.userId);
      } else {
        toast.error(result.message);
      }
    } catch (error) {
      console.error("Signup error:", error);
      toast.error("Signup failed. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleOtpVerify = async (otp) => {
    setIsLoading(true);

    try {
      const [response, result] = await fetchApi(
        "user/verify-otp",
        {
          identifier: formData.mobileNo,
          otp: otp,
          purpose: "signup", // Added purpose as per backend
        },
        "POST"
      );

      console.log("OTP verification result:", result);

      if (result.success) {
        toast.success(`${result.message}. Kindly login to continue.`);
        setShowOtpModal(false);
        navigate("/admin-login");
      } else {
        // Handle different error cases
        if (result.requiresResend) {
          toast.error(`${result.message} Please resend OTP.`);
          // You might want to automatically trigger resend or show resend button
        } else {
          toast.error(result.message);
          setReset((prev) => !prev); // Trigger OTP input reset
        }
      }
    } catch (error) {
      console.error("OTP verification error:", error);
      toast.error("OTP verification failed. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleResendOtp = async () => {
    setIsLoading(true);

    try {
      const [response, result] = await fetchApi(
        "user/resend-otp",
        {
          identifier: formData.mobileNo,
          type: "phone_verification", // Added type as per backend
          purpose: "signup", // Added purpose as per backend
        },
        "POST"
      );

      console.log("Resend OTP result:", result);

      if (result.success) {
        toast.success(result.message);
        setReset((prev) => !prev); // Reset OTP input for new OTP
      } else {
        toast.error(result.message);
      }
    } catch (error) {
      console.error("Resend OTP error:", error);
      toast.error("Failed to resend OTP. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex relative overflow-hidden">
      <OtpValidation
        isOpen={showOtpModal}
        onVerify={handleOtpVerify}
        reset={reset}
        handleResendOtp={handleResendOtp}
        title="Verify Your Identity"
        description="Enter the 4-digit code sent to your registered mobile No."
      />
      <div className="absolute inset-0 bg-white">
        <div className="absolute top-10 left-[550px] opacity-20 ">
          <FloatingElement>
            <Wallet className="w-14 h-14 text-white" />
          </FloatingElement>
        </div>
        <div className="absolute top-32 right-28 opacity-20">
          <FloatingElement delay={1}>
            <TrendingUp className="w-12 h-12 text-white" />
          </FloatingElement>
        </div>
        <div className="absolute bottom-32 left-32 opacity-20">
          <FloatingElement delay={2}>
            <Shield className="w-16 h-16 text-white" />
          </FloatingElement>
        </div>
        <div className="absolute bottom-10 right-10 opacity-20">
          <FloatingElement delay={0.5}>
            <Bitcoin className="w-10 h-10 text-white" />
          </FloatingElement>
        </div>
        <div className="absolute bottom-16 left-[36rem] opacity-20">
          <FloatingElement delay={0.5}>
            <Bitcoin className="w-10 h-10 text-white" />
          </FloatingElement>
        </div>
      </div>
      <div className="hidden lg:block fixed top-10 left-16 z-20">
        <img src={logoLight} alt="Logo" className="h-8" />
      </div>

      {/* Left Side - Branding */}
      <div className="hidden lg:flex lg:w-[50%] relative z-10 items-center justify-center bg-gradient-to-br from-cyan-700  to-blue-500">
        <div className="absolute inset-0 pointer-events-none">
          {/* Digital Currency Rain */}
          <div className="absolute top-0 left-1/4 animate-fall-slow opacity-10">
            <div className="text-6xl font-bold text-blue-500">₿</div>
          </div>
          <div className="absolute top-0 right-1/3 animate-fall-medium opacity-10">
            <div className="text-4xl font-bold text-cyan-500">Ξ</div>
          </div>
          <div className="absolute top-0 left-2/3 animate-fall-fast opacity-10">
            <div className="text-5xl font-bold text-green-500">$</div>
          </div>

          {/* Hexagonal Grid Pattern */}
          <div className="absolute inset-0 opacity-5">
            <svg className="w-full h-full">
              <defs>
                <pattern
                  id="hexagons"
                  x="0"
                  y="0"
                  width="100"
                  height="87"
                  patternUnits="userSpaceOnUse"
                >
                  <polygon
                    points="50,1 95,25 95,75 50,99 5,75 5,25"
                    fill="none"
                    stroke="#d7d8d9"
                    strokeWidth="1"
                  />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#hexagons)" />
            </svg>
          </div>
        </div>

        <div className="text-center text-white space-y-2 mt-28">
          <div className="space-y-4">
            <div className="relative z-10">
              <motion.img
                src={img3}
                alt="animated"
                animate={{ y: [0, -10, 0] }}
                transition={{
                  duration: 4,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
                className="rounded-lg "
                style={{ width: "300px", height: "auto" }}
              />
            </div>
          </div>

          <div className="space-y-4 max-w-sm mx-auto">
            <div className="flex items-center space-x-3 bg-white/10 backdrop-blur-lg rounded-2xl p-4">
              <CheckCircle className="w-6 h-6 text-green-300" />
              <span>Bank-level security</span>
            </div>
            <div className="flex items-center space-x-3 bg-white/10 backdrop-blur-lg rounded-2xl p-4">
              <CheckCircle className="w-6 h-6 text-green-300" />
              <span>150+ cryptocurrencies</span>
            </div>
            <div className="flex items-center space-x-3 bg-white/10 backdrop-blur-lg rounded-2xl p-4">
              <CheckCircle className="w-6 h-6 text-green-300" />
              <span>24/7 customer support</span>
            </div>
          </div>
        </div>
      </div>

      {/* Right Side - Signup Form */}
      <div className="w-full lg:w-[50%] flex items-center justify-center relative z-10">
        <div className="absolute inset-0 pointer-events-none">
          {/* ---------------------------------------- */}
          <div className="absolute -top-40 -right-40 w-80 h-80 bg-blue-300/20 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-cyan-300/20 rounded-full blur-3xl animate-pulse delay-1000"></div>

          {/* Floating Crypto Icons */}
          <div className="absolute top-20 left-10 animate-float">
            <div className="w-16 h-16 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center shadow-lg">
              <span className="text-white font-bold text-xl">₿</span>
            </div>
          </div>

          <div className="absolute top-40 right-20 animate-float-delay-1">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-400 to-purple-500 rounded-full flex items-center justify-center shadow-lg">
              <span className="text-white font-bold">Ξ</span>
            </div>
          </div>

          <div className="absolute bottom-32 left-20 animate-float-delay-2">
            <div className="w-14 h-14 bg-gradient-to-br from-green-400 to-blue-500 rounded-full flex items-center justify-center shadow-lg">
              <span className="text-white font-bold">$</span>
            </div>
          </div>

          <div className="absolute top-1/2 right-10 animate-float-delay-3">
            <div className="w-10 h-10 bg-gradient-to-br from-pink-400 to-red-500 rounded-full flex items-center justify-center shadow-lg">
              <span className="text-white font-bold text-xs">ADA</span>
            </div>
          </div>

          {/* Blockchain Network Animation */}
          <div className="absolute inset-0 pointer-events-none">
            <svg className="w-full h-full opacity-20">
              {/* Animated Lines */}
              <g className="animate-pulse">
                <line
                  x1="10%"
                  y1="20%"
                  x2="30%"
                  y2="40%"
                  stroke="url(#gradient1)"
                  strokeWidth="2"
                  className="animate-draw"
                />
                <line
                  x1="30%"
                  y1="40%"
                  x2="50%"
                  y2="20%"
                  stroke="url(#gradient1)"
                  strokeWidth="2"
                  className="animate-draw-delay-1"
                />
                <line
                  x1="50%"
                  y1="20%"
                  x2="70%"
                  y2="60%"
                  stroke="url(#gradient1)"
                  strokeWidth="2"
                  className="animate-draw-delay-2"
                />
                <line
                  x1="70%"
                  y1="60%"
                  x2="90%"
                  y2="30%"
                  stroke="url(#gradient1)"
                  strokeWidth="2"
                  className="animate-draw-delay-3"
                />
              </g>

              {/* Network Nodes */}
              <circle
                cx="10%"
                cy="20%"
                r="4"
                fill="#3B82F6"
                className="animate-ping-slow"
              >
                <animate
                  attributeName="fill"
                  values="#3B82F6;#06B6D4;#3B82F6"
                  dur="2s"
                  repeatCount="indefinite"
                />
              </circle>
              <circle
                cx="30%"
                cy="40%"
                r="4"
                fill="#06B6D4"
                className="animate-ping-slow animation-delay-500"
              >
                <animate
                  attributeName="fill"
                  values="#06B6D4;#3B82F6;#06B6D4"
                  dur="2s"
                  repeatCount="indefinite"
                />
              </circle>
              <circle
                cx="50%"
                cy="20%"
                r="4"
                fill="#3B82F6"
                className="animate-ping-slow animation-delay-1000"
              >
                <animate
                  attributeName="fill"
                  values="#3B82F6;#06B6D4;#3B82F6"
                  dur="2s"
                  repeatCount="indefinite"
                />
              </circle>
              <circle
                cx="70%"
                cy="60%"
                r="4"
                fill="#06B6D4"
                className="animate-ping-slow animation-delay-1500"
              >
                <animate
                  attributeName="fill"
                  values="#06B6D4;#3B82F6;#06B6D4"
                  dur="2s"
                  repeatCount="indefinite"
                />
              </circle>
              <circle
                cx="90%"
                cy="30%"
                r="4"
                fill="#3B82F6"
                className="animate-ping-slow animation-delay-2000"
              >
                <animate
                  attributeName="fill"
                  values="#3B82F6;#06B6D4;#3B82F6"
                  dur="2s"
                  repeatCount="indefinite"
                />
              </circle>

              {/* Gradient Definitions */}
              <defs>
                <linearGradient
                  id="gradient1"
                  x1="0%"
                  y1="0%"
                  x2="100%"
                  y2="100%"
                >
                  <stop offset="0%" stopColor="#3B82F6" stopOpacity="0.8" />
                  <stop offset="100%" stopColor="#06B6D4" stopOpacity="0.4" />
                </linearGradient>
              </defs>
            </svg>
          </div>

          {/* ---------------------------------------- */}

          {/* Hexagonal Grid Pattern */}
          <div className="absolute inset-0 opacity-5">
            <svg className="w-full h-full">
              <defs>
                <pattern
                  id="hexagons"
                  x="0"
                  y="0"
                  width="100"
                  height="87"
                  patternUnits="userSpaceOnUse"
                >
                  <polygon
                    points="50,1 95,25 95,75 50,99 5,75 5,25"
                    fill="none"
                    stroke="red"
                    strokeWidth="1"
                  />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#hexagons)" />
            </svg>
          </div>
        </div>

        <div className="w-full max-w-lg">
          <div
            className="bg-white/95 backdrop-blur-lg rounded-3xl shadow-2xl pb-8 pt-4 px-5 border border-white/20"
            style={{ boxShadow: "0 8px 32px 0 rgba(31, 38, 135, 0.37)" }}
          >
            <div className="lg:hidden top-4 left-4 z-40">
              <img src={logodark} alt="Logo" className="h-8" />
            </div>
            <div className="text-center mb-8">
              {/* <div className="flex items-center justify-center space-x-2 mb-4 lg:hidden"> */}

              {/* </div> */}
              <h2 className="text-3xl font-bold text-gray-900 mb-1 them-sec">
                Create Account
              </h2>
              <p className="text-gray-600">
                Join millions of traders worldwide
              </p>
            </div>

            <form className="space-y-6" onSubmit={handleSubmit}>
              <div className="space-y-2">
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-[2px]">
                      First Name
                    </label>
                    <div className="relative">
                      <User className="w-5 h-5 text-gray-400 absolute left-3 top-3" />
                      <input
                        type="text"
                        required
                        value={formData.firstName}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            firstName: e.target.value,
                          })
                        }
                        className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg transition-all bg-white/50 
        focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="First name"
                      />
                      {/* focus:ring-2 focus:ring-green-500 focus:border-transparent */}
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-[2px]">
                      Last Name
                    </label>
                    <div className="relative">
                      <User className="w-5 h-5 text-gray-400 absolute left-3 top-3" />
                      <input
                        type="text"
                        required
                        value={formData.lastName}
                        onChange={(e) =>
                          setFormData({ ...formData, lastName: e.target.value })
                        }
                        className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg transition-all bg-white/50 
        focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="Last name"
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-[2px]">
                    Email
                  </label>
                  <div className="relative">
                    <Mail className="w-5 h-5 text-gray-400 absolute left-3 top-3" />
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) =>
                        setFormData({ ...formData, email: e.target.value })
                      }
                      className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg transition-all bg-white/50 
        focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="Enter your email"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-[2px]">
                    Phone
                  </label>
                  <div className="relative">
                    <Phone className="w-5 h-5 text-gray-400 absolute left-3 top-3" />
                    <input
                      type="tel"
                      value={formData.mobileNo}
                      onChange={(e) =>
                        setFormData({ ...formData, mobileNo: e.target.value })
                      }
                      className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg transition-all bg-white/50 
        focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="Phone number"
                    />
                  </div>
                </div>
                {/* <div className="grid grid-cols-2 gap-2">
                                    <div>
                                        <label className="block text-sm font-medium text-gray-700 mb-[2px]">Password</label>
                                        <div className="relative">
                                            <Lock className="w-5 h-5 text-gray-400 absolute left-3 top-3" />
                                            <input
                                                type={showPassword ? "text" : "password"}
                                                required
                                                value={formData.password}
                                                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                                                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg transition-all bg-white/50 
        focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                                placeholder="Create password"
                                            />
                                            <button
                                                type="button"
                                                onClick={() => setShowPassword(!showPassword)}
                                                className="absolute right-3 top-3 hover:scale-110 transition-transform"
                                            >
                                                {showPassword ? <EyeOff className="w-5 h-5 text-gray-400" /> : <Eye className="w-5 h-5 text-gray-400" />}
                                            </button>
                                        </div>
                                    </div>

                                    <div>
                                        <label className="block text-sm font-medium text-gray-700 mb-[2px]">Confirm Password</label>
                                        <div className="relative">
                                            <Lock className="w-5 h-5 text-gray-400 absolute left-3 top-3" />
                                            <input
                                                type={showConfirmPassword ? "text" : "password"}
                                                required
                                                value={formData.confirmPassword}
                                                onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                                                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg transition-all bg-white/50 
        focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                                placeholder="Confirm password"
                                            />
                                            <button
                                                type="button"
                                                onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                                                className="absolute right-3 top-3 hover:scale-110 transition-transform"
                                            >
                                                {showConfirmPassword ? <EyeOff className="w-5 h-5 text-gray-400" /> : <Eye className="w-5 h-5 text-gray-400" />}
                                            </button>
                                        </div>
                                    </div>
                                </div> */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {/* Password */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-[2px]">
                      Password
                    </label>
                    <div className="relative">
                      <Lock className="w-5 h-5 text-gray-400 absolute left-3 top-3" />
                      <input
                        type={showPassword ? "text" : "password"}
                        required
                        value={formData.password}
                        onChange={(e) =>
                          setFormData({ ...formData, password: e.target.value })
                        }
                        className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg transition-all bg-white/50 
        focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="Create password"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-3 hover:scale-110 transition-transform"
                      >
                        {showPassword ? (
                          <EyeOff className="w-5 h-5 text-gray-400" />
                        ) : (
                          <Eye className="w-5 h-5 text-gray-400" />
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Confirm Password */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-[2px]">
                      Confirm Password
                    </label>
                    <div className="relative">
                      <Lock className="w-5 h-5 text-gray-400 absolute left-3 top-3" />
                      <input
                        type={showConfirmPassword ? "text" : "password"}
                        required
                        value={formData.confirmPassword}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            confirmPassword: e.target.value,
                          })
                        }
                        className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg transition-all bg-white/50 
        focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="Confirm password"
                      />
                      <button
                        type="button"
                        onClick={() =>
                          setShowConfirmPassword(!showConfirmPassword)
                        }
                        className="absolute right-3 top-3 hover:scale-110 transition-transform"
                      >
                        {showConfirmPassword ? (
                          <EyeOff className="w-5 h-5 text-gray-400" />
                        ) : (
                          <Eye className="w-5 h-5 text-gray-400" />
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* 
                            setVerified */}
              <Captchacomponent setVerified={setVerified} verified={verified} />

              <button
                type="submit"
                className="w-full py-2 px-4 bg-gradient-to-br from-cyan-700  to-blue-500 text-white rounded-xl font-semibold hover:shadow-xl transform hover:scale-105 transition-all duration-300"
              >
                Create Account
              </button>

              <div className="text-center">
                <p className="text-gray-600">
                  Already have an account?{" "}
                  <Link
                    to="/admin-login"
                    className="text-green-600 hover:text-green-500 font-medium"
                  >
                    Sign in
                  </Link>
                </p>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Signup;
