import { useState } from "react";
import { Shield, Lock, Eye, EyeOff, User, Building } from "lucide-react";
import img3 from "./../../assets/imgages/img3.png";
import { motion } from "framer-motion";
import logoLight from "../../assets/imgages/payglobal-logo-light.png";
import logodark from "../../assets/imgages/payglobal-logo.png";
import { Link, NavLink, useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import { fetchApi } from "../../assets/js/function";
import OtpValidation from "./OtpValidition";

const AdminLogin = ({ setCurrentPage }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    otp: "",
  });
  const navigate = useNavigate();
  const [showOtpModal, setShowOtpModal] = useState(false);
  const [reset, setReset] = useState(false);

  const handleSubmit = async (otp) => {
    if (!formData.email.trim() || !formData.password.trim() || !otp) {
      toast.error("Please fill in all fields");
      return;
    }

    setIsLoading(true);

    // const otpResult = await handleOTP(email);

    // if (otpResult.success) {

    // try {

    console.log("formData---", formData);
    const [response, result] = await fetchApi(
      "admin/admin-login",
      formData,
      "POST"
    );

    console.log("response--", response);
    console.log("result--", result);

    if (result?.success) {
      toast.success(result.message || "Login successful");
      localStorage.setItem("adminData", JSON.stringify(result.data));
      navigate("/dashboard");
    } else {
      setReset((prev) => !prev);
      setIsLoading(false);
      toast.error(result.message || "Invalid credentials");
    }
    // } else {
    //   toast.error(result.message || "otp response error");
    // }
  };

  const handleOtpVerify = async (otp) => {
    console.log("otp===", otp);
    formData.otp = otp;
    await handleSubmit(otp);
  };

  const generateOtp = async (e) => {
    e.preventDefault();
    const [response, result] = await fetchApi(
      "admin/get-admin-otp",
      { email: formData.email },
      "POST"
    );

    if (!response.ok) {
      toast.error("Error in OTP.Try again");
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    if (result.success) {
      // setUserId(result.userId);
      toast.success(result.message);
      console.log("OTP  API response:", result);
      setShowOtpModal(true);
    }
  };

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  const handleResendOtp = async () => {
    setIsLoading(true);

    try {
      const [response, result] = await fetchApi(
        "user/resend-otp",
        {
          // identifier: userId,
          type: "phone_verification",
          purpose: "login",
        },
        "POST"
      );

      console.log("Resend OTP result:", result);

      if (result.success) {
        toast.success(result.message);
        setReset((prev) => !prev);
      } else {
        toast.error(result.message);
      }
    } catch (error) {
      console.error("Resend OTP error:", error);
      toast.error("Failed to resend OTP. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex relative overflow-hidden">
      <OtpValidation
        isOpen={showOtpModal}
        onVerify={handleOtpVerify}
        // handleResendOtp={handleResendOtp}
        reset={reset}
        title="Verify Your Identity"
        description="Enter the 4-digit code sent to your registered email"
      />

      <div className="hidden lg:block fixed top-10 left-16 z-20">
        <img src={logoLight} alt="Logo" className="h-8" />
      </div>

      {/* Left side */}
      <div className="hidden lg:flex lg:w-1/2 relative z-10 items-center justify-center bg-gradient-to-br from-cyan-800 to-blue-500">
        <div className="absolute inset-0 pointer-events-none">
          {/* Digital Currency Rain */}
          <div className="absolute top-0 left-1/4 animate-fall-slow opacity-10">
            <div className="text-6xl font-bold text-blue-500">₿</div>
          </div>
          <div className="absolute top-0 right-1/3 animate-fall-medium opacity-10">
            <div className="text-4xl font-bold text-cyan-500">Ξ</div>
          </div>
          <div className="absolute top-0 left-2/3 animate-fall-fast opacity-10">
            <div className="text-5xl font-bold text-green-500">$</div>
          </div>

          {/* Hexagonal Grid Pattern */}
          <div className="absolute inset-0 opacity-5">
            <svg className="w-full h-full">
              <defs>
                <pattern
                  id="hexagons"
                  x="0"
                  y="0"
                  width="100"
                  height="87"
                  patternUnits="userSpaceOnUse"
                >
                  <polygon
                    points="50,1 95,25 95,75 50,99 5,75 5,25"
                    fill="none"
                    stroke="#d7d8d9"
                    strokeWidth="1"
                  />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#hexagons)" />
            </svg>
          </div>
        </div>

        <div className="text-center text-white space-y-8">
          <div className="space-y-4">
            <div className="relative z-10">
              <motion.img
                src={img3}
                alt="animated"
                animate={{ y: [0, -10, 0] }}
                transition={{
                  duration: 4,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
                className="rounded-lg"
                style={{ width: "400px", height: "auto", objectFit: "cover" }}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-6 max-w-md mx-auto">
            <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-4 text-center">
              <div className="text-2xl font-bold">2M+</div>
              <div className="text-sm opacity-80">Trusted Users</div>
            </div>
            <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-4 text-center">
              <div className="text-2xl font-bold">$50B</div>
              <div className="text-sm opacity-80">Trading Volume</div>
            </div>
          </div>
        </div>
      </div>

      {/* Right side */}
      <div className="w-full lg:w-1/2 flex items-center justify-center relative z-10">
        <div className="absolute inset-0 pointer-events-none">
          {/* Background effects */}
          <div className="absolute -top-40 -right-40 w-80 h-80 bg-blue-300/20 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-cyan-300/20 rounded-full blur-3xl animate-pulse delay-1000"></div>

          {/* Floating Crypto Icons */}
          <div className="absolute top-20 left-10 animate-float">
            <div className="w-16 h-16 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center shadow-lg">
              <span className="text-white font-bold text-xl">₿</span>
            </div>
          </div>

          <div className="absolute top-40 right-20 animate-float-delay-1">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-400 to-purple-500 rounded-full flex items-center justify-center shadow-lg">
              <span className="text-white font-bold">Ξ</span>
            </div>
          </div>

          <div className="absolute bottom-32 left-20 animate-float-delay-2">
            <div className="w-14 h-14 bg-gradient-to-br from-green-400 to-blue-500 rounded-full flex items-center justify-center shadow-lg">
              <span className="text-white font-bold">$</span>
            </div>
          </div>

          <div className="absolute top-1/2 right-10 animate-float-delay-3">
            <div className="w-10 h-10 bg-gradient-to-br from-pink-400 to-red-500 rounded-full flex items-center justify-center shadow-lg">
              <span className="text-white font-bold text-xs">ADA</span>
            </div>
          </div>

          {/* Blockchain Network Animation */}
          <div className="absolute inset-0 pointer-events-none">
            <svg className="w-full h-full opacity-20">
              {/* Animated Lines */}
              <g className="animate-pulse">
                <line
                  x1="10%"
                  y1="20%"
                  x2="30%"
                  y2="40%"
                  stroke="url(#gradient1)"
                  strokeWidth="2"
                  className="animate-draw"
                />
                <line
                  x1="30%"
                  y1="40%"
                  x2="50%"
                  y2="20%"
                  stroke="url(#gradient1)"
                  strokeWidth="2"
                  className="animate-draw-delay-1"
                />
                <line
                  x1="50%"
                  y1="20%"
                  x2="70%"
                  y2="60%"
                  stroke="url(#gradient1)"
                  strokeWidth="2"
                  className="animate-draw-delay-2"
                />
                <line
                  x1="70%"
                  y1="60%"
                  x2="90%"
                  y2="30%"
                  stroke="url(#gradient1)"
                  strokeWidth="2"
                  className="animate-draw-delay-3"
                />
              </g>

              {/* Network Nodes */}
              <circle
                cx="10%"
                cy="20%"
                r="4"
                fill="#3B82F6"
                className="animate-ping-slow"
              >
                <animate
                  attributeName="fill"
                  values="#3B82F6;#06B6D4;#3B82F6"
                  dur="2s"
                  repeatCount="indefinite"
                />
              </circle>
              <circle
                cx="30%"
                cy="40%"
                r="4"
                fill="#06B6D4"
                className="animate-ping-slow animation-delay-500"
              >
                <animate
                  attributeName="fill"
                  values="#06B6D4;#3B82F6;#06B6D4"
                  dur="2s"
                  repeatCount="indefinite"
                />
              </circle>
              <circle
                cx="50%"
                cy="20%"
                r="4"
                fill="#3B82F6"
                className="animate-ping-slow animation-delay-1000"
              >
                <animate
                  attributeName="fill"
                  values="#3B82F6;#06B6D4;#3B82F6"
                  dur="2s"
                  repeatCount="indefinite"
                />
              </circle>
              <circle
                cx="70%"
                cy="60%"
                r="4"
                fill="#06B6D4"
                className="animate-ping-slow animation-delay-1500"
              >
                <animate
                  attributeName="fill"
                  values="#06B6D4;#3B82F6;#06B6D4"
                  dur="2s"
                  repeatCount="indefinite"
                />
              </circle>
              <circle
                cx="90%"
                cy="30%"
                r="4"
                fill="#3B82F6"
                className="animate-ping-slow animation-delay-2000"
              >
                <animate
                  attributeName="fill"
                  values="#3B82F6;#06B6D4;#3B82F6"
                  dur="2s"
                  repeatCount="indefinite"
                />
              </circle>

              {/* Gradient Definitions */}
              <defs>
                <linearGradient
                  id="gradient1"
                  x1="0%"
                  y1="0%"
                  x2="100%"
                  y2="100%"
                >
                  <stop offset="0%" stopColor="#3B82F6" stopOpacity="0.8" />
                  <stop offset="100%" stopColor="#06B6D4" stopOpacity="0.4" />
                </linearGradient>
              </defs>
            </svg>
          </div>

          {/* Hexagonal Grid Pattern */}
          <div className="absolute inset-0 opacity-5">
            <svg className="w-full h-full">
              <defs>
                <pattern
                  id="hexagons"
                  x="0"
                  y="0"
                  width="100"
                  height="87"
                  patternUnits="userSpaceOnUse"
                >
                  <polygon
                    points="50,1 95,25 95,75 50,99 5,75 5,25"
                    fill="none"
                    stroke="red"
                    strokeWidth="1"
                  />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#hexagons)" />
            </svg>
          </div>
        </div>

        <div
          className="bg-white/95 backdrop-blur-lg rounded-3xl shadow-2xl w-full h-screen md:w-auto md:h-auto px-4 md:px-8 py-2 md:py-8 border border-white/20"
          style={{ boxShadow: "0 8px 32px 0 rgba(31, 38, 135, 0.37)" }}
        >
          <div className="lg:hidden p-2 left-4 z-40">
            <img src={logodark} alt="Logo" className="h-8" />
          </div>
          <div className="text-center mt-14 md:mt-0 mb-8">
            <div className="flex items-center justify-center space-x-2 mb-4">
              <div className="w-12 h-12 bg-gradient-to-br from-gray-800 via-blue-800 to-cyan-800 rounded-xl flex items-center justify-center">
                <Building className="w-8 h-8 text-white" />
              </div>
              <span className="text-2xl font-bold bg-gradient-to-br from-gray-800 via-blue-800 to-cyan-800 bg-clip-text text-transparent">
                Admin Portal
              </span>
            </div>
            <p className="text-gray-600">Secure administrative login</p>
          </div>

          <form className="space-y-6" onSubmit={generateOtp}>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-[2px]">
                  Admin ID
                </label>
                <div className="relative">
                  <User className="w-5 h-5 text-gray-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    required
                    // value={formData.adminId}
                    onChange={(e) =>
                      setFormData({ ...formData, email: e.target.value })
                    }
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent transition-all bg-white/50"
                    placeholder="Enter admin ID"
                    disabled={isLoading}
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-[2px]">
                  Password
                </label>
                <div className="relative">
                  <Lock className="w-5 h-5 text-gray-400 absolute left-3 top-3" />
                  <input
                    type={showPassword ? "text" : "password"}
                    required
                    // value={formData.password}
                    onChange={(e) =>
                      setFormData({ ...formData, password: e.target.value })
                    }
                    className="w-full pl-10 pr-12 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent transition-all bg-white/50"
                    placeholder="Enter admin password"
                    disabled={isLoading}
                  />
                  <button
                    type="button"
                    onClick={togglePasswordVisibility}
                    className="absolute right-3 top-3 hover:scale-110 transition-transform"
                    disabled={isLoading}
                  >
                    {showPassword ? (
                      <EyeOff className="w-5 h-5 text-gray-400" />
                    ) : (
                      <Eye className="w-5 h-5 text-gray-400" />
                    )}
                  </button>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <NavLink
                to="/forgot-password" // Fixed typo: forgate -> forgot
                className="text-sm text-blue-600 hover:text-blue-500 font-medium"
              >
                Forgot password?
              </NavLink>
            </div>

            <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4">
              <div className="flex">
                <Shield className="w-5 h-5 text-yellow-600 mr-2 mt-0.5" />
                <div>
                  <h4 className="text-sm font-medium text-yellow-800">
                    Security Notice
                  </h4>
                  <p className="text-sm text-yellow-700 mt-1">
                    This is a restricted area. All access attempts are logged
                    and monitored.
                  </p>
                </div>
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-2 px-4 bg-gradient-to-br from-cyan-900 to-blue-600 text-white rounded-lg font-semibold hover:shadow-xl transform hover:scale-105 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
            >
              {isLoading ? "Logging in..." : "Admin Login"}
            </button>

            <Link
              to="/"
              className="w-full mt-4 py-2 text-gray-600 text-center hover:text-gray-800 transition-colors block"
            >
              <p className="mt-4">← Back to Home</p>
            </Link>
          </form>
        </div>
      </div>
    </div>
  );
};

export default AdminLogin;
