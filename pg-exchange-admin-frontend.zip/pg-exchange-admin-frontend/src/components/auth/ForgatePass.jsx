import { useEffect, useState } from "react";
import logoLight from "../../assets/imgages/payglobal-logo-light.png";
import logodark from "../../assets/imgages/payglobal-logo.png";

import img3 from "./../../assets/imgages/img3.png";
import { motion } from "framer-motion";
import {
  TrendingUp,
  Shield,
  Bitcoin,
  Coins,
  Lock,
  Eye,
  EyeOff,
  Mail,
} from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { fetchApi } from "../../assets/js/function";
import OtpValidation from "./OtpValidition";
import toast from "react-hot-toast";

const FloatingElement = ({ children, delay = 0, duration = 3 }) => {
  return (
    <div
      className="animate-bounce"
      style={{
        animationDelay: `${delay}s`,
        animationDuration: `${duration}s`,
      }}
    >
      {children}
    </div>
  );
};

const ForgatePass = ({ setCurrentPage }) => {
  const [showPassword, setShowPassword] = useState(false);
  const [showPasswordArea, setShowPasswordArea] = useState(false);
  const [showcnfPassword, setShowCnfPassword] = useState(false);
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    confirmPassword: "",
    otp: "",
  });
  const [isLoading, setIsLoading] = useState(false);
  const [reset, setReset] = useState(false);
  const [userId, setuserId] = useState();
  const navigate = useNavigate();

  const [showOtpModal, setShowOtpModal] = useState(false);

  const handleOtpVerify = async (otp) => {
    // setIsLoading(true);
    console.log("req  for  otp-", otp, "userId-", userId);

    try {
      const [response, result] = await fetchApi(
        "admin/verify-otp",
        {
          identifier: userId,
          otp: otp,
          purpose: "admin_forget_password",
          type: "forgot_password",
        },
        "POST"
      );

      console.log("OTP verification result:", result);

      if (result.success) {
        toast.success("OTP verified successfully!");
        setIsLoading(false);
        setShowOtpModal(false);
        setShowPasswordArea(true);
        formData.otp = otp;
      } else {
        if (result.requiresResend) {
          setIsLoading(false);
          setReset((prev) => !prev);
          toast.error(`${result.message} Please resend OTP.`);
        } else {
          setIsLoading(false);
          toast.error(result.message);
          setReset((prev) => !prev);
        }
        setIsLoading(false);
      }
    } catch (error) {
      setIsLoading(false);
      console.error("OTP verification error:", error);
      toast.error("OTP verification failed. Please try again.");
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const [response, result] = await fetchApi(
        "admin/forgot-password",
        { email: formData.email },
        "POST"
      );

      console.log("Forgot password result:", result);

      if (result.success) {
        toast.success(result.message);
        setuserId(result.userId || formData.email);
        setShowOtpModal(true);
        console.log("result--", result);
      } else {
        toast.error(result.message);
      }
    } catch (error) {
      console.error("Forgot password error:", error);
      toast.error("Failed to process request. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleResendOtp = async () => {
    setIsLoading(true);

    try {
      const [response, result] = await fetchApi(
        "user/resend-otp",
        {
          identifier: userId,
          purpose: "admin_forget_password",
          type: "forgot_password",
        },
        "POST"
      );

      console.log("Resend OTP result:", result);

      if (result.success) {
        toast.success(result.message);
        setReset((prev) => !prev);
      } else {
        toast.error(result.message);
      }
    } catch (error) {
      console.error("Resend OTP error:", error);
      toast.error("Failed to resend OTP. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmitresetPassword = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    if (formData.password === formData.confirmPassword) {
      try {
        const [response, result] = await fetchApi(
          "admin/reset-password",
          {
            identifier: userId,
            otp: formData.otp,
            newPassword: formData.password,
            purpose: "admin_forget_password",
            type: "forgot_password",
          },
          "POST"
        );

        console.log("Forgot password result:-", result);

        if (result.success) {
          toast.success(result.message);
          setShowOtpModal(false);
          navigate("/admin-login");
          console.log("result--", result);
          setIsLoading(false);
        } else {
          toast.error(result.message);
          setIsLoading(false);
        }
      } catch (error) {
        console.error("Forgot password error:", error);
        toast.error("Failed to process request. Please try again.");
      } finally {
        setIsLoading(false);
      }
    } else {
      toast.error("password and confirm password  not matched");
      setIsLoading(false);
    }
  };

  useEffect(() => {
    const particleContainer = document.querySelector(".bg-animations");

    const interval = setInterval(() => {
      const particle = document.createElement("div");
      particle.className = "particle";
      particle.style.left = Math.random() * 100 + "vw";
      particle.style.animationDelay = Math.random() * 2 + "s";
      particle.style.animationDuration = Math.random() * 3 + 50 + "s";
      particleContainer.appendChild(particle);

      setTimeout(() => {
        particle.remove();
      }, 80000);
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen flex relative overflow-hidden">
      <OtpValidation
        isOpen={showOtpModal}
        onVerify={handleOtpVerify}
        reset={reset}
        handleResendOtp={handleResendOtp}
        title="Verify Your Identity"
        description="Enter the 4-digit code sent to your registered mobile no."
      />
      <div className="absolute inset-0 bg-white">
        <div className="absolute top-20 left-20 opacity-20">
          <FloatingElement>
            <Bitcoin className="w-16 h-16 text-white" />
          </FloatingElement>
        </div>
        <div className="absolute top-40 right-40 opacity-20">
          <FloatingElement delay={1}>
            <Coins className="w-12 h-12 text-white" />
          </FloatingElement>
        </div>
        <div className="absolute bottom-40 left-40 opacity-20">
          <FloatingElement delay={2}>
            <Shield className="w-14 h-14 text-white" />
          </FloatingElement>
        </div>
        <div className="absolute bottom-20 right-20 opacity-20">
          <FloatingElement delay={0.5}>
            <TrendingUp className="w-10 h-10 text-white" />
          </FloatingElement>
        </div>
      </div>

      <div className="bg-animations absolute inset-0 w-full h-full pointer-events-none overflow-hidden"></div>

      <div className="hidden lg:block fixed top-10 left-16 z-20">
        <img src={logoLight} alt="Logo" className="h-8" />
      </div>
      <div className="hidden lg:flex lg:w-1/2 relative z-10 items-center justify-center p-12  bg-gradient-to-br from-cyan-800  to-blue-500">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-0 left-1/4 animate-fall-slow opacity-10">
            <div className="text-6xl font-bold text-blue-500">₿</div>
          </div>
          <div className="absolute top-0 right-1/3 animate-fall-medium opacity-10">
            <div className="text-4xl font-bold text-cyan-500">Ξ</div>
          </div>
          <div className="absolute top-0 left-2/3 animate-fall-fast opacity-10">
            <div className="text-5xl font-bold text-green-500">$</div>
          </div>
          <div className="absolute inset-0 opacity-5">
            <svg className="w-full h-full">
              <defs>
                <pattern
                  id="hexagons"
                  x="0"
                  y="0"
                  width="100"
                  height="87"
                  patternUnits="userSpaceOnUse"
                >
                  <polygon
                    points="50,1 95,25 95,75 50,99 5,75 5,25"
                    fill="none"
                    stroke="#d7d8d9"
                    strokeWidth="1"
                  />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#hexagons)" />
            </svg>
          </div>
        </div>

        <div className="text-center text-white space-y-8">
          <div className="space-y-4">
            <div className="relative z-10">
              <motion.img
                src={img3}
                alt="animated"
                animate={{ y: [0, -10, 0] }}
                transition={{
                  duration: 4,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
                className="rounded-lg"
                style={{ width: "400px", height: "auto", objectFit: "cover" }}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-6 max-w-md mx-auto">
            <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-4 text-center">
              <div className="text-2xl font-bold">2M+</div>
              <div className="text-sm opacity-80">Trusted Users</div>
            </div>
            <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-4 text-center">
              <div className="text-2xl font-bold">$50B</div>
              <div className="text-sm opacity-80">Trading Volume</div>
            </div>
          </div>
        </div>
      </div>

      <div className="w-full lg:w-1/2 flex items-center justify-center p-0 md:p-8 relative z-10">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute -top-40 -right-40 w-80 h-80 bg-blue-300/20 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-cyan-300/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
          <div className="absolute top-20 left-10 animate-float">
            <div className="w-16 h-16 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center shadow-lg">
              <span className="text-white font-bold text-xl">₿</span>
            </div>
          </div>

          <div className="absolute top-40 right-20 animate-float-delay-1">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-400 to-purple-500 rounded-full flex items-center justify-center shadow-lg">
              <span className="text-white font-bold">Ξ</span>
            </div>
          </div>

          <div className="absolute bottom-32 left-20 animate-float-delay-2">
            <div className="w-14 h-14 bg-gradient-to-br from-green-400 to-blue-500 rounded-full flex items-center justify-center shadow-lg">
              <span className="text-white font-bold">$</span>
            </div>
          </div>

          <div className="absolute top-1/2 right-10 animate-float-delay-3">
            <div className="w-10 h-10 bg-gradient-to-br from-pink-400 to-red-500 rounded-full flex items-center justify-center shadow-lg">
              <span className="text-white font-bold text-xs">ADA</span>
            </div>
          </div>

          <div className="absolute inset-0 pointer-events-none">
            <svg className="w-full h-full opacity-20">
              <g className="animate-pulse">
                <line
                  x1="10%"
                  y1="20%"
                  x2="30%"
                  y2="40%"
                  stroke="url(#gradient1)"
                  strokeWidth="2"
                  className="animate-draw"
                />
                <line
                  x1="30%"
                  y1="40%"
                  x2="50%"
                  y2="20%"
                  stroke="url(#gradient1)"
                  strokeWidth="2"
                  className="animate-draw-delay-1"
                />
                <line
                  x1="50%"
                  y1="20%"
                  x2="70%"
                  y2="60%"
                  stroke="url(#gradient1)"
                  strokeWidth="2"
                  className="animate-draw-delay-2"
                />
                <line
                  x1="70%"
                  y1="60%"
                  x2="90%"
                  y2="30%"
                  stroke="url(#gradient1)"
                  strokeWidth="2"
                  className="animate-draw-delay-3"
                />
              </g>

              <circle
                cx="10%"
                cy="20%"
                r="4"
                fill="#3B82F6"
                className="animate-ping-slow"
              >
                <animate
                  attributeName="fill"
                  values="#3B82F6;#06B6D4;#3B82F6"
                  dur="2s"
                  repeatCount="indefinite"
                />
              </circle>
              <circle
                cx="30%"
                cy="40%"
                r="4"
                fill="#06B6D4"
                className="animate-ping-slow animation-delay-500"
              >
                <animate
                  attributeName="fill"
                  values="#06B6D4;#3B82F6;#06B6D4"
                  dur="2s"
                  repeatCount="indefinite"
                />
              </circle>
              <circle
                cx="50%"
                cy="20%"
                r="4"
                fill="#3B82F6"
                className="animate-ping-slow animation-delay-1000"
              >
                <animate
                  attributeName="fill"
                  values="#3B82F6;#06B6D4;#3B82F6"
                  dur="2s"
                  repeatCount="indefinite"
                />
              </circle>
              <circle
                cx="70%"
                cy="60%"
                r="4"
                fill="#06B6D4"
                className="animate-ping-slow animation-delay-1500"
              >
                <animate
                  attributeName="fill"
                  values="#06B6D4;#3B82F6;#06B6D4"
                  dur="2s"
                  repeatCount="indefinite"
                />
              </circle>
              <circle
                cx="90%"
                cy="30%"
                r="4"
                fill="#3B82F6"
                className="animate-ping-slow animation-delay-2000"
              >
                <animate
                  attributeName="fill"
                  values="#3B82F6;#06B6D4;#3B82F6"
                  dur="2s"
                  repeatCount="indefinite"
                />
              </circle>

              {/* Gradient Definitions */}
              <defs>
                <linearGradient
                  id="gradient1"
                  x1="0%"
                  y1="0%"
                  x2="100%"
                  y2="100%"
                >
                  <stop offset="0%" stopColor="#3B82F6" stopOpacity="0.8" />
                  <stop offset="100%" stopColor="#06B6D4" stopOpacity="0.4" />
                </linearGradient>
              </defs>
            </svg>
          </div>
          <div className="absolute inset-0 opacity-5">
            <svg className="w-full h-full">
              <defs>
                <pattern
                  id="hexagons"
                  x="0"
                  y="0"
                  width="100"
                  height="87"
                  patternUnits="userSpaceOnUse"
                >
                  <polygon
                    points="50,1 95,25 95,75 50,99 5,75 5,25"
                    fill="none"
                    stroke="red"
                    strokeWidth="1"
                  />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#hexagons)" />
            </svg>
          </div>
        </div>
        <div className="w-full max-w-md">
          <div
            className="bg-white/95 backdrop-blur-lg md:rounded-3xl shadow-2xl p-8 border border-white/20"
            style={{ boxShadow: "0 8px 32px 0 rgba(31, 38, 135, 0.37)" }}
          >
            <div className="lg:hidden top-4 left-4 z-40">
              <img src={logodark} alt="Logo" className="h-8" />
            </div>
            <div className="text-center mb-8">
              <div className="flex items-center justify-center space-x-2 mb-4 lg:hidden">
                <div className="w-12 h-12 bg-gradient-to-r from-gray-800 to-cyan-600 rounded-xl flex items-center justify-center">
                  <Bitcoin className="w-8 h-8 text-white" />
                </div>
              </div>
              <h2 className="text-3xl font-bold them-sec mb-1">
                Forgate Password
              </h2>
              <p className="text-gray-600">Reset Your Password here</p>
            </div>

            {!showPasswordArea ? (
              <form className="space-y-6" onSubmit={handleSubmit}>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-[2px]">
                      Email Address
                    </label>
                    <div className="relative">
                      <Mail className="w-5 h-5 text-gray-400 absolute left-3 top-3" />
                      <input
                        type="email"
                        required
                        value={formData.email}
                        onChange={(e) =>
                          setFormData({ ...formData, email: e.target.value })
                        }
                        className="w-full pl-10 pr-4 py-2 focus:outline-none  border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all bg-white/50 "
                        placeholder="Enter your email"
                      />
                    </div>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-2 px-4 bg-gradient-to-br from-cyan-700  to-blue-500 text-white rounded-xl font-semibold hover:shadow-xl transform hover:scale-105 transition-all duration-300 disabled:opacity-50"
                >
                  {isLoading ? "Signing In..." : "Sign In"}
                </button>

                <div className="text-center">
                  <p className="text-gray-600">
                    Go to Login page{" "}
                    <Link
                      to="/admin-login"
                      className="text-blue-600 hover:text-blue-500 font-medium"
                    >
                      Log in
                    </Link>
                  </p>
                </div>

                <Link
                  to="/"
                  className="w-full mt-4 py-2 text-gray-600 hover:text-gray-800 transition-colors ml-[33%]"
                >
                  ← Back to Home
                </Link>
              </form>
            ) : (
              <form className="space-y-6" onSubmit={handleSubmitresetPassword}>
                <div className="space-y-4">
                  {/* <div>
                  <label className="block text-sm font-medium text-gray-700 mb-[2px]">
                    Email Address
                  </label>
                  <div className="relative">
                    <Mail className="w-5 h-5 text-gray-400 absolute left-3 top-3" />
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) =>
                        setFormData({ ...formData, email: e.target.value })
                      }
                      className="w-full pl-10 pr-4 py-2 focus:outline-none  border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all bg-white/50 "
                      placeholder="Enter your email"
                    />
                  </div>
                </div> */}

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-[2px]">
                      Password
                    </label>
                    <div className="relative">
                      <Lock className="w-5 h-5 text-gray-400 absolute left-3 top-3" />
                      <input
                        type={showPassword ? "text" : "password"}
                        required
                        value={formData.password}
                        onChange={(e) =>
                          setFormData({ ...formData, password: e.target.value })
                        }
                        className="w-full pl-10 pr-4 py-2 focus:outline-none  border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all bg-white/50 "
                        placeholder="Enter your password"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-3 hover:scale-110 transition-transform"
                      >
                        {showPassword ? (
                          <EyeOff className="w-5 h-5 text-gray-400" />
                        ) : (
                          <Eye className="w-5 h-5 text-gray-400" />
                        )}
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-[2px]">
                      Confirm Password
                    </label>
                    <div className="relative">
                      <Lock className="w-5 h-5 text-gray-400 absolute left-3 top-3" />
                      <input
                        type={showcnfPassword ? "text" : "password"}
                        required
                        value={formData.confirmPassword}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            confirmPassword: e.target.value,
                          })
                        }
                        className="w-full pl-10 pr-4 py-2 focus:outline-none  border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all bg-white/50 "
                        placeholder="Confirm your password"
                      />
                      <button
                        type="button"
                        onClick={() => setShowCnfPassword(!showcnfPassword)}
                        className="absolute right-3 top-3 hover:scale-110 transition-transform"
                      >
                        {showcnfPassword ? (
                          <EyeOff className="w-5 h-5 text-gray-400" />
                        ) : (
                          <Eye className="w-5 h-5 text-gray-400" />
                        )}
                      </button>
                    </div>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-2 px-4 bg-gradient-to-br from-cyan-700  to-blue-500 text-white rounded-xl font-semibold hover:shadow-xl transform hover:scale-105 transition-all duration-300 disabled:opacity-50"
                >
                  {isLoading ? "Submiting..." : "Submit"}
                </button>

                <div className="text-center">
                  <p className="text-gray-600">
                    Don't have an account?{" "}
                    <Link
                      to="/signup"
                      className="text-blue-600 hover:text-blue-500 font-medium"
                    >
                      Sign up
                    </Link>
                  </p>
                </div>

                <Link
                  to="/"
                  className="w-full mt-4 py-2 text-gray-600 hover:text-gray-800 transition-colors ml-[33%]"
                >
                  ← Back to Home
                </Link>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ForgatePass;
