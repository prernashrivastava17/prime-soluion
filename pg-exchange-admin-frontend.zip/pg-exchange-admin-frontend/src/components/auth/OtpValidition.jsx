import React, { useState, useRef, useEffect } from "react";
import "../../assets/css/Otpvalidation.css";

export default function OtpValidation({
  isOpen,
  onVerify,
  reset,
  handleResendOtp,
  title = "Enter OTP Code",
  description = "We've sent a 4-digit code to your email",
}) {
  const [otp, setOtp] = useState(["", "", "", ""]);
  const [isComplete, setIsComplete] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const inputRefs = useRef([]);

  // Reset state when modal opens/closes
  useEffect(() => {
    if (isOpen) {
      setOtp(["", "", "", ""]);
      setIsComplete(false);
      setIsSuccess(false);
      setIsVerifying(false);
      // Focus first input when modal opens
      setTimeout(() => {
        if (inputRefs.current[0]) {
          inputRefs.current[0].focus();
        }
      }, 100);
    }
  }, [isOpen]);

  useEffect(() => {
    if (otp.every((digit) => digit !== "")) {
      setIsComplete(true);
    } else {
      setIsComplete(false);
      setIsSuccess(false);
    }
  }, [otp]);

  const handleChange = (index, value) => {
    if (isNaN(value)) return;

    const newOtp = [...otp];
    newOtp[index] = value.slice(-1);
    setOtp(newOtp);

    if (value && index < 3) {
      inputRefs.current[index + 1].focus();
    }
  };

  const handleKeyDown = (index, e) => {
    if (e.key === "Backspace" && !otp[index] && index > 0) {
      inputRefs.current[index - 1].focus();
    }
  };

  const handlePaste = (e) => {
    e.preventDefault();
    const pastedData = e.clipboardData.getData("text").slice(0, 4);
    if (!/^\d+$/.test(pastedData)) return;

    const newOtp = [...otp];
    pastedData.split("").forEach((char, i) => {
      if (i < 4) newOtp[i] = char;
    });
    setOtp(newOtp);

    const lastFilledIndex = Math.min(pastedData.length - 1, 3);
    inputRefs.current[lastFilledIndex].focus();
  };

  const handleVerify = async () => {
    setIsVerifying(true);
    const otpCode = otp.join("");
    onVerify(otpCode);
  };
  useEffect(() => {
    handleReset();
  }, [reset]);
  const handleReset = () => {
    setOtp(["", "", "", ""]);
    setIsComplete(false);
    setIsSuccess(false);
    setIsVerifying(false);
    if (inputRefs.current[0]) {
      inputRefs.current[0].focus();
    }
  };

  //   const handleClose = () => {
  //     if (onClose) {
  //       onClose();
  //     }
  //   };

  // Don't render if not open
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-[#0000006b] bg-opacity-50 flex items-center justify-center p-4 z-50 backdrop-blur-sm">
      <div className="w-full max-w-md">
        <div className="bg-white rounded-3xl shadow-2xl p-8 backdrop-blur-sm bg-opacity-90 border border-gray-100 relative">
          {/* Close Button */}
          {/* <button
            onClick={handleClose}
            className="absolute top-4 right-4 w-8 h-8 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center transition-colors"
          > 
            <svg
              className="w-4 h-4 text-gray-600"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M6 18L18 6M6 6l12 12"
              />
            </svg>
          </button>*/}

          {/* Header */}
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-blue-500 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
              <svg
                className="w-8 h-8 text-white"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"
                />
              </svg>
            </div>
            <h2 className="text-2xl font-bold text-gray-800 mb-2">{title}</h2>
            <p className="text-gray-500 text-sm">{description}</p>
          </div>

          {/* OTP Input Fields */}
          <div className="flex justify-center gap-3 mb-8">
            {otp.map((digit, index) => (
              <input
                key={index}
                ref={(el) => (inputRefs.current[index] = el)}
                type="text"
                inputMode="numeric"
                maxLength={1}
                value={digit}
                onChange={(e) => handleChange(index, e.target.value)}
                onKeyDown={(e) => handleKeyDown(index, e)}
                onPaste={handlePaste}
                className={`w-16 h-16 text-center text-2xl font-bold rounded-xl border-2 transition-all duration-300 focus:outline-none ${
                  isSuccess
                    ? "border-green-500 bg-green-50 text-green-600"
                    : digit
                    ? "border-purple-500 bg-purple-50 text-purple-700 shadow-md"
                    : "border-gray-300 bg-gray-50 text-gray-700 focus:border-purple-500 focus:bg-white focus:shadow-lg"
                } ${isVerifying ? "animate-pulse" : ""}`}
                disabled={isVerifying || isSuccess}
              />
            ))}
          </div>

          {/* Success Message */}
          {isSuccess && (
            <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-xl flex items-center gap-3 animate-fadeIn">
              <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center flex-shrink-0">
                <svg
                  className="w-5 h-5 text-white"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={3}
                    d="M5 13l4 4L19 7"
                  />
                </svg>
              </div>
              <span className="text-green-700 font-medium">
                OTP verified successfully!
              </span>
            </div>
          )}

          {/* Verify Button */}
          <button
            onClick={isSuccess ? handleReset : handleVerify}
            disabled={!isComplete || isVerifying}
            className={`w-full py-4 rounded-xl font-semibold text-white transition-all duration-300 ${
              isSuccess
                ? "bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 shadow-lg hover:shadow-xl"
                : isComplete
                ? "bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 shadow-lg hover:shadow-xl transform hover:scale-105"
                : "bg-gray-300 cursor-not-allowed"
            }`}
          >
            {isVerifying ? (
              <span className="flex items-center justify-center gap-2">
                <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                  <circle
                    className="opacity-25"
                    cx="12"
                    cy="12"
                    r="10"
                    stroke="currentColor"
                    strokeWidth="4"
                    fill="none"
                  />
                  <path
                    className="opacity-75"
                    fill="currentColor"
                    d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                  />
                </svg>
                Verifying...
              </span>
            ) : isSuccess ? (
              "Enter New Code"
            ) : (
              "Verify OTP"
            )}
          </button>

          {/* Resend Link */}
          <div className="text-center mt-6">
            <p className="text-gray-600 text-sm">
              Didn't receive the code?{" "}
              <button
                className="text-purple-600 font-semibold hover:text-purple-700 transition-colors cursor-pointer"
                onClick={(e) => handleResendOtp(e)}
              >
                Resend
              </button>
            </p>
          </div>
        </div>

        {/* Info Text */}
        <p className="text-center text-gray-500 text-xs mt-6">
          This code will expire in 5 minutes
        </p>
      </div>
    </div>
  );
}
