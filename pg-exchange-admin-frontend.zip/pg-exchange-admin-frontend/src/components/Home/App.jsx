import { useState } from "react";
import "./App.css";
import CryptoExchangeApp from "./ExchangeLeanding";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
} from "react-router-dom";
import LoginPage from "./components/auth/LoginPage";
import Signup from "./components/auth/Signup";
import AdminLogin from "./components/auth/AdminLogin";
import Dashboard from "./components/Dashboard/Dashboard";
import Home from "./components/Home/Home";
import Profile from "./components/Profile/Profile";
import TransactionHistory from "./components/TransactionHistory/TransactionHistory";
import ForgatePass from "./components/auth/ForgatePass";
import QRPayment from "../auth/payment/QRPayment";

// Auth check function
const isAuthenticated = () => {
  try {
    const adminData = localStorage.getItem("adminData");
    return !!adminData; // Returns true if userData exists, false otherwise
  } catch {
    return false;
  }
};

// Protected route wrapper
const RequireAuth = ({ children }) => {
  return isAuthenticated() ? children : <Navigate to="/admin-login" replace />;
};

// Public route wrapper (redirect to dashboard if already authenticated)
const PublicRoute = ({ children }) => {
  return !isAuthenticated() ? children : <Navigate to="/dashboard" replace />;
};

function App() {
  return (
    <Router>
      <Routes>
        {/* Public routes - only accessible when NOT logged in */}
        <Route
          path="/"
          element={
            <PublicRoute>
              <CryptoExchangeApp />
            </PublicRoute>
          }
        />
        <Route
          path="/admin-login"
          element={
            <PublicRoute>
              <LoginPage />
            </PublicRoute>
          }
        />
        <Route
          path="/signup"
          element={
            <PublicRoute>
              <Signup />
            </PublicRoute>
          }
        />
        <Route
          path="/forgate-password"
          element={
            <PublicRoute>
              <ForgatePass />
            </PublicRoute>
          }
        />
        <Route
          path="/admin-login"
          element={
            <PublicRoute>
              <AdminLogin />
            </PublicRoute>
          }
        />

        {/* Protected routes - only accessible when logged in */}
        <Route
          path="/dashboard"
          element={
            <RequireAuth>
              <Home>
                <Dashboard />
              </Home>
            </RequireAuth>
          }
        />
        <Route
          path="/payment"
          element={
            <RequireAuth>
              <Home>
                <QRPayment />
              </Home>
            </RequireAuth>
          }
        />
        <Route
          path="/profile"
          element={
            <RequireAuth>
              <Home>
                <Profile />
              </Home>
            </RequireAuth>
          }
        />
        <Route
          path="/transaction-history"
          element={
            <RequireAuth>
              <Home>
                <TransactionHistory />
              </Home>
            </RequireAuth>
          }
        />

        {/* Catch all route - redirect to appropriate page based on auth status */}
        <Route
          path="*"
          element={
            isAuthenticated() ? (
              <Navigate to="/dashboard" replace />
            ) : (
              <Navigate to="/" replace />
            )
          }
        />
      </Routes>
    </Router>
  );
}

export default App;
