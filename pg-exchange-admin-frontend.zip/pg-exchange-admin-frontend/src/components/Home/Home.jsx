import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import SideBarNavigation from "../Sidebar/Sidebar";

function Home({ children }) {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    // Double check authentication when component mounts
    const checkAuth = () => {
      try {
        const userData = localStorage.getItem("adminData");
        if (!userData) {
          navigate("/admin-login");
        }
      } catch {
        navigate("/admin-login");
      }
    };

    checkAuth();
  }, [navigate]);

  return (
    <>
      <div className="flex h-screen bg-gray-50">
        <SideBarNavigation
          isCollapsed={isCollapsed}
          setIsCollapsed={setIsCollapsed}
        />

        <div className="flex-1 overflow-auto">{children}</div>
      </div>
    </>
  );
}

export default Home;
