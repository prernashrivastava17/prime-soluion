import { NavLink } from "react-router-dom";
import {
  Home,
  Table,
  FileCheck,
  Users,
  Settings,
  Wallet,
  BarChart3,
  Sparkles,
  Menu,
  X,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { useState, useEffect } from "react";
import logo from "../../assets/imgages/payglobal-logo-light.png";
import logoSort from "../../assets/imgages/shortlogo.png";

function SideBarNavigation({ isCollapsed, setIsCollapsed }) {
  const [isMobile, setIsMobile] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const checkScreenSize = () => {
      const mobile = window.innerWidth < 768;
      setIsMobile(mobile);
      if (!mobile) {
        setIsMobileMenuOpen(false);
      }
    };

    checkScreenSize();
    window.addEventListener("resize", checkScreenSize);
    return () => window.removeEventListener("resize", checkScreenSize);
  }, []);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const toggleCollapse = () => {
    setIsCollapsed(!isCollapsed);
  };

  const handleNavClick = () => {
    if (isMobile) {
      setIsMobileMenuOpen(false);
    }
  };

  const navigationItems = [
    {
      title: "UTILITY",
      items: [
        { to: "/dashboard", icon: Home, label: "Dashboard" },
        {
          to: "/transaction-history/buy"
,
          icon: Table,
          label: "Buy Transaction History",
        },
        {
          to: "/transaction-history/withdraw"
,
          icon: Table,
          label: "Withdraw Transaction History",
        },
        { to: "/KYCValidationForm", icon: FileCheck, label: "KYC Validation" },
        { to: "/UserTable", icon: Users, label: "Users" },
      ],
    },
  ];

  return (
    <>
      {/* Mobile Toggle Button */}
      {isMobile && (
        <button
          className="fixed top-4 left-4 z-50 w-10 h-10 rounded-xl border-2 border-white/20 bg-gradient-to-br from-slate-800 to-blue-900 text-white flex items-center justify-center shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-110 lg:hidden"
          onClick={toggleMobileMenu}
          aria-label="Toggle menu"
        >
          {isMobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
      )}

      {/* Mobile Overlay */}
      {isMobile && isMobileMenuOpen && (
        <div
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40 lg:hidden"
          onClick={toggleMobileMenu}
        />
      )}

      {/* Sidebar */}
      <div
        className={`
          fixed lg:relative z-40
          flex flex-col
          bg-gradient-to-br from-slate-900 via-blue-900 to-cyan-900
          text-white
          min-h-screen
          transition-all duration-300 ease-in-out
          border-r border-white/10
          shadow-2xl
          ${
            isMobile
              ? isMobileMenuOpen
                ? "translate-x-0"
                : "-translate-x-full"
              : "translate-x-0"
          }
          ${isCollapsed && !isMobile ? "w-20" : "w-64"}
          ${isMobile ? "w-64" : ""}
        `}
      >
        {/* Header */}
        <div className="relative flex items-center justify-center p-4 md:p-6 border-b border-white/15 bg-white/5 backdrop-blur-sm">
          <div className="flex items-center justify-center transition-all duration-300">
            {/* Full Logo */}
            <img
              src={logo}
              alt="PayGlobal Logo"
              className={`${
                isCollapsed && !isMobile ? "hidden" : "block"
              } w-40 h-auto max-w-full transition-all duration-300`}
            />
            {/* Small Logo */}
            <img
              src={logoSort}
              alt="PayGlobal Logo Small"
              className={`${
                isCollapsed && !isMobile ? "block" : "hidden"
              } w-8 h-8 transition-all duration-300`}
              style={{ filter: "brightness(0) invert(1)" }}
            />
          </div>

          {/* Desktop Toggle Button */}
          {!isMobile && (
            <button
              className="absolute -right-3 top-1/2 -translate-y-1/2 w-7 h-7 rounded-xl border-2 border-white/20 bg-gradient-to-br from-slate-800 to-blue-900 text-white flex items-center justify-center shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-110 hover:bg-gradient-to-br hover:from-blue-900 hover:to-cyan-800"
              onClick={toggleCollapse}
              aria-label={isCollapsed ? "Expand sidebar" : "Collapse sidebar"}
            >
              {isCollapsed ? (
                <ChevronRight size={16} />
              ) : (
                <ChevronLeft size={16} />
              )}
            </button>
          )}
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-3 md:p-4 overflow-y-auto">
          {navigationItems.map((section) => (
            <div key={section.title} className="mb-6 last:mb-0">
              <h3
                className={`
                text-xs font-bold text-slate-300 uppercase tracking-wider mb-3 px-3 
                transition-all duration-300 
                ${
                  isCollapsed && !isMobile
                    ? "opacity-0 h-0 overflow-hidden mb-0"
                    : "opacity-100 h-auto"
                }
              `}
              >
                {section.title}
              </h3>
              <ul className="space-y-1">
                {section.items.map((item) => (
                  <li key={item.to}>
                    <NavLink
                      to={item.to}
                      className={({ isActive }) => `
                        flex items-center gap-3 p-3 rounded-xl transition-all duration-300
                        ${isCollapsed && !isMobile ? "justify-center px-3" : "px-4"}
                        ${isActive
                          ? "bg-gradient-to-r from-blue-600 to-blue-800 border border-white/30 shadow-lg"
                          : "hover:bg-white/10 hover:border-white/20 border border-transparent"
                        }
                        text-slate-200 hover:text-white
                        relative overflow-hidden group
                      `}
                      onClick={handleNavClick}
                    >
                      <div className="flex items-center justify-center w-5 h-5">
                        <item.icon className="w-5 h-5" />
                      </div>
                      <span
                        className={`
                        font-medium transition-all duration-300 
                        ${
                          isCollapsed && !isMobile
                            ? "opacity-0 w-0 absolute"
                            : "opacity-100 w-auto"
                        }
                      `}
                      >
                        {item.label}
                      </span>
                      {isCollapsed && !isMobile && (
                        <div className="absolute left-full ml-2 px-2 py-1 bg-gray-900 text-white text-sm rounded-md opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 whitespace-nowrap z-50 shadow-lg border border-white/10">
                          {item.label}
                          <div className="absolute -left-1 top-1/2 -translate-y-1/2 w-2 h-2 bg-gray-900 rotate-45"></div>
                        </div>
                      )}
                    </NavLink>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </nav>

        {/* Footer */}
        <div className="p-3 md:p-4 border-t border-white/10 bg-white/5">
          <div
            className={`
            flex items-center gap-3 p-3 rounded-xl
            bg-gradient-to-r from-blue-600/20 to-blue-800/20
            border border-white/10
            transition-all duration-300
            hover:from-blue-600/30 hover:to-blue-800/30
            ${isCollapsed && !isMobile ? "justify-center" : ""}
          `}
          >
            <Sparkles className="w-4 h-4 text-yellow-400 flex-shrink-0" />
            <span
              className={`
              font-semibold text-sm text-slate-200 transition-all duration-300 
              ${
                isCollapsed && !isMobile
                  ? "opacity-0 w-0 overflow-hidden"
                  : "opacity-100 w-auto truncate"
              }
            `}
            >
              PayGlobal Exchange
            </span>
          </div>
        </div>
      </div>
    </>
  );
}

export default SideBarNavigation;
