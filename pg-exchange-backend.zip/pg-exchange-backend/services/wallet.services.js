import axios from 'axios';
import dotenv from "dotenv";
import logger from '../utils/logger.js';

dotenv.config();

const cryptoApiClient = axios.create({
  baseURL: env.CRYPTO_API_BASE_URL,
  timeout: 10000,
});

const cryptoAPI = {
  generateMnemonic: async (chain = 'EVM') => {
    try {
      const response = await cryptoApiClient.get(`/mnemonic?chain=${chain}`);
      return response.data;
    } catch (error) {
      throw new Error('Mnemonic generation error:', error.message);
    }
  },

  generateWallet: async (chain = 'EVM') => {
    try {
      const response = await cryptoApiClient.get(`/wallets?chain=${chain}`);
      return response.data;
    } catch (error) {
      throw new Error('Wallet generation error:', error.message);
    }
  },

  getBalance: async (chain, network, address) => {
    try {
      const response = await cryptoApiClient.get(
        `/balance?chain=${chain}&network=${network}&address=${address}`
      );
      return response.data;
    } catch (error) {
      throw new Error('Balance fetch error:', error.message);
    }
  },

  getPrice: async (crypto) => {
    try {
      const response = await cryptoApiClient.get(`/price?crypto=${crypto}`);
      return response.data;
    } catch (error) {

      throw new Error('Price fetch error:', error.message);
    }
  },

  deposit: async (payload) => {
    try {
      const response = await cryptoApiClient.post('/deposit', payload);
      return response.data;
    } catch (error) {
      throw new Error('Deposit error:', error.message);
    }
  },

  withdraw: async (payload) => {
    try {
      const response = await cryptoApiClient.post('/withdraw', payload);
      return response.data;
    } catch (error) {
      throw new Error('Withdraw error:', error.message);
    }
  },

  getTransaction: async (txHash) => {
    try {
      const response = await cryptoApiClient.get(`/tx?hash=${txHash}`);
      return response.data;
    } catch (error) {
      throw new Error('Transaction fetch error:', error.message);
    }
  },
};

export default cryptoAPI;