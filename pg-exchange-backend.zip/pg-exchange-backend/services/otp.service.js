import { OTP } from "../models/OTP.model.js";
import { User } from "../models/user.model.js";
import { generateAndSendOTP } from "./nodeMailer.service.js";
const otpUrl = process.env.OTPURL;

const generateOrderId = () => {
    const prefix = "ORD";
    const randomLetters = Math.random().toString(36).substring(2, 4).toUpperCase();
    const randomNumber = Math.floor(100 + Math.random() * 900);
    return prefix + randomLetters + randomNumber;
};

const sendOtp = async (mobileNo) => {
    console.log("inside send otp")
    try {
        const otpId = generateOrderId();
        const response = await fetch(otpUrl, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ mobileNo, otpId })
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();
        console.log("OTP service response data:", data);

        if (data?.respMsg === "Success") {
            const mainData = await JSON.parse(data.respData);
            console.log("OTP sent successfully to:", mobileNo, "OTP ID:", otpId, "otp is ", mainData.Otp);
            return data.respData;
        } else {
            console.error("Error sending OTP:", data);
            throw new Error(data?.respMsg || "OTP sending failed");
        }
    } catch (error) {
        console.error("Network error sending OTP:", error);
        throw new Error("Failed to send OTP. Please try again.");
    }
};

const sendEmailOtp = async (identifier) => {

    const result = await generateAndSendOTP(identifier)
    if (result.success) {
        console.log("OTP sent successfully to:", identifier, "otp is ", result.otp);
        return {
            Otp: result.otp,
            message: result.message,
        }
    } else {
        console.log("Failed to send test email:", result.error);
    }

}

export const generateAndStoreOTP = async (identifier, type = 'phone_verification', purpose = 'signup') => {
    try {
        // Validate identifier
        if (!identifier) {
            throw new Error("Identifier (mobile number) is required");
        }

        // Check for existing blocked OTP and clean it up
        const existingBlockedOTP = await OTP.findOne({
            identifier,
            type,
            purpose,
            isBlocked: true,
            expiresAt: { $gt: new Date() }
        });

        if (existingBlockedOTP) {
            await OTP.deleteOne({ _id: existingBlockedOTP._id });
        }

        // Send OTP via external service
        // const otpData = await sendOtp(identifier);



        const otpData = await sendEmailOtp(identifier);
        console.log("otpData----", otpData);
        const parsedOtpData =
            typeof otpData === "string" ? JSON.parse(otpData) : otpData;

        const otp = parsedOtpData?.Otp;

        if (!otp) {
            throw new Error("Invalid OTP response from service");
        }

        // Set expiration (10 minutes) - Use UTC to avoid timezone issues
        const expiresAt = new Date(Date.now() + 10 * 60 * 1000);

        // Delete any existing OTPs for this identifier, type, and purpose
        await OTP.deleteMany({
            identifier,
            type,
            purpose
        });

        // Create new OTP record
        const otpRecord = await OTP.create({
            identifier,
            otp,
            type,
            purpose,
            expiresAt,
            attempts: 0,
            isBlocked: false,
            isUsed: false
        });

        console.log(`New OTP generated for ${identifier}, purpose: ${purpose}`);
        console.log(`OTP: ${otp}`);
        console.log(`OTP expires at: ${expiresAt}`);
        console.log(`Current time: ${new Date()}`);
        console.log(`Time difference: ${expiresAt - new Date()}ms`);

        return otp;

    } catch (error) {
        console.error("Error generating and storing OTP:", error);
        throw new Error("Failed to generate OTP");
    }
};

export const verifyOTP = async (identifier, userOTP, type = 'phone_verification', purpose = 'signup') => {
    console.log("=== OTP VERIFICATION STARTED ===");
    console.log("identifier:", identifier, "User OTP:", userOTP, "Type:", type, "Purpose:", purpose);

    try {
        const currentTime = new Date();
        console.log("Current server time:", currentTime);
        console.log("Current server time ISO:", currentTime.toISOString());
        console.log("Current server time UTC:", currentTime.getTime());

        let otpRecord;

        // First, try to find any OTP record regardless of status for debugging
        const anyOtpRecord = await OTP.findOne({
            identifier,
            type,
            purpose
        }).sort({ createdAt: -1 }); // Get the most recent one

        console.log("Most recent OTP record found (any status):", anyOtpRecord);

        if (anyOtpRecord) {
            console.log("OTP Record Details:");
            console.log("- OTP:", anyOtpRecord.otp);
            console.log("- Expires At:", anyOtpRecord.expiresAt);
            console.log("- Expires At UTC:", anyOtpRecord.expiresAt.getTime());
            console.log("- Is Used:", anyOtpRecord.isUsed);
            console.log("- Is Blocked:", anyOtpRecord.isBlocked);
            console.log("- Attempts:", anyOtpRecord.attempts);
            console.log("- Time until expiry:", anyOtpRecord.expiresAt - currentTime, "ms");
            console.log("- Is expired?", anyOtpRecord.expiresAt <= currentTime);
        }

        // Now find the valid OTP record
        if (purpose === 'password_reset_submit') {
            otpRecord = await OTP.findOne({
                identifier,
                type,
                purpose: "password_reset",
                isUsed: false,
                isBlocked: false,
                expiresAt: { $gt: currentTime }
            });
        } else if (purpose === 'admin_forget_password') {
            otpRecord = await OTP.findOne({
                identifier,
                type: "forgot_password",
                purpose: "admin_forget_password",
                isUsed: false,
                isBlocked: false,
                expiresAt: { $gt: currentTime }
            });

        } else if (purpose === 'admin_reset_password') {
            otpRecord = await OTP.findOne({
                identifier,
                type: "forgot_password",
                purpose: "admin_forget_password",
                isBlocked: false,
                expiresAt: { $gt: currentTime }
            });

        }

        else {

            otpRecord = await OTP.findOne({
                identifier,
                type,
                purpose,
                isUsed: false,
                isBlocked: false,
                expiresAt: { $gt: currentTime }
            });
        }

        console.log("Valid OTP record found:", otpRecord);

        if (!otpRecord) {
            console.log("No valid OTP record found. Checking reasons...");

            // Check for expired OTP
            const expiredRecord = await OTP.findOne({
                identifier,
                type,
                purpose,
                expiresAt: { $lte: currentTime }
            });

            if (expiredRecord) {
                console.log("❌ OTP EXPIRED:");
                console.log("- OTP expired at:", expiredRecord.expiresAt);
                console.log("- Current time:", currentTime);
                console.log("- Time difference:", currentTime - expiredRecord.expiresAt, "ms past expiry");
            }

            // Check for used OTP
            const usedRecord = await OTP.findOne({
                identifier,
                type,
                purpose,
                isUsed: true
            });

            if (usedRecord) {
                console.log("❌ OTP ALREADY USED");
            }

            // Check for blocked OTP
            const blockedRecord = await OTP.findOne({
                identifier,
                type,
                purpose,
                isBlocked: true
            });

            if (blockedRecord) {
                console.log("❌ OTP BLOCKED - Too many attempts");
            }

            // Check if no OTP exists at all
            const anyRecord = await OTP.findOne({ identifier, type, purpose });
            if (!anyRecord) {
                console.log("❌ NO OTP FOUND - Please generate a new OTP");
            }

            return {
                isValid: false,
                message: "Invalid or expired OTP. Please request a new OTP.",
                requiresResend: true
            };
        }

        console.log("✅ Valid OTP record found, proceeding with verification...");

        if (otpRecord.isBlocked) {
            console.log("❌ OTP is blocked");
            return {
                isValid: false,
                message: "Maximum attempts exceeded. Please request a new OTP.",
                requiresResend: true
            };
        }

        if (otpRecord.attempts >= 4) {
            console.log("❌ Maximum attempts reached");
            otpRecord.isBlocked = true;
            await otpRecord.save();

            return {
                isValid: false,
                message: "Maximum attempts exceeded. Please request a new OTP.",
                requiresResend: true
            };
        }

        // Increment attempts
        otpRecord.attempts += 1;
        console.log(`Attempt ${otpRecord.attempts} for OTP ${otpRecord._id}`);

        // Verify OTP
        if (otpRecord.otp === userOTP) {
            console.log("✅ OTP VERIFIED SUCCESSFULLY");
            purpose === 'admin_reset_password' ? otpRecord.isUsed = true : otpRecord.isUsed = false;
            await otpRecord.save();

            return {
                isValid: true,
                message: "OTP verified successfully",
                requiresResend: false
            };
        } else {
            console.log("❌ INVALID OTP");
            console.log("Expected:", otpRecord.otp, "Received:", userOTP);

            if (otpRecord.attempts >= 4) {
                console.log("❌ MAX ATTEMPTS REACHED - BLOCKING OTP");
                otpRecord.isBlocked = true;
                await otpRecord.save();

                return {
                    isValid: false,
                    message: "Maximum attempts exceeded. Please request a new OTP.",
                    requiresResend: true
                };
            } else {
                await otpRecord.save();

                const remainingAttempts = 4 - otpRecord.attempts;
                console.log(`Remaining attempts: ${remainingAttempts}`);

                return {
                    isValid: false,
                    message: `Invalid OTP. ${remainingAttempts} attempts remaining.`,
                    requiresResend: false,
                    remainingAttempts
                };
            }
        }
    } catch (error) {
        console.error("❌ Error verifying OTP:", error);
        throw new Error("Failed to verify OTP");
    }
};

export const cleanupExpiredOTPs = async () => {
    try {
        const result = await OTP.deleteMany({
            expiresAt: { $lt: new Date() }
        });
        console.log(`Cleaned up ${result.deletedCount} expired OTPs`);
        return result;
    } catch (error) {
        console.error("Error cleaning up expired OTPs:", error);
        throw error;
    }
};

export const generateWithdrawalOTP = async (req, res) => {
    console.log("inside generate withdrawal OTP")
    try {
        const { email } = req.body;

        if (!email) {
            return res.status(400).json({
                success: false,
                message: "email number is required"
            });
        }

        // Verify user exists
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(404).json({
                success: false,
                message: "User not found"
            });
        }

        // Generate OTP for transaction
        const generatedOTP = await generateAndStoreOTP(email, 'phone_verification', 'transaction');

        if (!generatedOTP) {
            return res.status(400).json({
                success: false,
                message: "OTP generation failed please try again."
            });
        }

        console.log("Withdrawal OTP generated for:", email);

        return res.status(200).json({
            success: true,
            message: "OTP sent successfully",
            userId: user._id
        });

    } catch (error) {
        console.error("Generate withdrawal OTP error:", error);
        return res.status(500).json({
            success: false,
            message: "Failed to generate OTP",
            error: error.message
        });
    }
};