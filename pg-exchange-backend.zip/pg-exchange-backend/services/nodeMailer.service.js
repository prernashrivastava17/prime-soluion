import nodemailer from "nodemailer";
import dotenv from "dotenv";
dotenv.config();

// Hard-coded credentials (for testing/development only)
const EMAIL_USER = process.env.EMAIL_USER;
const EMAIL_PASS = process.env.EMAIL_PASS;
const FROM_EMAIL = process.env.FROM_EMAIL;

const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
        user: EMAIL_USER,
        pass: EMAIL_PASS,
    },
});
export const generateOTP = () => {
    return Math.floor(1000 + Math.random() * 9000).toString();
};
export const sendOTPEmail = async (email, otp) => {
    const subject = "Your One-Time Password (OTP)";
    const text = `Your OTP is: ${otp}\n\nThis OTP is valid for 5 minutes.\n\nDo not share this OTP with anyone.`;
    const html = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e0e0e0; border-radius: 10px;">
            <div style="text-align: center; margin-bottom: 30px;">
                <h2 style="color: #333; margin-bottom: 10px;">One-Time Password (OTP)</h2>
                <div style="background-color: #f5f5f5; padding: 15px; border-radius: 8px; display: inline-block; margin: 20px 0;">
                    <h1 style="color: #0279e8ff; margin: 0; letter-spacing: 10px; font-size: 36px;">${otp}</h1>
                </div>
            </div>
            
            <div style="background-color: #f8f9fa; padding: 15px; border-radius: 8px; margin: 20px 0;">
                <p style="margin: 10px 0; color: #666;">
                    <strong>📱 Enter this code to complete your verification</strong>
                </p>
                <p style="margin: 10px 0; color: #666;">
                    <strong>⏰ Valid for:</strong> 5 minutes
                </p>
            </div>
            
            <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #eee;">
                <p style="color: #999; font-size: 14px;">
                    <strong>⚠️ Security Notice:</strong>
                    <br>Do not share this OTP with anyone.
                    <br>Our team will never ask for your OTP.
                    <br>If you didn't request this OTP, please ignore this email.
                </p>
            </div>
        </div>
    `;

    return await sendEmail(email, subject, text, html);
};

export const generateAndSendOTP = async (email) => {
    try {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            return {
                success: false,
                error: "Invalid email format",
                otp: null
            };
        }

        // Generate OTP
        const otp = generateOTP();

        const result = await sendOTPEmail(email, otp);

        if (result.success) {
            return {
                success: true,
                message: "OTP sent successfully",
                otp: otp,
                expiresIn: "5 minutes"
            };
        } else {
            return {
                success: false,
                error: result.error,
                otp: null
            };
        }

    } catch (error) {
        console.error("❌ Error in generateAndSendOTP:", error.message);
        return {
            success: false,
            error: "Failed to generate and send OTP",
            otp: null
        };
    }
};

export const sendEmail = async (to, subject, text, html = "", from = FROM_EMAIL) => {
    try {

        const mailOptions = {
            from: from,
            to: to,
            subject: subject.trim(),
            text: text.trim(),
        };

        if (html && html.trim() !== "") {
            mailOptions.html = html.trim();
        }

        const info = await transporter.sendMail(mailOptions);

        console.log("✅ Email sent successfully:", info.messageId);
        console.log("📧 Preview URL:", nodemailer.getTestMessageUrl(info));

        return {
            success: true,
            messageId: info.messageId,
            previewUrl: nodemailer.getTestMessageUrl(info),
            response: info.response
        };

    } catch (error) {
        console.error("❌ Error sending email:", error.message);

        // Handle specific Gmail errors
        let errorMessage = "Failed to send email";
        if (error.code === "EAUTH") {
            errorMessage = "Authentication failed. Check your email credentials.";
        } else if (error.code === "EENVELOPE") {
            errorMessage = "Invalid email address or recipient.";
        }

        return {
            success: false,
            error: errorMessage,
            details: error.message
        };
    }
};
