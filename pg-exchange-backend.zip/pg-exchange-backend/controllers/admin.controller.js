import { Admin } from "../models/Admin.model.js";
import { Kyc } from "../models/Kyc.model.js";
import { OTP } from "../models/OTP.model.js";
import { Payment } from "../models/payment.model.js";
import { transaction } from "../models/Transactions.model.js";
import { User } from "../models/user.model.js";
import { Wallet } from "../models/Wallet.model.js";
import { generateAndStoreOTP, verifyOTP } from "../services/otp.service.js";
import { hashPassword, verifyPassword } from "../utils/basicSecurity.js";
import { logger } from "../utils/logger.js";

export const AdminLogin = async (req, res) => {
    console.log("inside AdminLogin")
    try {
        const { email, password, otp } = req.body;
        const admin = await Admin.findOne({ email });

        console.log("admin found---", admin)

        const otpVerification = await verifyOTP(admin.email, otp, 'phone_verification', 'Admin-login');

        if (!otpVerification.isValid) {
            console.log("Otp verification failed")
            return res.status(400).json({
                success: false,
                message: otpVerification.message,
                requiresResend: otpVerification.requiresResend
            });
        }

        console.log("OTP verified successfully");


        if (!admin) {
            return res.status(404).json({ message: "Admin not found" });
        }
        const isValidPassword = await verifyPassword(password, admin.password);
        if (!isValidPassword) {
            return res.status(400).json({
                success: false,
                message: "Incorrect email or password"
            });
        }
        return res.status(200).json({
            success: true,
            message: "Admin logged in successfully",
            data: {
                name: admin.name,
                email: admin.email
            }
        });
    }
    catch (error) {
        console.error("Admin login error:", error);
        res.status(500).json({ message: "Internal server error" });
    }
}
export const findAdmin = async (req, res) => {
    const admin = await Admin.findOne({ email: process.env.ADMIN_EMAIL });
    if (!admin) {
        return res.status(404).json({
            message: "unable to find admin"
        })
    }

    return res.status(200).json({
        message: "admin found",
        data: admin,
    })

}
export const createDefaultAdmin = async () => {
    try {
        const adminCount = await Admin.countDocuments();

        if (adminCount === 0) {
            const hashedPassword = await hashPassword("Admin@123");

            await Admin.create({
                email: "admin@maiilinator.com",
                password: hashedPassword,
                name: "Admin",
            });

            console.log("✔ Default admin created");
        } else {
            console.log("✔ Admin already exists. Skipping default creation.");
        }

    } catch (error) {
        console.log("❌ Error in createDefaultAdmin:", error);
    }
};
export const getPendingKycs = async (req, res) => {
    console.log("inside getPendingKycs");
    try {
        const pendingKycs = await Kyc.find({
            kycStatus: "inProgress"
        }).populate('userId', 'name email');

        // Check if array is empty
        if (pendingKycs.length === 0) {
            return res.status(404).json({
                success: false,
                message: "No pending KYCs found."
            });
        }

        res.status(200).json({
            success: true,
            message: "Pending KYCs found",
            count: pendingKycs.length,
            data: pendingKycs
        });

    } catch (error) {
        console.error('Error fetching pending KYCs:', error);
        res.status(500).json({
            success: false,
            message: "Internal server error",
            error: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
};
export const approveKyc = async (req, res) => {
    try {
        const { kycId } = req.params;

        // 1. Update KYC and get the updated document
        const updatedKyc = await Kyc.findByIdAndUpdate(
            kycId,
            {
                kycStatus: 'verified',
                reviewedAt: new Date()
            },
            { new: true }
        );

        // 2. If no KYC found, stop here
        if (!updatedKyc) {
            return res.status(404).json({
                success: false,
                message: "KYC not found"
            });
        }

        // 3. Update User using updatedKyc.userId
        await User.findByIdAndUpdate(
            updatedKyc.userId,
            {
                kycStatus: 'verified',
                kycVerifiedAt: new Date()
            }
        );

        return res.status(200).json({
            success: true,
            message: "User KYC approved successfully"
        });

    } catch (error) {
        console.error("Error approving KYC:", error);

        return res.status(500).json({
            success: false,
            message: "Internal server error",
            error: process.env.NODE_ENV === "development" ? error.message : undefined
        });
    }
};
export const rejectKyc = async (req, res) => {
    try {
        const { kycId } = req.params;

        // 1. Update KYC and get the updated document
        const updatedKyc = await Kyc.findByIdAndUpdate(
            kycId,
            {
                kycStatus: 'rejected',
                reviewedAt: new Date()
            },
            { new: true }
        );

        // 2. If no KYC found, stop here
        if (!updatedKyc) {
            return res.status(404).json({
                success: false,
                message: "KYC not found"
            });
        }

        // 3. Update User using updatedKyc.userId
        await User.findByIdAndUpdate(
            updatedKyc.userId,
            {
                kycStatus: 'rejected',
            }
        );

        return res.status(200).json({
            success: true,
            message: "User KYC approved successfully"
        });

    } catch (error) {
        console.error("Error approving KYC:", error);

        return res.status(500).json({
            success: false,
            message: "Internal server error",
            error: process.env.NODE_ENV === "development" ? error.message : undefined
        });
    }
}
export const getAdminOtp = async (req, res) => {
    const { email } = req.body;
    const admin = await Admin.findOne({ email })
    if (!admin) {
        return res.status(404).json({
            success: false,
            message: "admin not found"
        });
    }

    console.log("fetched admin---- ", admin)
    const generatedOTP = await generateAndStoreOTP(admin.email, 'phone_verification', 'Admin-login');

    if (!generatedOTP) {
        return res.status(400).json({
            success: false,
            message: "OTP generation failed please try again."
        });
    }

    return res.status(200).json({
        success: true,
        message: "Otp sent to the admin mobile no."
    })
}
export const getFees = async (req, res) => {
    const { email } = req.body;
    const admin = await Admin.findOne({ email })

    if (!admin) {
        return res.status(404).json({
            success: fail,
            message: "Admin Not found",
        })
    }
    return res.status(200).json({
        success: true,
        message: "Fee fetched successfully.",
        fee: admin.fees,
    })
}
export const setFees = async (req, res) => {
    try {
        const { fees, email } = req.body;

        // Validate input
        if (!fees || !email) {
            return res.status(400).json({
                success: false,
                message: "Fees and mobile number are required."
            });
        }

        // Validate fees is a number
        if (isNaN(fees) || parseFloat(fees) < 0) {
            return res.status(400).json({
                success: false,
                message: "Fees must be a valid positive number."
            });
        }

        const admin = await Admin.findOne({ email });

        if (!admin) {
            return res.status(404).json({
                success: false,
                message: "Admin not found."
            });
        }

        // Update fees
        admin.fees = parseFloat(fees);
        await admin.save();

        return res.status(200).json({
            success: true,
            message: "Fees updated successfully.",
            data: {
                email: admin.email,
                fees: admin.fees
            }
        });

    } catch (error) {
        console.error("Error updating fees:", error);
        return res.status(500).json({
            success: false,
            message: "Internal server error while updating fees."
        });
    }
};
export const getAdminData = async (req, res) => {

    console.log("before getAdminData")
    const transactions = await transaction.find().sort({ createdAt: -1 })
    const admin = await Admin.find()
    const payments = await Payment.find().sort({ createdAt: -1 })

    console.log("inside getAdminData")
    console.log("admin--", admin)
    console.log("transactions--", transactions)
    console.log("payments--", payments)

    if (!payments || !transactions || !admin) {
        return res.status(400).json({
            success: false,
            message: "No data found",
        })
    }

    console.log("admin----data----",)

    return res.status(200).json({
        success: true,
        balance: admin[0].balance,
        transactions: transactions[0],
        fees: admin[0].fees,
        email: admin[0].email
    })
}
export const getTxns = async (req, res) => {
    try {
        const [allTxns, successTxnsCount] = await Promise.all([
            transaction.find().sort({ createdAt: -1 }),
            transaction.countDocuments({ status: "success" })
        ]);

        res.status(200).json({
            success: true,
            message: "Transaction data fetched successfully.",
            allTxnsLength: allTxns.length,
            successTxns: successTxnsCount,
            allTxns: allTxns,
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: "Error fetching transaction data.",
            error: error.message
        });
    }
}

export const getTxnsByToday = async (req, res) => {
    const { buyAssets } = req.body
    try {

        const startOfDay = new Date();
        startOfDay.setHours(0, 0, 0, 0);

        const endOfDay = new Date();
        endOfDay.setHours(23, 59, 59, 999);

        const transactions = await transaction.aggregate([
            {
                $match: {
                    createdAt: {
                        $gte: startOfDay,
                        $lte: endOfDay
                    },
                    transactionType: buyAssets ? "buy" : "withdraw"
                }
            },
            {
                $lookup: {
                    from: "users",
                    localField: "userId",
                    foreignField: "_id",
                    as: "user"
                }
            },
            {
                $unwind: "$user"
            },
            {
                $project: buyAssets ? {
                    _id: 0,
                    transactionId: 1,
                    transactionType: 1,
                    paymentId: 1,
                    amount: 1,
                    chain: 1,
                    network: 1,
                    fee: 1,
                    token: 1,
                    currency: 1,
                    status: 1,
                    txHash: 1,
                    createdAt: 1,
                    name: "$user.name"

                } : {
                    _id: 0,
                    transactionId: 1,
                    transactionType: 1,
                    toAddress: 1,
                    userFromAddress: 1,
                    paymentId: 1,
                    amount: 1,
                    chain: 1,
                    network: 1,
                    fee: 1,
                    token: 1,
                    currency: 1,
                    status: 1,
                    txHash: 1,
                    createdAt: 1,
                    name: "$user.name"

                }
            },
            {
                $sort: {
                    createdAt: -1
                }
            }
        ])
        if (transactions.length === 0) {
            return res.status(200).json({
                message: `No ${buyAssets ? "buy" : "withdraw"} Transection Found for today`,
                data: []
            })
        }
        return res.status(200).json({
            message: "Transection fetched successfully.",
            data: transactions
        })

    } catch (error) {
        res.status(500).json({
            success: false,
            message: "Error fetching transaction data.",
            error: error.message
        });
    }
}

export const getCashTxnData = async (req, res) => {
    try {
        const txnData = await transaction.aggregate([{
            $match: { status: 'pending', transactionType: "buy", paymentMode: { $in: ['CASH', 'BANK'] } }
        }])
        console.log("txnData---", txnData)
        if (!txnData) {
            return res.status(200).json({
                message: "No pending Transactions",
                data: []
            })
        } else {
            return res.status(200).json({
                message: "Available pending Transactions",
                data: txnData
            })
        }
    } catch (error) {
        logger.error('Error in getting transaction Data', {
            message: error.message,
            stack: error.stack
        });

        res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
}

export const getWdrwTxnData = async (req, res) => {
    try {
        const txnData = await transaction.aggregate([{
            $match: { status: 'pending', transactionType: "withdraw", }
        }])
        console.log("txnData---", txnData)
        if (!txnData) {
            return res.status(200).json({
                message: "No pending Transactions",
                data: []
            })
        } else {
            return res.status(200).json({
                message: "Available pending Transactions",
                data: txnData
            })
        }
    } catch (error) {
        logger.error('Error in getting transaction Data', {
            message: error.message,
            stack: error.stack
        });

        res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
}
export const CashTxnsAction = async (req, res) => {
    const { transactionId, action, chain, remark } = req.body

    try {
        const newTransaction = await transaction.findOne({ transactionId })
        if (action.toLowerCase === "approve") {

            if (!newTransaction) {
                logger.warn('transaction not found by the transaction id.', { chain, transactionId });
                return res.status(200).json({
                    success: false,
                    message: "transaction not found."
                })
            }
            const newwallet = await Wallet.findOne({ userId: newTransaction.userId })
            const admin = (await Admin.find())[0];

            if (Number(admin.balance) < Number(newTransaction.token)) {
                logger.warn("Insufficient admin balance ", {
                    adminBalance: admin.balance,
                    userBalance: newTransaction.token
                })
                return res.status(200).json({
                    message: "Something went wront.",
                    success: false
                })
            }


            if (chain === "EVM") {
                newwallet.wallets[0].balance = Number(newwallet.wallets[0].balance) + Number(newTransaction.token)
                admin.balance = Number(admin.balance) - Number(newTransaction.token)
            } else if (chain === "TRON") {
                newwallet.wallets[1].balance = Number(newwallet.wallets[1].balance) + Number(newTransaction.token)
                admin.balance = Number(admin.balance) - Number(newTransaction.token)
            }
            else {
                return res.status(200).json({
                    success: false,
                    message: "Invalid chain"
                })
            }
        }
        else {
            newTransaction.status = "rejected"
            newTransaction.remark = remark || "Transaction Rejected"
        }
        await newTransaction.save({ validateBeforeSave: false });
        return res.status(200).json({
            success: true,
            message: `Transaction ${action === "reject" ? "rejected" : "approved"} successfully.`,
        })
    } catch (error) {
        logger.info(`unable to proceed transation`)
        res.status(500).json({
            success: false,
            message: "Error in proceeding with transation.",
            error: error.message
        });
    }










}
export const getAllUsers = async (req, res) => {
    try {
        const allUsers = await User.find().lean().sort({ createdAt: -1 });

        if (allUsers.length === 0) {
            return res.status(200).json({
                success: true,
                message: "No users found",
                userData: []
            });
        }

        return res.status(200).json({
            success: true,
            message: "Users found",
            userData: allUsers
        });

    } catch (error) {
        console.error("Error fetching users:", error);
        return res.status(500).json({
            success: false,
            message: "Server error while fetching users"
        });
    }
};
export const getuser = async (req, res) => {
    const { email } = req.body;

    try {
        // 1. Find user by email
        const userData = await User.findOne({ email });
        userData.password = undefined;
        // 2. If user not found
        if (!userData) {
            return res.status(404).json({
                message: "User not found",
                data: {
                    userData: null,
                    userKycData: null
                }
            });
        }

        // 3. Find KYC using userId
        const userKycData = await Kyc.findOne({ userId: userData._id });

        // 4. User found but KYC not found
        if (!userKycData) {
            return res.status(200).json({
                message: "User details fetched successfully, but KYC not available.",
                data: {
                    userData,
                    userKycData: null
                }
            });
        }

        // 5. Both user & KYC found
        return res.status(200).json({
            message: "User and KYC data fetched successfully.",
            data: {
                userData,
                userKycData
            }
        });

    } catch (error) {
        console.error("Error fetching user:", error);
        return res.status(500).json({
            success: false,
            message: "Server error while fetching user"
        });
    }
};
export const actionOnUser = async (req, res) => {
    try {
        const { email } = req.body;

        if (!email) {
            return res.status(400).json({
                success: false,
                message: "Mobile number is required"
            });
        }

        const user = await User.findOne({ email });

        if (!user) {
            return res.status(404).json({
                success: false,
                message: "User not found"
            });
        }

        // Toggle the verification/block status
        user.isActive = !user.isActive;
        const updatedUser = await user.save();

        return res.status(200).json({
            success: true,
            message: updatedUser.isActive
                ? "User verified/unblocked successfully"
                : "User blocked successfully",
            isActive: updatedUser.isActive,
            user: {
                email: updatedUser.email,
                name: updatedUser.name
            }
        });

    } catch (error) {
        console.error("Error in actionOnUser:", error);
        return res.status(500).json({
            success: false,
            message: "Server error while updating user"
        });
    }
};
export const forgotPassword = async (req, res) => {
    const { email } = req.body;

    if (!email) {
        return res.status(400).json({
            success: false,
            message: "Email is required"
        });
    }

    try {
        const admin = await Admin.findOne({ email: email.toLowerCase() });

        if (!admin) {
            return res.status(404).json({
                success: false,
                message: "User not found"
            });
        }

        // Generate OTP for password reset
        const generatedOTP = await generateAndStoreOTP(admin.email, 'forgot_password', 'admin_forget_password');

        if (!generatedOTP) {
            return res.status(400).json({
                success: false,
                message: "OTP generation failed please try again."
            });
        }

        return res.status(200).json({
            success: true,
            message: "OTP sent for password reset",
            userId: admin.email
        });

    } catch (error) {
        console.error("Error during forgot password:", error);
        return res.status(500).json({
            success: false,
            message: "Internal server error"
        });
    }
};
export const resetPassword = async (req, res) => {
    const { identifier, otp, newPassword } = req.body;


    console.log("req---", req.body)

    if (!identifier || !otp || !newPassword) {
        return res.status(400).json({
            success: false,
            message: "Identifier, OTP and new password are required"
        });
    }

    try {
        // Verify OTP for password reset
        const verificationResult = await verifyOTP(identifier, otp, 'forgot_password', 'admin_reset_password');

        console.log("verification Result---", verificationResult)


        if (!verificationResult.isValid) {
            // Check if resend is required
            if (verificationResult.requiresResend) {
                return res.status(400).json({
                    success: false,
                    message: verificationResult.message,
                    requiresResend: true
                });
            } else {
                return res.status(400).json({
                    success: false,
                    message: verificationResult.message,
                    requiresResend: false,
                    remainingAttempts: verificationResult.remainingAttempts
                });
            }
        }

        // Find user and update password
        const admin = await Admin.findOne({
            $or: [
                { email: identifier },
            ]
        });

        if (!admin) {
            return res.status(404).json({
                success: false,
                message: "User not found"
            });
        }

        // Update password (in production, hash the password)
        const hashedPassword = await hashPassword(newPassword);

        admin.password = hashedPassword;
        await admin.save();

        return res.status(200).json({
            success: true,
            message: "Password reset successfully"
        });

    } catch (error) {
        console.error("Error resetting password:", error);
        return res.status(500).json({
            success: false,
            message: "Internal server error"
        });
    }
};
export const otpVerify = async (req, res) => {
    const { identifier, otp, purpose = "signup", type = "phone_verification" } = req.body;

    console.log("identifier, otp -", identifier, otp, purpose);

    if (!identifier || !otp) {
        return res.status(400).json({
            success: false,
            message: "Identifier (email/mobile) and OTP are required"
        });
    }

    try {
        // Verify OTP
        const verificationResult = await verifyOTP(identifier, otp, type, purpose);

        if (!verificationResult.isValid) {
            // Check if resend is required
            if (verificationResult.requiresResend) {
                return res.status(400).json({
                    success: false,
                    message: verificationResult.message,
                    requiresResend: true
                });
            } else {
                return res.status(400).json({
                    success: false,
                    message: verificationResult.message,
                    requiresResend: false,
                    remainingAttempts: verificationResult.remainingAttempts
                });
            }
        }

        // Find user and mark as verified
        const admin = await Admin.findOne({
            $or: [
                { email: identifier },
            ]
        });

        if (!admin) {
            return res.status(404).json({
                success: false,
                message: "User not found"
            });
        }

        const otpRecord = await OTP.findOne({
            identifier,
            type: "forgot_password",
            purpose: "admin_forget_password",
            isUsed: false,
            isBlocked: false,
        });

        otpRecord.isUsed = true
        await otpRecord.save();

        return res.status(200).json({
            success: true,
            message: "OTP verified successfully.",
            data: {
                name: admin.name,
                email: admin.email,
                isVerified: true
            }
        });

    } catch (error) {
        console.error("Error verifying OTP:", error);
        return res.status(500).json({
            success: false,
            message: "Internal server error"
        });
    }
};