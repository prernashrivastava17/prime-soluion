import { v2 as cloudinary } from 'cloudinary';
import dotenv from 'dotenv';

dotenv.config();

cloudinary.config({
    cloud_name: process.env.CLOUD_NAME,
    api_key: process.env.API_KEY,
    api_secret: process.env.API_SECRET,
});

export const uploadBase64ToCloudinary = async (req, res, next) => {
    try {
        const { aadharFrontImage } = req.body;

        if (!aadharFrontImage) {
            return res.status(400).json({
                success: false,
                message: 'Image is required',
            });
        }

        const result = await cloudinary.uploader.upload(aadharFrontImage, {
            folder: 'kyc',
        });

        req.uploadedImage = result.secure_url;
        next();
    } catch (error) {
        console.log(error)
        return res.status(400).json({
            success: false,
            message: 'Image upload failed',
        });
    }
};


export const userKyctest = async (req, res) => {


    res.status(200).json({
        success: true,
        data: {
            aadharFrontImage: req.uploadedImage,
        },
    });
};
