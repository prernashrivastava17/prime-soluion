import fs from "fs";
import { Kyc } from '../models/Kyc.model.js';
import { transaction } from '../models/Transactions.model.js';
import { User } from '../models/user.model.js';
import { Wallet } from '../models/Wallet.model.js';
import { generateAndStoreOTP, verifyOTP } from '../services/otp.service.js';
import { hashPassword, verifyPassword } from '../utils/basicSecurity.js';
import cryptoAPI from '../utils/cryptoApiClient.js';
import { updateBalance } from './transaction.controller.js';
import { v2 as cloudinary } from 'cloudinary';
import axios from "axios";
import { Admin } from "../models/Admin.model.js";
import { generateAccessToken, generateRefreshToken, tokenVerification } from "../middleware/authToken.js";

const accessTokenCoockies = {
    httpOnly: true,
    samesite: "strict",
    secure: true,
    maxAge: 15 * 60 * 100
}
const refreshTokenCoockies = {
    httpOnly: true,
    secure: true,
    samesite: 'strict',
    maxAge: 7 * 24 * 60 * 60 * 100
}



export const userSignup = async (req, res) => {
    const { name, email, password } = req.body;

    console.log("Signup request:", name, email);

    try {
        if (!name || !email || !password) {
            return res.status(400).json({
                success: false,
                message: "All fields are required: name, email, password"
            });
        }

        // Check if user already exists
        const existingUser = await User.findOne({ email: email.toLowerCase() });

        // Existing & verified
        if (existingUser && existingUser.isVerified) {
            return res.status(400).json({
                success: false,
                message: "User with this email or mobile number already exists"
            });
        }

        // Existing but NOT verified
        if (existingUser && !existingUser.isVerified) {
            const generatedOTP = await generateAndStoreOTP(email, 'phone_verification', 'signup');

            if (!generatedOTP) {
                return res.status(400).json({
                    success: false,
                    message: "OTP generation failed please try again."
                });
            }

            return res.status(201).json({
                success: true,
                message: "OTP sent again",
                userId: existingUser._id
            });
        }

        // NEW USER FLOW
        const generatedOTP = await generateAndStoreOTP(email, 'phone_verification', 'signup');
        if (!generatedOTP) {
            return res.status(400).json({
                success: false,
                message: "OTP generation failed please try again."
            });
        }

        const hashedPassword = await hashPassword(password);

        // ----------------------------------------------------------
        // WALLET GENERATION
        // ----------------------------------------------------------

        const totalUsers = await User.estimatedDocumentCount();
        const userIndex = totalUsers + 1;

        console.log("Total users:", totalUsers);

        // ------------ Generate EVM Wallet -------------
        let evmWallet, evmAddress;

        try {
            evmWallet = await cryptoAPI.generateWallet("EVM");
            console.log("EVM Mnemonic:", evmWallet);

            evmAddress = await cryptoAPI.generateAddress("EVM", evmWallet, userIndex);
            console.log("EVM Address Response:", evmAddress);

            if (!evmAddress || !evmAddress.address) {
                throw new Error("Failed to generate EVM address (address is null)");
            }
        } catch (err) {
            console.error("EVM Wallet Error:", err.message);
            return res.status(500).json({
                success: false,
                message: "EVM wallet generation failed. Please try again."
            });
        }

        const hashedEvmPrivateKey = await hashPassword(evmAddress.privateKey);

        console.log("hashedEvmPrivateKey--", hashedEvmPrivateKey)

        // ------------ Generate TRON Wallet -------------
        let tronWallet, tronAddress;

        try {
            tronWallet = await cryptoAPI.generateWallet("TRON");
            console.log("TRON Mnemonic:", tronWallet);

            tronAddress = await cryptoAPI.generateAddress("TRON", tronWallet, userIndex);
            console.log("TRON Address Response:", tronAddress);

            if (!tronAddress || !tronAddress.address) {
                throw new Error("Failed to generate TRON address (address is null)");
            }
        } catch (err) {
            console.error("TRON Wallet Error:", err.message);
            return res.status(500).json({
                success: false,
                message: "TRON wallet generation failed. Please try again."
            });
        }

        const hashedTronPrivateKey = await hashPassword(tronAddress.privateKey);

        console.log("hashedTronPrivateKey---", hashedTronPrivateKey)


        console.log("------------Logger---------------------------")
        console.log("hashedEvmPrivateKey : ", hashedEvmPrivateKey)
        console.log("EVM Address :", evmAddress.address);
        console.log("---------")
        console.log("TRON Address :", tronAddress.address);

        console.log("hashedTronPrivateKey : ", hashedTronPrivateKey)
        console.log("--------------------logger end---------------------")

        // ----------------------------------------------------------
        // CREATE USER
        // ----------------------------------------------------------

        const newUser = await User.create({
            name: name.trim(),
            email: email.toLowerCase().trim(),
            password: hashedPassword,
            isVerified: false,
            wallets: [
                { chain: 'EVM', address: evmAddress.address },
                { chain: 'TRON', address: tronAddress.address },
                { chain: 'PGL', address: evmAddress.address },
            ]

        });


        console.log("newUser created----", newUser)

        // ----------------------------------------------------------
        // CREATE USER WALLET ENTRY
        // ----------------------------------------------------------

        const userWallet = await Wallet.create({
            userId: newUser._id,
            wallets: [
                {
                    chain: "EVM",
                    address: evmAddress.address,
                    privateKey: hashedEvmPrivateKey,
                    walletType: "platform"
                },
                {
                    chain: "TRON",
                    address: tronAddress.address,
                    privateKey: hashedTronPrivateKey,
                    walletType: "platform"
                },
                {
                    chain: "PGL",
                    address: evmAddress.address,
                    privateKey: hashedEvmPrivateKey,
                    walletType: "platform"
                },
            ]
        });

        console.log("User Wallet Created:", userWallet);

        return res.status(201).json({
            success: true,
            message: "User created successfully, OTP sent",
            userId: newUser._id
        });

    } catch (error) {
        console.error("Error during user signup:", error);
        return res.status(500).json({
            success: false,
            message: error.message
        });
    }
};


export const otpVerify = async (req, res) => {
    const { identifier, otp, purpose = "signup", type = "phone_verification" } = req.body;

    console.log("identifier, otp -", identifier, otp, purpose);

    if (!identifier || !otp) {
        return res.status(400).json({
            success: false,
            message: "Identifier (email/mobile) and OTP are required"
        });
    }

    try {
        // Verify OTP
        const verificationResult = await verifyOTP(identifier, otp, type, purpose);

        if (!verificationResult.isValid) {
            // Check if resend is required
            if (verificationResult.requiresResend) {
                return res.status(400).json({
                    success: false,
                    message: verificationResult.message,
                    requiresResend: true
                });
            } else {
                return res.status(400).json({
                    success: false,
                    message: verificationResult.message,
                    requiresResend: false,
                    remainingAttempts: verificationResult.remainingAttempts
                });
            }
        }

        // Find user and mark as verified
        const user = await User.findOne({
            $or: [
                { email: identifier },
            ]
        });

        if (!user) {
            return res.status(404).json({
                success: false,
                message: "User not found"
            });
        }



        user.isVerified = true;

        await user.save();

        if (purpose === "login") {
            const userWallet = await Wallet.findOne({ userId: user._id });

            if (!userWallet) {
                return res.status(404).json({
                    success: false,
                    message: "User Wallet not found"
                });
            }

            const createWalletData = (chain) => {
                const wallet = userWallet.wallets.find(w => w.chain === chain);
                return wallet ? {
                    chain: wallet.chain,
                    balance: wallet.balance,
                    address: wallet.address,
                } : null;
            };

            const responseData = {
                name: user.name,
                email: user.email,
                // mobileNo: user.mobileNo,
                isVerified: user.isVerified,
                kycStatus: user.kycStatus,
                evmWalletData: createWalletData("EVM"),
                tronWalletData: createWalletData("TRON"),
                pglWalletData: createWalletData("PGL")
            };

            // Remove null wallet data
            Object.keys(responseData).forEach(key => {
                if (responseData[key] === null) {
                    delete responseData[key];
                }
            });

            return res.status(200).json({
                success: true,
                message: "OTP verified successfully",
                data: responseData
            });
        }

        return res.status(200).json({
            success: true,
            message: "OTP verified successfully",
            data: {
                name: user.name,
                email: user.email,
                // mobileNo: user.mobileNo,
                isVerified: user.isVerified
            }
        });

    } catch (error) {
        console.error("Error verifying OTP:", error);
        return res.status(500).json({
            success: false,
            message: "Internal server error"
        });
    }
};

// User Signin
export const userSignin = async (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({
            success: false,
            message: "Email and password are required"
        });
    }

    try {
        const user = await User.findOne({ email: email.toLowerCase() });

        if (!user) {
            return res.status(404).json({
                success: false,
                message: "User not found"
            });
        }

        const isValidPassword = await verifyPassword(password, user.password);
        console.log("isValidPassword--", isValidPassword)
        if (!isValidPassword) {
            return res.status(400).json({
                success: false,
                message: "Incorrect email or password"
            });
        }

        // if (!user.isVerified) {
        //     // Resend OTP for verification

        //     return res.status(200).json({
        //         success: false,
        //         respCode: 2,
        //         message: "User not verified. OTP sent again.",
        //         userId: user.mobileNo
        //     });
        // }

        const generatedOTP = await generateAndStoreOTP(user.email, 'phone_verification', 'login');
        if (!generatedOTP) {
            return res.status(400).json({
                success: false,
                message: "OTP generation failed please try again."
            });

        }
        console.log("generatedOTP--", generatedOTP);
        console.log("user==", user);
        const accessToken = generateAccessToken(email)
        const refreshToken = generateRefreshToken(email)
        return res.status(200)
            .cookie('accessToken', accessToken, accessTokenCoockies)
            .cookie('refreshToken', refreshToken, refreshTokenCoockies)
            .json({
                success: true,
                respCode: 1,
                message: "Login successful",
                data: {
                    name: user.name,
                    email: user.email,
                    // mobileNo: user.mobileNo,
                    wallet_addresses: user.wallets.map(address => ({ chain: address.chain, address: address.address })),
                    joinDate: user.createdAt.toISOString().split('T')[0]
                }
            })

    } catch (error) {
        console.error("Error during user signin:", error);
        return res.status(500).json({
            success: false,
            message: "Internal server error"
        });
    }
};

// Forgot Password
export const forgotPassword = async (req, res) => {
    const { email } = req.body;

    if (!email) {
        return res.status(400).json({
            success: false,
            message: "Email is required"
        });
    }

    try {
        const user = await User.findOne({ email: email.toLowerCase() });

        if (!user) {
            return res.status(404).json({
                success: false,
                message: "User not found"
            });
        }

        // Generate OTP for password reset
        const generatedOTP = await generateAndStoreOTP(user.email, 'forgot_password', 'password_reset');

        if (!generatedOTP) {
            return res.status(400).json({
                success: false,
                message: "OTP generation failed please try again."
            });
        }

        return res.status(200).json({
            success: true,
            message: "OTP sent for password reset",
            userId: user.email
        });

    } catch (error) {
        console.error("Error during forgot password:", error);
        return res.status(500).json({
            success: false,
            message: "Internal server error"
        });
    }
};

// Reset Password with OTP
export const resetPassword = async (req, res) => {
    const { identifier, otp, newPassword } = req.body;

    if (!identifier || !otp || !newPassword) {
        return res.status(400).json({
            success: false,
            message: "Identifier, OTP and new password are required"
        });
    }

    try {
        // Verify OTP for password reset
        const verificationResult = await verifyOTP(identifier, otp, 'forgot_password', 'password_reset_submit');

        if (!verificationResult.isValid) {
            // Check if resend is required
            if (verificationResult.requiresResend) {
                return res.status(400).json({
                    success: false,
                    message: verificationResult.message,
                    requiresResend: true
                });
            } else {
                return res.status(400).json({
                    success: false,
                    message: verificationResult.message,
                    requiresResend: false,
                    remainingAttempts: verificationResult.remainingAttempts
                });
            }
        }

        // Find user and update password
        const user = await User.findOne({
            $or: [
                { email: identifier },
                // { mobileNo: identifier }
            ]
        });

        if (!user) {
            return res.status(404).json({
                success: false,
                message: "User not found"
            });
        }

        // Update password (in production, hash the password)
        const hashedPassword = await hashPassword(newPassword);

        user.password = hashedPassword;
        await user.save();

        return res.status(200).json({
            success: true,
            message: "Password reset successfully"
        });

    } catch (error) {
        console.error("Error resetting password:", error);
        return res.status(500).json({
            success: false,
            message: "Internal server error"
        });
    }
};

// Resend OTP
export const resendOtp = async (req, res) => {
    const { identifier, type = 'phone_verification', purpose = 'signup' } = req.body;

    if (!identifier) {
        return res.status(400).json({
            success: false,
            message: "Identifier (email/mobile) is required"
        });
    }

    try {
        // Find user
        const user = await User.findOne({
            $or: [
                { email: identifier },
                // { mobileNo: identifier }
            ]
        });

        if (!user) {
            return res.status(404).json({
                success: false,
                message: "User not found"
            });
        }

        // Generate and send new OTP
        await generateAndStoreOTP(user.email, type, purpose);

        return res.status(200).json({
            success: true,
            message: "OTP sent again",
            userId: user.email
        });
    } catch (error) {
        console.error("Error resending OTP:", error);
        return res.status(500).json({
            success: false,
            message: "Failed to resend OTP"
        });
    }
};

export const userProfile = async (req, res) => {
    try {
        const { email } = req.body;

        console.log("email---", email)

        if (!email) {
            return res.status(200).json({
                success: false,
                message: "email is required"
            });
        }

        const user = await User.findOne({ email });
        if (!user) {
            return res.status(200).json({
                success: false,
                message: "User not found"
            });
        }

        // Parallel API calls for better performance
        const [totalTransactions, successTransactions, walletData] = await Promise.all([
            transaction.find({ userId: user._id }).lean(),
            transaction.find({ userId: user._id, status: "success" }).lean(),
            updateBalance(user.email),

        ]);

        const Photo = await Kyc.find({ userId: user._id }).lean();
        console.log("Photo---", Photo)

        // Validate wallet data
        if (!walletData?.success) {
            return res.status(200).json({
                success: false,
                message: walletData?.message || "Failed to fetch wallet data"
            });
        }

        // Safe data extraction
        const walletInfo = walletData.data || {};
        const evmData = walletInfo.evmWalletData || {};
        const tronData = walletInfo.tronWalletData || {};
        const pglData = walletInfo.pglWalletData || {};

        // Calculate balances
        const balances = {
            evm: Number(evmData.balance) || 0,
            tron: Number(tronData.balance) || 0,
            pgl: Number(pglData.balance) || 0
        };

        const totalBalance = Object.values(balances).reduce((sum, balance) => sum + balance, 0);

        // Name handling
        const nameParts = user.name?.split(" ") || [];
        const firstName = nameParts[0] || "User";
        const lastName = nameParts.slice(1).join(" ") || "";

        // Statistics
        const totalTrades = totalTransactions.length;
        const successTrades = successTransactions.length;
        const successRate = totalTrades > 0 ? Math.round((successTrades / totalTrades) * 100) : 0;

        // KYC Status (implement based on your business logic)
        // const getKycStatus = () => {
        //     if (user.kycVerified) return "verified";
        //     if (user.kycSubmitted) return "pending";
        //     return "not_submitted";
        // };

        return res.status(200).json({
            success: true,
            message: "User data fetched successfully",
            data: {
                userInfo: {
                    firstName,
                    lastName,
                    emailId: user.email,
                    // mobileNo: user.mobileNo,
                    joinDate: user.createdAt,
                    passportSizePhoto: Photo[0]?.passportSizePhoto
                },
                financials: {
                    totalBalance,
                    totalTrades,
                    successTrades,
                    successRate,
                    tokens: 3 // This might need dynamic calculation
                },
                verification: {
                    status: user.kycStatus
                },
                wallets: {
                    addresses: {
                        evm: evmData.address || "Not available",
                        trx: tronData.address || "Not available",
                        pgl: pglData.address || "Not available"
                    },
                    balances: balances
                }
            }
        });

    } catch (error) {
        console.error("Error in userProfile:", error);
        return res.status(500).json({
            success: false,
            message: "Internal server error",
            error: error.message
        });
    }
};


export const getBuyTxnsByUser = async (req, res) => {
    const { email, transactionType } = req.body
    const newuser = await User.findOne({ email })
    const txn = await transaction.find({
        userId: newuser._id,
        transactionType: transactionType === "buy" ? "buy" : "withdraw"
    }).sort({ createdAt: -1 });

    if (!txn) {
        return res.status(404).json({
            message: "no transaction found.",
            data: []
        })
    }
    return res.status(200).json({
        message: "transaction fetched successfully.",
        data: txn
    })

}






// Configure Cloudinary
cloudinary.config({
    cloud_name: process.env.CLOUD_NAME,
    api_key: process.env.API_KEY,
    api_secret: process.env.API_SECRET
});

export const uploadOnCloudinary = async (localFilePath) => {
    try {
        if (!localFilePath) {
            return null;
        }
        const cloudinaryResponse = await cloudinary.uploader.upload(localFilePath, {
            resource_type: "image",
            folder: "kyc_documents" // Optional: organize files in folder
        });
        console.log("File uploaded to Cloudinary:", cloudinaryResponse.url);

        // Delete local file after successful upload
        if (fs.existsSync(localFilePath)) {
            fs.unlinkSync(localFilePath);
        }

        return cloudinaryResponse.url;

    } catch (error) {
        // Delete local file on error
        if (fs.existsSync(localFilePath)) {
            fs.unlinkSync(localFilePath);
        }
        console.error('Cloudinary upload failed:', error);
        return null;
    }
};

export const userKyc = async (req, res) => {
    const uploadedFiles = [];

    try {
        console.log('=== KYC SUBMISSION STARTED ===');
        console.log('Request files keys:', Object.keys(req.files || {}));
        console.log('Request body:', req.body);

        // Check if files exist (additional safety check)
        if (!req.files) {
            return res.status(400).json({
                success: false,
                message: "No files uploaded. Please upload all required documents."
            });
        }

        const {
            aadharFrontImage,
            aadharBackImage,
            passportSizePhoto,
            pancardImage,
            passbookFrontImage
        } = req.files;

        const {
            FullName,
            FathersName,
            DoB,
            Gender,
            Email,
            userEmail
        } = req.body;

        // Debug log each file
        console.log('File details:', {
            aadharFrontImage: aadharFrontImage ? `exists (${aadharFrontImage.length} files)` : 'missing',
            aadharBackImage: aadharBackImage ? `exists (${aadharBackImage.length} files)` : 'missing',
            passportSizePhoto: passportSizePhoto ? `exists (${passportSizePhoto.length} files)` : 'missing',
            pancardImage: pancardImage ? `exists (${pancardImage.length} files)` : 'missing',
            passbookFrontImage: passbookFrontImage ? `exists (${passbookFrontImage.length} files)` : 'missing'
        });

        // Track files for cleanup with safety checks
        if (aadharFrontImage && aadharFrontImage[0] && aadharFrontImage[0].path) {
            uploadedFiles.push(aadharFrontImage[0].path);
        }
        if (aadharBackImage && aadharBackImage[0] && aadharBackImage[0].path) {
            uploadedFiles.push(aadharBackImage[0].path);
        }
        if (passportSizePhoto && passportSizePhoto[0] && passportSizePhoto[0].path) {
            uploadedFiles.push(passportSizePhoto[0].path);
        }
        if (pancardImage && pancardImage[0] && pancardImage[0].path) {
            uploadedFiles.push(pancardImage[0].path);
        }
        if (passbookFrontImage && passbookFrontImage[0] && passbookFrontImage[0].path) {
            uploadedFiles.push(passbookFrontImage[0].path);
        }

        console.log('Files to cleanup:', uploadedFiles);

        // Validate required fields
        if (!FullName || !FathersName || !DoB || !Gender || !Email || !userEmail) {
            console.log('Missing required fields');
            cleanupFiles(uploadedFiles);
            return res.status(400).json({
                success: false,
                message: "All personal information fields are required"
            });
        }

        // Validate mobile number format
        // if (!userEmail) {
        //     console.log('');
        //     cleanupFiles(uploadedFiles);
        //     return res.status(400).json({
        //         success: false,
        //         message: "Please provide valid 10-digit mobile numbers"
        //     });
        // }

        // Validate required files with better error messages
        const missingFiles = [];
        if (!aadharFrontImage || !aadharFrontImage[0]) missingFiles.push("Aadhar Front Image");
        if (!aadharBackImage || !aadharBackImage[0]) missingFiles.push("Aadhar Back Image");
        if (!passportSizePhoto || !passportSizePhoto[0]) missingFiles.push("Passport Size Photo");
        if (!pancardImage || !pancardImage[0]) missingFiles.push("PAN Card Image");
        if (!passbookFrontImage || !passbookFrontImage[0]) missingFiles.push("Passbook Front Image");

        if (missingFiles.length > 0) {
            console.log('Missing files:', missingFiles);
            cleanupFiles(uploadedFiles);
            return res.status(400).json({
                success: false,
                message: `Missing required documents: ${missingFiles.join(', ')}`
            });
        }

        // Upload images to Cloudinary and get URLs
        console.log('Starting Cloudinary uploads...');

        let aadharFrontImageUrl, aadharBackImageUrl, passportSizePhotoUrl, pancardImageUrl, passbookFrontImageUrl;

        try {
            // Upload all files to Cloudinary in parallel
            [aadharFrontImageUrl, aadharBackImageUrl, passportSizePhotoUrl, pancardImageUrl, passbookFrontImageUrl] = await Promise.all([
                uploadOnCloudinary(aadharFrontImage[0].path),
                uploadOnCloudinary(aadharBackImage[0].path),
                uploadOnCloudinary(passportSizePhoto[0].path),
                uploadOnCloudinary(pancardImage[0].path),
                uploadOnCloudinary(passbookFrontImage[0].path)
            ]);

            console.log('Cloudinary upload results:', {
                aadharFrontImageUrl,
                aadharBackImageUrl,
                passportSizePhotoUrl,
                pancardImageUrl,
                passbookFrontImageUrl
            });

        } catch (uploadError) {
            console.error('Cloudinary upload error:', uploadError);
            cleanupFiles(uploadedFiles);
            return res.status(500).json({
                success: false,
                message: "Error uploading documents to cloud storage"
            });
        }

        // Validate that all uploads were successful
        if (!aadharFrontImageUrl || !aadharBackImageUrl || !passportSizePhotoUrl || !pancardImageUrl || !passbookFrontImageUrl) {
            console.log('Cloudinary upload failed for some files');
            cleanupFiles(uploadedFiles);
            return res.status(500).json({
                success: false,
                message: "Failed to upload one or more documents to cloud storage"
            });
        }

        // Cleanup local files after successful Cloudinary upload
        cleanupFiles(uploadedFiles);

        // Find user
        const user = await User.findOne({ email: userEmail });
        if (!user) {
            return res.status(404).json({
                success: false,
                message: "User not found."
            });
        }

        const existingKyc = await Kyc.findOne({
            $and: [
                { userId: user._id },
                // { mobileNo: mobileNo },
                { kycStatus: { $in: ["inProgress", "verified"] } }
            ]
        });


        if (existingKyc) {
            return res.status(400).json({
                success: false,
                message: "KYC already exists for this user/mobile number"
            });
        }

        // Create KYC record with Cloudinary URLs
        const userKyc = await Kyc.create({
            userId: user._id,
            // mobileNo: mobileNo,
            FullName: FullName.trim(),
            FathersName: FathersName.trim(),
            DoB: DoB,
            Gender: Gender,
            Email: Email.trim().toLowerCase(),
            aadharFrontImage: aadharFrontImageUrl,
            aadharBackImage: aadharBackImageUrl,
            passportSizePhoto: passportSizePhotoUrl,
            pancardImage: pancardImageUrl,
            passbookFrontImage: passbookFrontImageUrl,
            kycStatus: 'inProgress'
        });

        // Update user's KYC status
        await User.findByIdAndUpdate(user._id, {
            kycStatus: 'inProgress',
            kycSubmittedAt: new Date()
        });

        console.log('KYC submission successful');
        return res.status(201).json({
            success: true,
            message: "KYC uploaded successfully. Wait for admin authorization.",
            data: {
                kycId: userKyc._id,
                status: userKyc.kycStatus,
                submittedAt: userKyc.createdAt
            }
        });

    } catch (error) {
        console.error('KYC submission error:', error);
        cleanupFiles(uploadedFiles);
        return res.status(500).json({
            success: false,
            message: "Internal server error",
            error: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
};

const cleanupFiles = (filePaths) => {
    if (!filePaths || filePaths.length === 0) return;

    filePaths.forEach(filePath => {
        try {
            if (fs.existsSync(filePath)) {
                fs.unlinkSync(filePath);
                console.log('Cleaned up file:', filePath);
            }
        } catch (error) {
            console.error('Error deleting file:', filePath, error);
        }
    });
};


export const verifyCaptcha = async (req, res) => {
    try {
        const { token } = req.body;
        const secretKey = process.env.RECAPTCHA_SECRET_KEY;

        // Verify with Google
        const response = await axios.post(
            "https://www.google.com/recaptcha/api/siteverify",
            null,
            {
                params: {
                    secret: secretKey,
                    response: token,
                },
            }
        );

        const data = response.data;

        if (data.success) {
            return res.json({ success: true });
        } else {
            return res.json({
                success: false,
                error: data["error-codes"],
            });
        }
    } catch (error) {
        return res.status(500).json({
            success: false,
            error: "Server error in verifying captcha",
        });
    }
};


export const getFeesForUser = async (req, res) => {
    console.log("inside fees")
    const admin = await Admin.find()

    if (!admin) {
        return res.status(404).json({
            success: fail,
            message: "Admin Not found",
        })
    }
    return res.status(200).json({
        success: true,
        message: "Fee fetched successfully.",
        fee: admin[0].fees,
    })
}

export const verifyToken = async (req, res) => {
    // const token = req.cookies.accessToken
    const token = req.cookies.accessToken
    console.log("token---", typeof token)
    const data = tokenVerification(token)
    return res.status(200).json({
        data: data
    })
}  