import dotenv from "dotenv"
import { User } from "../models/user.model.js";
import { Wallet } from "../models/Wallet.model.js";
import { generateTxnId, getCheckSum, getEncrypt, handlePaymentResponse, OrderId } from "../utils/apiFunctions.js";
import { Payment } from "../models/payment.model.js";
import { transaction } from "../models/Transactions.model.js";
import axios from "axios";
import { Admin } from "../models/Admin.model.js";
import { generateAndStoreOTP, verifyOTP } from "../services/otp.service.js";

dotenv.config()
let BASE_URL = process.env.BASE_URL;

let walletAddress = "";
let chain = "";

export const generateMobileNumber = () => {
    const firstDigit = ['6', '7', '8', '9'][Math.floor(Math.random() * 4)];
    let number = firstDigit;

    for (let i = 0; i < 9; i++) {
        number += Math.floor(Math.random() * 10);
    }

    return number;
}

export const BuyAssets = async (req, res) => {
    try {
        let PGLNetwork = "";
        const { currency, amount, email, token } = req.body;
        let { network } = req.body;

        if (network === "POLYGON") {
            PGLNetwork = "POLYGON"
            network = "ERC-20"
        }



        if (!currency || !network || !amount || !email || !token) {
            return res.status(400).json({
                message: "All fields are required."
            })
        }

        console.log("data to req---", amount, email, token, network)

        const admin = await Admin.find()
        if (!admin) {
            return res.status(200).json({ message: "admin not found" });

        }

        const fee = Number(admin[0].fees) * (Number(token) / 100)

        const user = await User.findOne({ email });
        if (!user) {
            return res.status(200).json({ message: "User not found" });
        }
        console.log("user found----", user)

        const userId = user._id.toString();
        console.log("userId found----", userId)

        let userWallet = await Wallet.findOne({ userId });
        if (!userWallet) {
            return res.status(404).json({ message: "Wallet for this user not found" });
        }

        if ((["ERC-20 Ethereum", "BEP-20 Binance", "AVALANCHE", "ERC-20"].includes(network) && !(["POLYGON"].includes(PGLNetwork)))) {
            walletAddress = userWallet.wallets[0].address;
            chain = "EVM";
        } else if (["POLYGON"].includes(PGLNetwork)) {
            walletAddress = userWallet.wallets[2].address;
            chain = "PGL";
        }
        else if (["TRC-20"].includes(network)) {

            walletAddress = userWallet.wallets[1].address;
            chain = "TRON";
        } else {
            return res.status(400).json({ message: "Unsupported network" });
        }

        const txnRefNo = generateTxnId();

        if (!txnRefNo) {
            console.log("txnRefNo not generated")
            return res.status(400).json({ message: "Something went wrong" });
        }

        const orderNo = OrderId();

        const newTransaction = await transaction.create([{
            userId: userId,
            transactionId: txnRefNo,
            transactionType: "buy",
            toAddress: walletAddress,
            amount: amount,
            chain: chain,
            network: network,
            fee: fee,
            token: token - fee,
            currency: currency,
            status: "pending",
            walletAddress: walletAddress,
            orderNo: orderNo,
            paymentMode: "UPI",
        }], { validateBeforeSave: false });

        console.log("transaction---", newTransaction);

        const mobileNo = generateMobileNumber()

        const paymentResult = await initiateBuyProcess(process.env.MID, orderNo, newTransaction[0]._id, amount, mobileNo, user.name, user.email, userId);

        console.log("paymentResult---", paymentResult);

        if (paymentResult?.error) {
            return res.status(400).json({
                success: false,
                message: "Payment initiation failed",
                error: paymentResult.error
            });
        }

        if (paymentResult?.respCode !== "0") {
            console.log("---------------------------inside respCode-------------------------------")
            return res.status(400).json({
                success: false,
                message: "Payment gateway error",
                paymentData: paymentResult
            });
        } else {
            const responseHandler = await respHandler(paymentResult, res);
            if (responseHandler?.respCode === "01" || responseHandler?.respCode === 1) {
                return res.status(500).json({
                    success: false,
                    message: "failed",
                    transactionId: txnRefNo,
                    orderNo: orderNo,
                    responseHandler: responseHandler
                });
            }

            return res.status(200).json({
                success: true,
                message: "Payment initiated successfully",
                transactionId: txnRefNo,
                orderNo: orderNo,
                responseHandler: responseHandler
            });
        }

    } catch (error) {
        console.error("BuyAssets error:", error);
        res.status(500).json({
            message: "Internal server error",
            error: error.message
        });
    }
}

const initiateBuyProcess = async (mid, orderNo, txnId, amount, mobileNo, customerName, email, userId) => {
    try {
        const amountInPaisa = (parseFloat(amount) * 100).toString();

        const payment = new Payment({
            userId: userId,
            txnId: txnId,
            mid: mid,
            orderNo: orderNo,
            amount: amount,
            paymentMethod: "UPI",
            status: "initiated",
        });

        await payment.save({ validateBeforeSave: false });
        console.log("Payment saved with orderNo:", orderNo);

        console.log("------mid, orderNo, amountInPaisa, mobileNo, customerName, email-------", mid, orderNo, amountInPaisa, mobileNo, customerName, email);

        const encryptReq = getEncrypt("TrnPayment", mid, orderNo, amountInPaisa, mobileNo, customerName, email);
        console.log("encryptReq--", encryptReq);

        const checkSum = getCheckSum(
            process.env.SALT_KEY,
            orderNo,
            amountInPaisa,
            "UPI", "", "", "", "", ""
        );
        console.log("checksum--", checkSum);

        let data = {
            mid: mid,
            encryptReq: encryptReq,
            checkSum: checkSum,
        };

        console.log("Request data:", {
            mid: mid,
            orderNo: orderNo,
            amountInPaisa: amountInPaisa,
            pgUrl: process.env.PG_URL
        });

        const PG_URL = process.env.PG_URL;
        if (!PG_URL) {
            throw new Error("PG_URL is not defined in environment variables");
        }

        const response = await fetch(PG_URL, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
            body: JSON.stringify(data),
        });


        const responseText = await response.text();
        console.log("Raw response:", responseText);

        let responseData;
        try {
            responseData = JSON.parse(responseText);
        } catch (parseError) {
            console.error("Failed to parse response:", parseError);
            responseData = { error: "Invalid response from payment gateway", rawResponse: responseText };
        }

        console.log("responseData---", responseData);

        if (responseData.txnRefNo) {
            await Payment.findOneAndUpdate(
                { orderNo: orderNo },
                { txnRefNo: responseData.txnRefNo, status: "processing" }
            );
        }

        return responseData;

    } catch (error) {
        console.error("Payment gateway error:", error.message);
        return {
            error: error.message || "Payment gateway error",
            success: false
        };
    }
}

export const BuyAssetsByCash = async (req, res) => {
    try {
        const { currency, amount, email, token, network } = req.body;

        // 1. Validate input
        if (!currency || !network || !amount || !email || !token) {
            return res.status(400).json({
                message: "All fields are required.",
            });
        }

        console.log("data to req---", amount, email, token, network);

        const admin = await Admin.findOne();
        if (!admin) {
            return res.status(404).json({ message: "Admin not found" });
        }

        const fee = Number(admin.fees) * (Number(token) / 100);

        const user = await User.findOne({ email });
        if (!user) {
            return res.status(404).json({ message: "User not found" });
        }

        console.log("user found----", user);

        const userId = user._id.toString();
        console.log("userId found----", userId);

        // 5. Find wallet
        const userWallet = await Wallet.findOne({ userId });
        if (!userWallet) {
            return res.status(404).json({
                message: "Wallet for this user not found",
            });
        }

        let walletAddress;
        let chain;

        if (["ERC-20 Ethereum", "BEP-20 Binance", "AVALANCHE", "ERC-20"].includes(network)) {
            walletAddress = userWallet.wallets?.[0]?.address;
            chain = "EVM";
        } else if (network === "TRC-20") {
            walletAddress = userWallet.wallets?.[1]?.address;
            chain = "TRON";
        } else {
            return res.status(400).json({ message: "Unsupported network" });
        }

        if (!walletAddress) {
            return res.status(400).json({ message: "Wallet address not found for this network" });
        }

        const txnRefNo = generateTxnId();
        if (!txnRefNo) {
            return res.status(500).json({ message: "Transaction ID generation failed" });
        }

        const orderNo = OrderId();

        const newTransaction = await transaction.create([{
            userId,
            transactionId: txnRefNo,
            transactionType: "buy",
            toAddress: walletAddress,
            amount: Number(amount),
            chain,
            network,
            fee,
            token: Number(token) - fee,
            currency,
            status: "pending",
            walletAddress,
            orderNo,
            paymentMode: "CASH",
            userName: user.name,
            userEmail: user.email,
        }], { validateBeforeSave: false });

        console.log("transaction---", newTransaction);

        return res.status(200).json({
            message: "Transaction initiated and waiting for Admin approval",
            data: newTransaction,
        });

    } catch (error) {
        console.error("BuyAssetsByCash error:", error);
        return res.status(500).json({
            message: "Internal server error",
        });
    }
};
export const BuyAssetsByBank = async (req, res) => {
    try {
        const { currency, amount, email, token, network, bankName, bankAccountNo, bankIfscNo, bankAcountHolderName, bankTxnId } = req.body;
        console.log("req-body---", req.body)
        if (!currency || !network || !amount || !email || !token || !bankName || !bankAccountNo || !bankIfscNo || !bankAcountHolderName || !bankTxnId) {
            return res.status(400).json({
                message: "All fields are required.",
            });
        }

        console.log("data to req---", amount, email, token, network);

        const admin = await Admin.findOne();
        if (!admin) {
            return res.status(404).json({ message: "Admin not found" });
        }

        const fee = Number(admin.fees) * (Number(token) / 100);

        const user = await User.findOne({ email });
        if (!user) {
            return res.status(404).json({ message: "User not found" });
        }

        console.log("user found----", user);

        const userId = user._id.toString();
        console.log("userId found----", userId);

        // 5. Find wallet
        const userWallet = await Wallet.findOne({ userId });
        if (!userWallet) {
            return res.status(404).json({
                message: "Wallet for this user not found",
            });
        }

        let walletAddress;
        let chain;

        if (["ERC-20 Ethereum", "BEP-20 Binance", "AVALANCHE", "ERC-20"].includes(network)) {
            walletAddress = userWallet.wallets?.[0]?.address;
            chain = "EVM";
        } else if (network === "TRC-20") {
            walletAddress = userWallet.wallets?.[1]?.address;
            chain = "TRON";
        } else {
            return res.status(400).json({ message: "Unsupported network" });
        }

        if (!walletAddress) {
            return res.status(400).json({ message: "Wallet address not found for this network" });
        }

        const txnRefNo = generateTxnId();
        if (!txnRefNo) {
            return res.status(500).json({ message: "Transaction ID generation failed" });
        }

        const orderNo = OrderId();

        const newTransaction = await transaction.create([{
            userId,
            transactionId: txnRefNo,
            transactionType: "buy",
            toAddress: walletAddress,
            amount: Number(amount),
            chain,
            network,
            fee,
            token: Number(token) - fee,
            currency,
            status: "pending",
            walletAddress,
            orderNo,
            paymentMode: "BANK",
            userName: user.name,
            userEmail: user.email,
            senderBankName: bankName,
            senderBankAccountNo: bankAccountNo,
            senderBankIfscNo: bankIfscNo,
            senderBankAcountHolderName: bankAcountHolderName,
            senderBankTxnId: bankTxnId
        }], { validateBeforeSave: false });

        console.log("transaction---", newTransaction);

        return res.status(200).json({
            message: "Transaction initiated and waiting for Admin approval",
            data: newTransaction,
        });

    } catch (error) {
        console.error("BuyAssetsByBank error:", error);
        return res.status(500).json({
            message: "Internal server error",
        });
    }
};


async function respHandler(jsonData, res) {
    try {
        const responseData = jsonData;

        if (responseData?.respCode == 1) {
            return responseData?.data?.ResponseMsg;
        } else {
            const data = JSON.parse(responseData?.data);
            console.log("data====", data);

            const mid = data.mid;
            const secretKey = process.env.PG_SECRET_KEY;
            const saltKey = process.env.SALT_KEY;

            const respData = data?.respData;
            const checkSum = data?.checkSum;

            const response = handlePaymentResponse(respData, mid, checkSum, secretKey, saltKey);
            console.log("handlePaymentResponse response---", response);

            if (data.orderNo) {
                await Payment.findOneAndUpdate(
                    { orderNo: data.orderNo },
                    {
                        status: "completed",
                        txnRefNo: data.txnRefNo || response.txnRefNo
                    }
                );
            }

            return response;
        }
    } catch (error) {
        console.error("Response handler error:", error);
        return { error: error.message };
    }
}


export const webhook = async (req, res) => {
    try {
        const { orderId, amount, txnStatus, txnRespCode, transactionId, rrn, txnResponseDate } = req.body;

        console.log("Webhook received:", req.body);

        // Find payment record
        const payment = await Payment.findOne({ orderNo: orderId });
        if (!payment) {
            return res.status(404).json({
                success: false,
                message: "Payment not found"
            });
        }
        const userId = payment.userId;

        const admin = await Admin.findOne({ email: process.env.ADMIN_EMAIL });
        if (!admin) {
            return res.status(404).json({
                success: false,
                message: "admin not found"
            });
        }

        const userWallet = await Wallet.findOne({ userId: userId });
        if (!userWallet) {
            return res.status(404).json({
                success: false,
                message: "Wallet not found"
            });
        }

        const txnId = payment.txnId;

        const newtransaction = await transaction.findById(txnId);
        if (!transaction) {
            return res.status(404).json({
                success: false,
                message: "Transaction not found"
            });
        }

        let statusUpdate = {};

        if (txnRespCode === "00" || txnRespCode == 0) {
            const chain = newtransaction.chain.toLowerCase();

            if (chain === "evm") {
                userWallet.wallets[0].balance = Number(userWallet.wallets[0].balance) + Number(newtransaction.token);
                admin.balance = Number(admin.balance) - (Number(newtransaction.token) - Number(newtransaction.fee))
            } else if (chain === "tron") {
                userWallet.wallets[1].balance = Number(userWallet.wallets[1].balance) + Number(newtransaction.token);
                admin.balance = Number(admin.balance) - (Number(newtransaction.token) - Number(newtransaction.fee))
            }
            else if (chain === "pgl") {

                userWallet.wallets[2].balance = Number(userWallet.wallets[1].balance) + Number(newtransaction.token)
                admin.balance = Number(admin.balance) - (Number(newtransaction.token))
            }

            statusUpdate = {
                transactionStatus: "success",
                paymentStatus: "success",
                message: txnStatus
            };

        } else if (txnRespCode === "01" || txnRespCode == 1) {
            statusUpdate = {
                transactionStatus: "failed",
                paymentStatus: "failed",
                message: txnStatus
            };
        } else {
            statusUpdate = {
                transactionStatus: "pending",
                paymentStatus: "pending",
                message: `Unknown Response: ${txnStatus}`
            };
            console.log("unknown message:-", JSON.stringify(req.body));
        }

        // Update records
        payment.status = statusUpdate.paymentStatus;
        payment.payment_gateway_responseMessage = statusUpdate.message;
        payment.webhookReceivedAt = new Date();
        payment.paymentTransactionId = transactionId;
        payment.rrn = rrn;


        newtransaction.status = statusUpdate.transactionStatus;


        // Save all updates
        await Promise.all([
            payment.save(),
            newtransaction.save({ validateBeforeSave: false }),
            userWallet.save(),
            admin.save(),
        ]);

        console.log("Payment updated successfully:", "paymentId-", payment._id, ", payment orderNo-", payment.orderNo, ", payment status-", payment.status);
        console.log("Transaction updated successfully:", "transaction-id--", newtransaction._id);
        console.log("UserWallet updated successfully:", userWallet._id);

        return res.status(200).json({
            message: "SUCCESS"
        });

    } catch (error) {
        console.error("Webhook error:", error);

        return res.status(500).json({
            success: false,
            message: "Internal server error",
            error: error.message
        });
    }
}


export const getcallBack = async (req, res) => {
    const { orderNo } = req.body;
    const paymentStatus = await Payment.findOne({ orderNo });

    if (!paymentStatus) {
        return res.status(400).json({
            respMsg: "orderId not found"
        })
    }


    if (paymentStatus.status === "initiated") {
        return res.status(200).json({
            respCode: 0,
            respMsg: `Payment is ${paymentStatus.status}`
        })
    }
    else if (paymentStatus.status === "success") {
        return res.status(200).json({
            respCode: 1,
            respMsg: `Payment is ${paymentStatus.status}`
        })

    }
    else if (paymentStatus.status === "failed") {
        return res.status(200).json({
            respCode: 2,
            respMsg: `Payment is ${paymentStatus.status}`
        })
    }
    else if (paymentStatus.status === "pending") {
        return res.status(200).json({
            respCode: 3,
            respMsg: `Payment is ${paymentStatus.status}`
        })
    }


}



export const getPrice = async (req, res) => {
    const { token } = req.body;
    let url = BASE_URL + `/price?chain=${token}`;

    console.log("url---", url)
    const response = await axios.get(url);

    // console.log("resp====",response)
    if (!response) {
        res.status(404).json({
            message: "No Price data found for this chain"
        })
    }
    console.log("generate price response = ", response?.data);



    return res.status(200).json({
        message: "Price data found for this chain",
        data: response?.data
    })
}

export const withdrawAssets = async (req, res) => {
    try {
        const { currency, network, amount, email, token, recipient_address, otp } = req.body;

        let newNetwork;
        let availableBalance;
        let walletAddress;
        let chain;

        if (!currency || !network || !amount || !email || !token || !recipient_address || !otp) {
            return res.status(400).json({
                message: "All fields including OTP are required."
            });
        }

        const otpVerification = await verifyOTP(email, otp, 'phone_verification', 'transaction');

        if (!otpVerification.isValid) {
            return res.status(400).json({
                success: false,
                message: otpVerification.message,
                requiresResend: otpVerification.requiresResend
            });
        }

        const user = await User.findOne({ email });
        if (!user) {
            return res.status(404).json({ message: "User not found" });
        }

        const userId = user._id.toString();

        const userWallet = await Wallet.findOne({ userId });
        if (!userWallet) {
            return res.status(404).json({ message: "Wallet for this user not found" });
        }

        const totalRequired = Number(token);

        if (["ERC-20 Ethereum", "POLYGON", "BEP-20 Binance", "AVALANCHE", "ERC-20"].includes(network)) {

            if (network === "POLYGON") {
                chain = "PGL";
                availableBalance = Number(userWallet.wallets[2].balance);
                walletAddress = userWallet.wallets[2].address;
            } else {
                chain = "EVM";
                availableBalance = Number(userWallet.wallets[0].balance);
                walletAddress = userWallet.wallets[0].address;
            }

            if (availableBalance < totalRequired) {
                return res.status(400).json({
                    success: false,
                    message: "Insufficient balance"
                });
            }

            if (network === "ERC-20") {
                newNetwork = "ERC-20";
            } else if (network === "POLYGON") {
                newNetwork = "ERC-20";
            } else {
                newNetwork = network;
            }

        } else if (network === "TRC-20") {

            availableBalance = Number(userWallet.wallets[1].balance);

            if (availableBalance < totalRequired) {
                return res.status(400).json({ message: "Insufficient balance" });
            }

            newNetwork = "TRC-20";
            walletAddress = userWallet.wallets[1].address;
            chain = "TRON";

        } else {
            return res.status(400).json({ message: "Unsupported network" });
        }

        const txnRefNo = generateTxnId();
        if (!txnRefNo) {
            return res.status(400).json({ message: "Transaction ID generation failed" });
        }

        const newTransaction = await transaction.create([{
            userId,
            transactionId: txnRefNo,
            transactionType: "withdraw",
            toAddress: recipient_address,
            amount,
            chain,
            network: newNetwork,
            token,
            currency,
            status: "pending",
            walletAddress: recipient_address,
            txHash: "n/a"
        }], { validateBeforeSave: false });

        return res.status(200).json({
            success: true,
            message: "Withdrawal request created successfully",
            data: newTransaction
        });

    } catch (error) {
        console.error("Withdraw error:", error);
        return res.status(500).json({
            success: false,
            message: "Internal server error"
        });
    }
};




export const withdrawAssetsAction = async (req, res) => {
    try {
        const { txnId, action, txHash, remark } = req.body;

        if (!txnId || !action || !txHash) {
            console.log(txnId, action, txHash)
            return res.status(400).json({
                message: "all parameter required !"
            });
        }

        const txn = await transaction.findOne({ transactionId: txnId });
        if (!txn) {
            return res.status(404).json({
                message: "transaction not found"
            });
        }

        const userWallet = await Wallet.findOne({ userId: txn.userId });
        if (!userWallet) {
            return res.status(404).json({
                message: "wallet not found"
            });
        }

        if (action === "reject") {
            txn.status = "rejected";
            await txn.save({ validateModifiedOnly: true });

            return res.status(200).json({
                message: "transaction rejected successfully."
            });
        }

        txn.status = "success";

        if (txn.chain === "PGL") {
            userWallet.wallets[2].balance =
                Number(userWallet.wallets[2].balance) + Number(txn.token);
        }
        else if (txn.chain === "EVM") {
            userWallet.wallets[0].balance =
                Number(userWallet.wallets[0].balance) + Number(txn.token);
        }
        else if (txn.chain === "TRON") {
            userWallet.wallets[1].balance =
                Number(userWallet.wallets[1].balance) + Number(txn.token);
        }

        txn.txHash = txHash;
        txn.remark = remark

        console.log("txn--", txn)
        console.log("userWallet--", userWallet)

        await txn.save({ validateModifiedOnly: true });
        await userWallet.save({ validateModifiedOnly: true });

        return res.status(200).json({
            message: "transaction approved successfully."
        });

    } catch (error) {
        console.error("withdrawAssetsAction error:", error);
        return res.status(500).json({
            message: "internal server error"
        });
    }
};







export const getAdminBalance = async (address, currency) => {

    let userData = {
        address, currency
    }
    console.log(userData)

    try {
        let url = "";

        if (currency.toLowerCase() === "evm") {
            const contract = process.env.USDT_ERC20_CONTRACT
            url = `https://erc.payglobal.co.in/erc20/getBalance?address=${address}&contract=${contract}`
        }
        else if (currency.toLowerCase() === "tron") {
            url = `https://trc.payglobal.co.in/trx/accountTRXBalance?address=${address}`
        }
        else if (currency.toLowerCase() === "pgl") {
            const contract = process.env.PGL_ERC20_CONTRACT
            url = `https://erc.payglobal.co.in/erc20/getBalance?address=${address}&contract=${contract}`
        }

        const response = await axios.get(url);

        console.log("Balance API response:", response.data);
        return response.data;

    } catch (error) {
        console.error("Error fetching balance:", error);
        throw error;
    }

}

export const updateBalance = async (email) => {

    const user = await User.findOne({ email });
    if (!user) {

        return {
            success: false,
            message: "user not found.."

        }
    }
    const userwallet = await Wallet.findOne({ userId: user._id })
    if (!userwallet) {

        return {
            success: false,
            message: "user wallet not found"

        }
    }
    let balance = {};
    userwallet.wallets.forEach((wallet) => {
        const key = `${wallet.chain.toLowerCase()}WalletData`;
        balance[key] = {
            balance: wallet.balance,
            chain: wallet.chain,
            address: wallet.address
        };
    });
    console.log(balance);

    return {
        success: true,
        message: "Balance fetched successfully",
        data: balance
    }



}


export const getBalance = async (req, res) => {
    const { email } = req.body;
    const balance = await updateBalance(email)
    if (!balance.success) {
        return res.status(404).json({
            success: false,
            message: "Unable to get Balance Now"
        })
    }
    return res.status(200).json({
        success: true,
        message: balance.message,
        data: balance.data
    })

}


export const txnHistory = async (req, res) => {
    try {
        const { email, transactionType } = req.body;

        // Validate required fields
        if (!email || !transactionType) {
            return res.status(400).json({
                success: false,
                message: "email and transaction type are required"
            });
        }

        // Validate transactionType
        const validTypes = ['buy', 'withdraw', 'all'];
        if (!validTypes.includes(transactionType)) {
            return res.status(400).json({
                success: false,
                message: "Invalid transaction type. Use 'buy', 'withdraw', or 'all'"
            });
        }

        const user = await User.findOne({ email });
        if (!user) {
            return res.status(404).json({
                success: false,
                message: "User not found"
            });
        }

        let transactions;
        let message = "";

        if (transactionType === "buy") {
            transactions = await transaction.find({
                userId: user._id,
                transactionType: "buy"
            })
                .sort({ createdAt: -1 })
                .lean();
            message = "Buy transactions fetched successfully";

        } else if (transactionType === "withdraw") {
            transactions = await transaction.find({
                userId: user._id,
                transactionType: "withdraw"
            })
                .sort({ createdAt: -1 })
                .lean();
            message = "Withdraw transactions fetched successfully";
        } else if (transactionType === "all") {
            transactions = await transaction.find({
                userId: user._id
            })
                .sort({ createdAt: -1 })
                .lean();
            message = "All transactions fetched successfully";
        }

        console.log(`Found ${transactions.length} transactions for user ${user._id}`);

        return res.status(200).json({
            success: true,
            message: message,
            data: {
                transactions: transactions,
                count: transactions.length,
                user: {
                    name: user.name,
                    email: user.email
                }
            }
        });

    } catch (error) {
        console.error("Error fetching transactions:", error);
        return res.status(500).json({
            success: false,
            message: "Internal server error",
            error: error.message
        });
    }
};

