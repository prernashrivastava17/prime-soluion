import { RANGE_CONFIG } from "../config/priceRange.config.js";
import CryptoPriceModel from "../models/CryptoPrice.model.js";
import PriceHistoryModel from "../models/PriceHistory.model.js";
import { logger } from "../utils/logger.js";

export const getChartData = async (req, res) => {
    try {
        const { range, chain } = req.body;

        logger.info('Chart data request', { range, chain });

        const startOfDay = new Date();
        startOfDay.setHours(0, 0, 0, 0);

        const startDate = new Date(startOfDay);

        switch (range) {
            case '1d':
                startDate.setDate(startDate.getDate() - 1);
                break;

            case '1w':
                startDate.setDate(startDate.getDate() - 7);
                break;

            case '1m':
                startDate.setMonth(startDate.getMonth() - 1);
                break;

            case '6m':
                startDate.setMonth(startDate.getMonth() - 6);
                break;

            case '1y':
                startDate.setFullYear(startDate.getFullYear() - 1);
                break;

            case 'All':
            default:
                break;
        }

        const endOfDay = new Date();
        endOfDay.setHours(23, 59, 59, 999);

        const matchStage = { chain };

        if (range !== 'All') {
            matchStage.createdAt = {
                $gte: startDate,
                $lte: endOfDay
            };
        }

        const data = await PriceHistoryModel.aggregate([
            { $match: matchStage },
            { $sort: { createdAt: 1 } },
            {
                $project: {
                    _id: 0,
                    price: "$price",
                    Date: {
                        $dateToString: {
                            format: "%Y-%m-%d",
                            date: "$createdAt"
                        }
                    }
                }
            }
        ]);



        logger.info('Chart data fetched', { count: data.length });

        res.json(data);
    } catch (error) {
        logger.error('Error fetching chart data', { error: error.message });
        res.status(500).json({ message: 'Internal server error' });
    }
};


export const setPrice = async (req, res) => {
    try {
        const { chain, price } = req.body;

        logger.info('Set price request', { chain, price });

        if (!chain || !['EVM', 'TRON'].includes(chain)) {
            logger.warn('Invalid chain', { chain });
            return res.status(400).json({ message: 'Invalid chain' });
        }

        if (typeof price !== 'number' || price <= 0) {
            logger.warn('Invalid price value', { price });
            return res.status(400).json({ message: 'Invalid price' });
        }

        const updateField =
            chain === 'EVM'
                ? { currentUsdtEVMPrice: price }
                : { currentUsdtTRONPrice: price };

        await CryptoPriceModel.findOneAndUpdate(
            {},
            { $set: updateField },
            { upsert: true, new: true }
        );

        await PriceHistoryModel.create({
            chain,
            price
        });

        logger.info('Price updated successfully', { chain, price });

        res.status(200).json({
            success: true,
            message: 'Price updated successfully',
            data: { chain, price }
        });
    } catch (error) {
        logger.error('Error setting price', {
            message: error.message,
            stack: error.stack
        });

        res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
};

export const getPrices = async (req, res) => {
    const data = await CryptoPriceModel.findOne()
    if (!data) {
        return res.status(400).json({
            message: "No data found"
        })
    }
    return res.status(200).json({
        message: "balance fetched successfully",
        data: {
            evmPrice: data.currentUsdtEVMPrice,
            tronPrice: data.currentUsdtTRONPrice
        }
    })

}
