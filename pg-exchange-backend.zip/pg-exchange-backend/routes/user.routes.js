import express from 'express';
import {
    userSignup,
    userSignin,
    otpVerify,
    forgotPassword,
    resetPassword,
    resendOtp,
    userProfile,
    userKyc,
    verifyCaptcha,
    getFeesForUser,
    getBuyTxnsByUser,
    verifyToken
} from '../controllers/auth.controller.js';
import { upload } from '../middleware/multer.middleware.js';
import { uploadBase64ToCloudinary, userKyctest } from '../controllers/uploadBase64ToCloudinary.js';
import { getChartData, getPrices } from '../controllers/price.controller.js';
// import { uploadBase64ToCloudinary, userKyctest } from '../controllers/uploadBase64ToCloudinary.js';

const router = express.Router();

router.post('/signup', userSignup);
router.post('/verify-captcha', verifyCaptcha);
router.post('/verify-otp', otpVerify);
router.post('/signin', userSignin);
router.post('/forgot-password', forgotPassword);
router.post('/reset-password', resetPassword);
router.post('/resend-otp', resendOtp);
router.post('/user-profile', userProfile);
router.post('/get-buy-txns', getBuyTxnsByUser)
router.get('/get-fees', getFeesForUser);
router.post('/user-kyc', (req, res, next) => {
    const uploadMiddleware = upload.fields([
        { name: "aadharFrontImage", maxCount: 1 },
        { name: "aadharBackImage", maxCount: 1 },
        { name: "passportSizePhoto", maxCount: 1 },
        { name: "pancardImage", maxCount: 1 },
        { name: "passbookFrontImage", maxCount: 1 },
    ]);

    uploadMiddleware(req, res, function (err) {
        if (err) {
            console.error('Multer upload error:', err);

            // Handle specific multer errors
            if (err.code === 'LIMIT_FILE_SIZE') {
                return res.status(400).json({
                    success: false,
                    message: "File too large. Maximum size is 5MB."
                });
            }
            if (err.message.includes('Invalid file type')) {
                return res.status(400).json({
                    success: false,
                    message: err.message
                });
            }
            if (err.code === 'LIMIT_FILE_COUNT') {
                return res.status(400).json({
                    success: false,
                    message: "Too many files uploaded."
                });
            }

            return res.status(400).json({
                success: false,
                message: "File upload failed: " + err.message
            });
        }

        // Check if files were actually uploaded
        if (!req.files) {
            return res.status(400).json({
                success: false,
                message: "No files were uploaded. Please select all required documents."
            });
        }

        console.log('Files uploaded successfully:', Object.keys(req.files));
        next(); // Proceed to the controller
    });
}, userKyc);

router.post(
    '/user-testing',
    express.json({ limit: '10mb' }),
    uploadBase64ToCloudinary,
    userKyctest
);
router.post("/get-chart-Data", getChartData)
router.get("/get-prices", getPrices)
router.get("/get-buy-txn-history", getPrices)
router.get("/get-prices", getPrices)
router.post("/verify-token", verifyToken)


export default router;

