import express from 'express';
import {
    actionOnUser,
    AdminLogin,
    approveKyc,
    CashTxnsAction,
    findAdmin,
    forgotPassword,
    getAdminData,
    getAdminOtp,
    getAllUsers,
    getCashTxnData,
    getFees,
    getPendingKycs,
    getTxns,
    getTxnsByToday,
    getuser,
    getWdrwTxnData,
    otpVerify,
    rejectKyc,
    resetPassword,
    setFees,
} from '../controllers/admin.controller.js';
import { setPrice } from '../controllers/price.controller.js';
import { withdrawAssetsAction } from '../controllers/transaction.controller.js';

const router = express.Router();

router.post('/admin-login', AdminLogin);
router.post('/get-admin-otp', getAdminOtp);
router.post('/find-admin', findAdmin);
router.post('/forgot-password', forgotPassword);
router.post('/reset-password', resetPassword);
router.post('/get-pending-kycs', getPendingKycs);
router.patch('/approve-kyc/:kycId', approveKyc);
router.patch('/reject-kyc/:kycId', rejectKyc);
router.post('/verify-otp', otpVerify);


router.post('/get-fees', getFees);
router.post('/set-fees', setFees);
router.get('/get-txn-history', getTxns);
router.post('/get-txn-byToday', getTxnsByToday);
router.get('/get-admin-data', getAdminData);
router.get('/get-all-users', getAllUsers);
router.post('/get-user', getuser);
router.post('/action-on-user', actionOnUser);
router.post('/set-price', setPrice);
router.get('/get-cash-txn-data', getCashTxnData);
router.post("/cash-txns-action", CashTxnsAction)
router.get('/get-withdraw-txn-data', getWdrwTxnData);
router.post("/withdraw-txns-action", withdrawAssetsAction)



export default router;
