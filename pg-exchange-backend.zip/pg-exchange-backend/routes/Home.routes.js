import express from "express";
import userRoutes from "./user.routes.js";
import adminRoutes from "./Admin.routes.js";
import txnRoutes from "./transaction.routes.js"

const router = express.Router();
router.use("/user", userRoutes);
router.use("/admin", adminRoutes);
router.use("/txn", txnRoutes);

export default router;
