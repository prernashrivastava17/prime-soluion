import { Router } from "express";
import { BuyAssets, BuyAssetsByBank, BuyAssetsByCash, getBalance, getcallBack, getPrice, txnHistory, webhook, withdrawAssets } from "../controllers/transaction.controller.js";
import { generateWithdrawalOTP } from "../services/otp.service.js";
import { checkKYCStatus } from "../middleware/checkKYCStatus.js";

const routes = Router();

routes.post("/buy-assets", checkKYCStatus, BuyAssets);
routes.post("/buy-assets-by-cash", checkKYCStatus, BuyAssetsByCash);
routes.post("/buy-assets-by-bank", checkKYCStatus, BuyAssetsByBank);
routes.post("/withdraw-assets", checkKYCStatus, withdrawAssets);
routes.post('/gen-withdraw-otp', checkKYCStatus, generateWithdrawalOTP);
routes.post("/webhook/callBack", webhook);
routes.post("/getcallBack", getcallBack);
routes.post("/getPrice", getPrice);
routes.post("/getbalanceData", checkKYCStatus, getBalance);
routes.post("/transactions", checkKYCStatus, txnHistory);

export default routes;