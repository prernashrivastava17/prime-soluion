import dns from "dns/promises";

const defaultIPs = ["192.168.1.41", "::1", "192.168.1.16", "192.168.1.26"];

const envDomains = [
    ...(process.env.ALLOWED_IPS?.split(",") || []),
    ...(process.env.ALLOWED_ADMIN_IPS?.split(",") || []),
    ...(process.env.ALLOWED_CALLBACK_IPS?.split(",") || []),
    ...(process.env.ALLOWED_wallet_IPS?.split(",") || []),
    ...(process.env.TRC_URL?.split(",") || []),
    ...(process.env.TRC_URL?.split(",") || []),
];


const domains = envDomains.map(d => d.trim()).filter(Boolean);

let resolvedIPs = [...defaultIPs];

const resolveDomains = async () => {

    for (const domain of domains) {
        try {
            if (/^\d+\.\d+\.\d+\.\d+$/.test(domain)) {
                resolvedIPs.push(domain);
                continue;
            }

            const ips = await dns.resolve4(domain);
            resolvedIPs.push(...ips);
            console.log("domain---", domain)

        } catch (error) {
            console.warn(`Could not resolve: ${domain}`, error.message);
        }
    }

    resolvedIPs = [...new Set(resolvedIPs)];
};

await resolveDomains();

export const ipValidationMiddleware = (req, res, next) => {
    console.log("inside ip Validation Middleware , ip :-", req.ip)
    const clientIP = req.ip || req.connection.remoteAddress;
    const cleanIP = clientIP?.replace(/^::ffff:/, "");

    console.log("my resolved ips--", resolvedIPs)
    console.log("my cleanIP ips--", cleanIP)

    if (resolvedIPs.includes(cleanIP)) {

        return next();
    }

    console.log(`❌ Blocked IP: ${cleanIP}`);

    return res.status(403).json({
        success: false,
        message: "Access forbidden: IP not authorized",
    });
};
