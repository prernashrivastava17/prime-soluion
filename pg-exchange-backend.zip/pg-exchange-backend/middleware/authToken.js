import jwt from "jsonwebtoken";
import dotenv from 'dotenv'

dotenv.config();

export const generateAccessToken = (email) => {
    return jwt.sign({ email }, process.env.JWT_ACCESS_SECRET_KEY, { expiresIn: '1d' })
}
export const generateRefreshToken = (email) => {
    return jwt.sign({ email }, process.env.JWT_REFRESH_SECRET_KEY, { expiresIn: '7d' })
}

export const tokenVerification = (token) => {
    console.log("provided token----", token)
    const newtoken = jwt.verify(token, process.env.JWT_ACCESS_SECRET_KEY)
    console.log("token verification----", newtoken)
    console.log("token verification type----", typeof newtoken)
    return newtoken;
}



