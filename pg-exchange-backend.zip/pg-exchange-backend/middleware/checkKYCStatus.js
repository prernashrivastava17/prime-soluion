import { User } from "../models/user.model.js";

export const checkKYCStatus = async (req, res, next) => {
    try {
        const { email } = req.body;
        console.log("email--", email)

        if (!email) {
            return res.status(401).json({
                success: false,
                message: "email is required"
            });
        }

        // ✅ CORRECT: Pass an object as filter to findOne
        const user = await User.findOne({ email: email });

        if (!user) {
            return res.status(404).json({
                success: false,
                message: "User not found"
            });
        }
        console.log("user---", user)
        // Check if KYC is verified
        if (user.kycStatus === 'inProgress') {
            return res.status(403).json({
                success: false,
                message: "KYC verification is in progress",
                kycStatus: user.kycStatus,
                requiredAction: ""
            });
        }
        if (user.kycStatus !== 'verified') {
            return res.status(403).json({
                success: false,
                message: "KYC verification required to perform transactions",
                kycStatus: user.kycStatus,
                requiredAction: user.kycStatus === 'pending' ?
                    "Please complete your KYC verification" :
                    "Your KYC verification was rejected. Please contact support"
            });
        }

        else if (user.isActive === false) {
            return res.status(403).json({
                success: false,
                message: "Your Account has been blocked. contact Admin",
                isActive: user.isActive,
                requiredAction: ""
            });
        }

        // If KYC is verified, proceed to the next middleware/route
        next();
    } catch (error) {
        console.error("KYC middleware error:", error);
        return res.status(500).json({
            success: false,
            message: "Internal server error in KYC verification"
        });
    }
};