api called--
withdrawal response-- - {
  responseCode: 200,
  responseMessage: 'Success',
  responseResult: {
    blockHash: '0xe6040b6ad3b9f3f92845e2afd560b6e7ea93e56cadb193293be59c6d8861af8e',
    blockNumber: 9675149,
    contractAddress: null,
    cumulativeGasUsed: 63206,
    effectiveGasPrice: 30000000000,
    from: '0x99ffc6e460b1a683f7f9604cc7b1f32d48a1539d',
    gasUsed: 63206,
    logs: [[Object]],
    logsBloom: '0x00000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000000000000000000000000000200000000000000000000000008000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000010000000000020000000000000000000040000000000000000000000004000000000000000000000000000000000000000000000000000000000000000000000000000020000000002000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000200000000000000000000000000000',
    status: true,
    to: '0x028e5a185c76345e6a02d93a53c0692233902c46',
    transactionHash: '0x38ee516a9429a2caa7026f55f9a7c08392e7d87f442c673c1b4c9199a978e62b',
    transactionIndex: 0,
    type: '0x0'
  }
}
Update result: {
  acknowledged: true,
    modifiedCount: 1,
      upsertedId: null,
        upsertedCount: 0,
          matchedCount: 1
}
Matched: 1 Modified: 1










// ------------------------------------------------------------------


export const userKyc = async (req, res) => {
  const uploadedFiles = [];

  try {
    console.log('=== KYC SUBMISSION STARTED ===');
    console.log('Request files keys:', Object.keys(req.files || {}));
    console.log('Request body:', req.body);

    // Check if files exist (additional safety check)
    if (!req.files) {
      return res.status(400).json({
        success: false,
        message: "No files uploaded. Please upload all required documents."
      });
    }

    const {
      aadharFrontImage,
      aadharBackImage,
      passportSizePhoto,
      pancardImage,
      passbookFrontImage
    } = req.files;

    const {
      FullName,
      FathersName,
      DoB,
      Gender,
      Email,
      mobileNo,
      userMobileNo
    } = req.body;

    // Debug log each file
    console.log('File details:', {
      aadharFrontImage: aadharFrontImage ? `exists (${aadharFrontImage.length} files)` : 'missing',
      aadharBackImage: aadharBackImage ? `exists (${aadharBackImage.length} files)` : 'missing',
      passportSizePhoto: passportSizePhoto ? `exists (${passportSizePhoto.length} files)` : 'missing',
      pancardImage: pancardImage ? `exists (${pancardImage.length} files)` : 'missing',
      passbookFrontImage: passbookFrontImage ? `exists (${passbookFrontImage.length} files)` : 'missing'
    });

    // Track files for cleanup with safety checks
    if (aadharFrontImage && aadharFrontImage[0] && aadharFrontImage[0].path) {
      uploadedFiles.push(aadharFrontImage[0].path);
    }
    if (aadharBackImage && aadharBackImage[0] && aadharBackImage[0].path) {
      uploadedFiles.push(aadharBackImage[0].path);
    }
    if (passportSizePhoto && passportSizePhoto[0] && passportSizePhoto[0].path) {
      uploadedFiles.push(passportSizePhoto[0].path);
    }
    if (pancardImage && pancardImage[0] && pancardImage[0].path) {
      uploadedFiles.push(pancardImage[0].path);
    }
    if (passbookFrontImage && passbookFrontImage[0] && passbookFrontImage[0].path) {
      uploadedFiles.push(passbookFrontImage[0].path);
    }

    console.log('Files to cleanup:', uploadedFiles);

    // Validate required fields
    if (!FullName || !FathersName || !DoB || !Gender || !Email || !mobileNo || !userMobileNo) {
      console.log('Missing required fields');
      cleanupFiles(uploadedFiles);
      return res.status(400).json({
        success: false,
        message: "All personal information fields are required"
      });
    }

    // Validate mobile number format
    const mobileRegex = /^[0-9]{10}$/;
    if (!mobileRegex.test(mobileNo) || !mobileRegex.test(userMobileNo)) {
      console.log('Invalid mobile number format');
      cleanupFiles(uploadedFiles);
      return res.status(400).json({
        success: false,
        message: "Please provide valid 10-digit mobile numbers"
      });
    }



    // Validate required files with better error messages
    const missingFiles = [];
    if (!aadharFrontImage || !aadharFrontImage[0]) missingFiles.push("Aadhar Front Image");
    if (!aadharBackImage || !aadharBackImage[0]) missingFiles.push("Aadhar Back Image");
    if (!passportSizePhoto || !passportSizePhoto[0]) missingFiles.push("Passport Size Photo");
    if (!pancardImage || !pancardImage[0]) missingFiles.push("PAN Card Image");
    if (!passbookFrontImage || !passbookFrontImage[0]) missingFiles.push("Passbook Front Image");

    if (missingFiles.length > 0) {
      console.log('Missing files:', missingFiles);
      cleanupFiles(uploadedFiles);
      return res.status(400).json({
        success: false,
        message: `Missing required documents: ${missingFiles.join(', ')}`
      });
    }

    // Continue with Cloudinary upload and KYC creation...
    // [Rest of your existing code remains the same]
    // Create KYC record
    const userKyc = await Kyc.create({
      userId: user._id,
      mobileNo: mobileNo,
      FullName: FullName.trim(),
      FathersName: FathersName.trim(),
      DoB: DoB,
      Gender: Gender,
      Email: Email.trim().toLowerCase(),
      aadharFrontImage: aadharFrontImageUrl,
      aadharBackImage: aadharBackImageUrl,
      passportSizePhoto: passportSizePhotoUrl,
      pancardImage: pancardImageUrl,
      passbookFrontImage: passbookFrontImageUrl,
      status: 'pending'
    });

    // Update user's KYC status
    await User.findByIdAndUpdate(user._id, {
      kycStatus: 'pending',
      kycSubmittedAt: new Date()
    });

    return res.status(201).json({
      success: true,
      message: "KYC uploaded successfully. Wait for admin authorization.",
      data: {
        kycId: userKyc._id,
        status: userKyc.status,
        submittedAt: userKyc.createdAt
      }
    });

  } catch (error) {
    console.error('KYC submission error:', error);
    cleanupFiles(uploadedFiles);
    return res.status(500).json({
      success: false,
      message: "Internal server error",
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

const cleanupFiles = (filePaths) => {
  if (!filePaths || filePaths.length === 0) return;

  filePaths.forEach(filePath => {
    try {
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
        console.log('Cleaned up file:', filePath);
      }
    } catch (error) {
      console.error('Error deleting file:', filePath, error);
    }
  });
};