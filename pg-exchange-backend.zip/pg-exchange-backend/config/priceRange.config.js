export const RANGE_CONFIG = {
    '1d': { days: 1, group: 'minute', },
    '1w': { days: 7, group: 'hour' },
    '1m': { days: 30, group: 'day' },
    '6m': { days: 180, group: 'week' },
    '1y': { days: 365, group: 'month' },
    'all': { days: null, group: 'month' }
};
