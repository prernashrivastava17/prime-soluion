// import bcrypt from 'bcryptjs';

// // Configuration
// const SALT_ROUNDS = 12;
// const PEPPER = process.env.SECRET_KEY;

// export async function hashPassword(password) {
//     try {
//         const pepperedPassword = password + PEPPER;
//         const salt = await bcrypt.genSalt(SALT_ROUNDS);
//         return await bcrypt.hash(pepperedPassword, salt);
//     } catch (error) {
//         throw new Error(`Password hashing failed: ${error.message}`);
//     }
// }


// export async function verifyPassword(password, hash) {
//     try {
//         const pepperedPassword = password + PEPPER;
//         return await bcrypt.compare(pepperedPassword, hash);
//     } catch (error) {
//         throw new Error(`Password verification failed: ${error.message}`);
//     }
// }



import bcrypt from 'bcryptjs';
import crypto from 'crypto';

const PEPPER = process.env.SECRET_KEY;

// For passwords (one-way hashing)
export async function hashPassword(password) {
    try {
        const pepperedPassword = password + PEPPER;
        const salt = await bcrypt.genSalt(12);
        return await bcrypt.hash(pepperedPassword, salt);
    } catch (error) {
        throw new Error(`Password hashing failed: ${error.message}`);
    }
}

export async function verifyPassword(password, hash) {
    console.log("verifying password");
    console.log("password:", password, "hash:", hash);
    try {
        const pepperedPassword = password + PEPPER;
        return await bcrypt.compare(pepperedPassword, hash);
    } catch (error) {
        throw new Error(`Password verification failed: ${error.message}`);
    }
}

export function encryptData(data) {
    const cipher = crypto.createCipher('aes-256-gcm', PEPPER);
    let encrypted = cipher.update(data, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    return encrypted;
}

export function decryptData(encryptedData) {
    const decipher = crypto.createDecipher('aes-256-gcm', PEPPER);
    let decrypted = decipher.update(encryptedData, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
}
