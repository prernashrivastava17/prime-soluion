import swaggerJsdoc from 'swagger-jsdoc';

const options = {
    definition: {
        openapi: '3.0.0',
        info: {
            title: 'Your API Documentation',
            version: '1.0.0',
            description: 'API documentation for your Node.js project',
        },
        servers: [
            {
                url: 'http://localhost:8080',   // CHANGE HERE
                description: 'Local server'
            }
        ]
    },
    apis: ['routes/*.js', 'routes/**/*.js'],  // IMPORTANT
};

const swaggerSpec = swaggerJsdoc(options);
export default swaggerSpec;
