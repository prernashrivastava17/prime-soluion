// import fs from 'fs';
// import path from 'path';

// const logDir = path.join(__dirname, '../logs');
// if (!fs.existsSync(logDir)) {
//   fs.mkdirSync(logDir);
// }

// const logger = {
//   info: (message, data = '') => {
//     const log = `[INFO] ${new Date().toISOString()} - ${message} ${data}\n`;
//     console.log(log);
//     fs.appendFileSync(path.join(logDir, 'app.log'), log);
//   },
//   error: (message, error = '') => {
//     const log = `[ERROR] ${new Date().toISOString()} - ${message} ${error}\n`;
//     console.error(log);
//     fs.appendFileSync(path.join(logDir, 'error.log'), log);
//   },
//   warn: (message, data = '') => {
//     const log = `[WARN] ${new Date().toISOString()} - ${message} ${data}\n`;
//     console.warn(log);
//     fs.appendFileSync(path.join(logDir, 'app.log'), log);
//   },
// };

// // module.exports = logger;

import winston from 'winston';

export const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()
  ),
  transports: [
    new winston.transports.Console(),
    new winston.transports.File({ filename: 'logs/error.log', level: 'error' }),
    new winston.transports.File({ filename: 'logs/combined.log' })
  ]
});


