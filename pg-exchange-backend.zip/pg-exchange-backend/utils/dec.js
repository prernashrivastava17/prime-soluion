import { decryptData } from "./basicSecurity.js";


const data = async (encryptedData) => {
    const data = await decryptData(encryptedData);
    return data;
}

data("$2b$12$57LCrB9ZWOcs/oBKUfPlGuUY1VAjVZUD8/B2kguwIoST45cAXxvcy").then((res) => {
    console.log("decrypted data", res);
}).catch((err) => {
    console.error("decryption error", err);
})