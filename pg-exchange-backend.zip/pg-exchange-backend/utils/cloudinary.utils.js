// import { v2 as cloudinary } from 'cloudinary';
// import fs from "fs";

// cloudinary.config({
//     cloud_name: process.env.CLOUD_NAME,
//     api_key: process.env.API_KEY,
//     api_secret: process.env.API_SECRET
// });

// export const uploadOnCloudinary = async (localFilePath) => {
//     try {
//         if (!localFilePath) {
//             return null;
//         }
//         const cloudinaryResponse = await cloudinary.uploader.upload(localFilePath, {
//             resource_type: "image"
//         })
//         console.log("File is uploaded on cloudinary", cloudinaryResponse.url)
//         return cloudinaryResponse.url

//     } catch (error) {
//         fs.unlinkSync(localFilePath)
//         return null;
//     }
// }


export const uploadOnCloudinary = async (localFilePath) => {
    try {
        if (!localFilePath) {
            return null;
        }
        const cloudinaryResponse = await cloudinary.uploader.upload(localFilePath, {
            resource_type: "image",
            folder: "kyc_documents" // Optional: organize files in folder
        });
        console.log("File uploaded to Cloudinary:", cloudinaryResponse.url);

        // Delete local file after successful upload
        if (fs.existsSync(localFilePath)) {
            fs.unlinkSync(localFilePath);
        }

        return cloudinaryResponse.url;

    } catch (error) {
        // Delete local file on error
        if (fs.existsSync(localFilePath)) {
            fs.unlinkSync(localFilePath);
        }
        console.error('Cloudinary upload failed:', error);
        return null;
    }
};