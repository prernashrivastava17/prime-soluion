import axios from 'axios';
import CryptoJS from "crypto-js";

export const GetAxios = async (url, method = "POST", data = {}) => {
    try {
        let response;

        if (method === "POST" || method === "post") {
            response = await axios.post(`https://backend.payglobal.co.in/${url}`, data, {
                headers: {
                    'Content-Type': 'application/json',
                    // 'Authorization': 'Bearer your-token'
                }
            });
        }
        else if (method === "GET" || method === "get") {
            response = await axios.get(`https://backend.payglobal.co.in/${url}`, {
                headers: {
                    'Content-Type': 'application/json',
                }
            });
        }
        else {
            throw new Error(`Unsupported method: ${method}`);
        }

        console.log('Response:', response.data);
        return [response.data, response];
    } catch (error) {
        console.error('Error:', error.response?.data || error.message);
        throw error;
    }
}

export const generateTxnId = () => {
    const now = new Date();

    const timestamp = [
        String(now.getDate()).padStart(2, '0'),
        String(now.getMonth() + 1).padStart(2, '0'),
        String(now.getFullYear()).slice(-2),
        String(now.getHours()).padStart(2, '0'),
        String(now.getMinutes()).padStart(2, '0'),
        String(now.getSeconds()).padStart(2, '0'),
        String(now.getMilliseconds()).padStart(3, '0')
    ].join('');

    const randomSuffix = String(Math.floor(Math.random() * 10000)).padStart(4, '0');

    return `TXN${timestamp}${randomSuffix}`;
};

export const OrderId = () => {
    const now = new Date();
    const timestamp = [
        String(now.getDate()).padStart(2, '0'),
        String(now.getMonth() + 1).padStart(2, '0'),
        String(now.getFullYear()).slice(-2),
        String(now.getHours()).padStart(2, '0'),
        String(now.getMinutes()).padStart(2, '0'),
        String(now.getSeconds()).padStart(2, '0'),
        String(now.getMilliseconds()).padStart(3, '0')
    ].join('');

    const randomSuffix = String(Math.floor(Math.random() * 10000)).padStart(4, '0');
    return `ORD${timestamp}${randomSuffix}`;
};

export const getEncrypt = (msg = "TrnPayment", mid, orderNo, amount, mobileNo, customerName, email) => {
    const RequestSequence = "mid|orderNo|amount|currency|txnReqType|undefinedField1|undefinedField2|undefinedField3|undefinedField4|undefinedField5|undefinedField6|undefinedField7|undefinedField8|undefinedField9|undefinedField10|emailId|mobileNo|address|city|state|pincode|transactionMethod|bankCode|vpa|cardNumber|expiryDate|cvv|customerName|respUrl|optional1";
    const ResponseSequence = "mid|orderNo|txnRefNo|amount|currency|txnReqType|undefinedField1|undefinedField2|undefinedField3|undefinedField4|undefinedField5|undefinedField6|undefinedField7|undefinedField8|undefinedField9|undefinedField10|emailId|mobileNo|address|city|state|pincode|respCode|respMessage|payAmount|txnRespDate|upiString";
    const RequestSequenceStatus = "Mid|TotalAmount|TxnRefNo|OrderNo";
    const ResponseSequenceStatus = "Mid|OrderNo|TxnRefNo|TotalAmount|CurrencyName|MeTransReqType|AddField1|AddField2|AddField3|AddField4|AddField5|AddField6|AddField7|AddField8|AddField9|AddField10|EmailId|MobileNo|Address|City|State|Pincode|RespCode|RespMessage|PayAmount|TxnRespDate|UPIString|utrNo";

    const valueMap = {
        'mid': mid,
        'orderNo': orderNo,
        'amount': amount, // This should already be in paisa format
        'mobileNo': mobileNo,
        'customerName': customerName,
        'currency': 'INR', // default currency
        'txnReqType': 'S', // default transaction type
        'undefinedField1': '',
        'undefinedField2': '',
        'undefinedField3': '',
        'undefinedField4': '',
        'undefinedField5': '',
        'undefinedField6': '',
        'undefinedField7': '',
        'undefinedField8': '',
        'undefinedField9': '',
        'undefinedField10': '',
        'emailId': email,
        'address': '',
        'city': '',
        'state': '',
        'pincode': '',
        'transactionMethod': 'UPI',
        'bankCode': '',
        'vpa': '',
        'cardNumber': '',
        'expiryDate': '',
        'cvv': '',
        'respUrl': process.env.RESPONSE_URL || '', // Add your response URL
        'optional1': 'intent' // This is important for UPI
    };

    let hashVarsSeq = [];

    if (msg == "TrnPayment") {
        hashVarsSeq = RequestSequence.split("|");
    }
    if (msg == "TrnStatus") {
        hashVarsSeq = RequestSequenceStatus.split("|");
    }

    let hash_string = "";
    let i = 1;
    let count = hashVarsSeq.length;

    hashVarsSeq.forEach((hash_var) => {
        hash_string = hash_string + valueMap[hash_var];
        if (i != count) hash_string += ",";
        i++;
    });

    console.log("hash_string--", hash_string);
    const encription = encrypt(hash_string, process.env.PG_SECRET_KEY);
    console.log("encription--", encription);

    return encription;
}

const encrypt = (hashString, key) => {
    console.log("hashString, key--", hashString, key);
    const iv = CryptoJS.lib.WordArray.create(16);
    key = fixKey(key);
    // Use the fixed salt key from PG provider's demo
    key = derivateKey(key, "Asdf@1234", 65536, 256); // Use the same salt as in the demo
    const cipher = CryptoJS.AES.encrypt(hashString, key, {
        iv: iv,
        format: CryptoJS.format.OpenSSL,
    });
    return cipher.toString();
}

const fixKey = (key) => {
    const keyLength = 35; // Match the key length from PG provider's code

    if (key.length < keyLength) {
        // 0 pad to length keyLength
        return key.padEnd(keyLength, "0");
    }

    if (key.length > keyLength) {
        // Truncate to keyLength characters
        return key.substring(0, keyLength);
    }

    return key;
}

const derivateKey = (password, salt, iterations, keyLengthBits) => {
    const key = CryptoJS.PBKDF2(password, salt, {
        keySize: keyLengthBits / 32,
        iterations: iterations,
        hasher: CryptoJS.algo.SHA256,
    });
    return key;
}

export const getCheckSum = (saltKey, orderNo, amount, transactionMethod, bankCode, vpa, cardNumber, expiryDate, cvv,) => {
    const dataString = orderNo + "," + amount + "," + transactionMethod + "," + bankCode + "," + vpa + "," + cardNumber + "," + expiryDate + "," + cvv;
    console.log("checksum dataString----", dataString);

    saltKey = base64Encode(saltKey);
    let hashValue = CryptoJS.HmacSHA512(dataString, saltKey);
    hashValue = CryptoJS.enc.Hex.stringify(hashValue);
    hashValue = hashValue.toString().toUpperCase();
    return hashValue;
}

const base64Encode = (data) => {
    return CryptoJS.enc.Base64.stringify(CryptoJS.enc.Utf8.parse(data));
}

// Add response handler similar to the PG provider's demo
export const handlePaymentResponse = (respData, mid, checkSum, secretKey, saltKey) => {
    // Implementation similar to getResponse method in PG provider's code
    if (mid === process.env.MID) {
        let response = decrypt(respData, secretKey);
        let respArray = response.split(",");
        let hashRespSeq = "mid|orderNo|txnRefNo|amount|currency|txnReqType|undefinedField1|undefinedField2|undefinedField3|undefinedField4|undefinedField5|undefinedField6|undefinedField7|undefinedField8|undefinedField9|undefinedField10|emailId|mobileNo|address|city|state|pincode|respCode|respMessage|payAmount|txnRespDate|upiString".split("|");

        let i = 0;
        let returnArray = {};
        hashRespSeq.forEach((hash_var) => {
            returnArray[hash_var] = respArray[i];
            i++;
        });

        // Verify checksum
        const CheckSumTxnResp = createCheckSumTxnResp(saltKey, returnArray["orderNo"], returnArray["payAmount"], returnArray["respCode"], returnArray["respMessage"]);

        if (checkSum === CheckSumTxnResp) {
            return {
                success: true,
                mid: returnArray["mid"],
                orderNo: returnArray["orderNo"],
                txnRefNo: returnArray["txnRefNo"],
                amount: parseFloat(returnArray["amount"]) / 100, // Convert back to rupees
                currency: returnArray["currency"],
                respCode: returnArray["respCode"],
                respMessage: returnArray["respMessage"],
                payAmount: parseFloat(returnArray["payAmount"]) / 100, // Convert back to rupees
                txnRespDate: returnArray["txnRespDate"],
                upiString: returnArray["upiString"]
            };
        } else {
            return {
                success: false,
                error: "Checksum mismatch"
            };
        }
    } else {
        return {
            success: false,
            error: "MID mismatch"
        };
    }
}

const decrypt = (data, key) => {
    const iv = CryptoJS.lib.WordArray.create(16);
    key = fixKey(key);
    key = derivateKey(key, "Asdf@1234", 65536, 256);
    const decrypted = CryptoJS.AES.decrypt(data, key, {
        iv: iv,
        format: CryptoJS.format.OpenSSL,
    });
    return decrypted.toString(CryptoJS.enc.Utf8);
}

const createCheckSumTxnResp = (saltKey, orderNo, amount, respCode, respMessage) => {
    const dataString = orderNo + "," + amount + "," + respCode + "," + respMessage;
    saltKey = base64Encode(saltKey);
    let hashValue = CryptoJS.HmacSHA512(dataString, saltKey);
    hashValue = CryptoJS.enc.Hex.stringify(hashValue);
    hashValue = hashValue.toString().toUpperCase();
    return hashValue;
}