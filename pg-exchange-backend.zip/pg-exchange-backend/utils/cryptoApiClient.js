import axios from 'axios';
// import logger from './logger.js';
import dotenv from "dotenv";
import { Wallet } from '../models/Wallet.model.js';
dotenv.config();
const env = process.env;

const cryptoApiClient = axios.create({
  baseURL: env.CRYPTO_API_BASE_URL,
  timeout: 10000,
});
let ErcUrl = env.ERC_URL;
let TrcUrl = env.TRC_URL;
let BASE_URL = env.BASE_URL;

const cryptoAPI = {
  // generateMnemonic: async (chain = 'EVM') => {
  //   try {
  //     const response = await cryptoApiClient.get(`/mnemonic?chain=${chain}`);
  //     return response.data;
  //   } catch (error) {
  //     logger.error('Mnemonic generation error:', error.message);
  //     throw error;
  //   }
  // },

  // generateWallet: async (chain = 'EVM') => {
  //   let url;


  //   try {
  //     if (chain === 'EVM') {
  //       url = "https://erc.payglobal.co.in/erc20/generateMnemoni";
  //     } else if (chain === 'TRON') {
  //       url = "https://trc.payglobal.co.in/trx/generateMnemonic";
  //     } else {
  //       throw new Error('Unsupported chain type');
  //     }
  //     console.log("inside url = ", url)
  //     const response = await axios.get(url);
  //     // console.log("generate wallet response = ", response)
  //     return response.data.responseResult;
  //   } catch (error) {
  //     throw new error('Wallet generation error:', error);
  //   }
  // },

  // generateAddress: async (chain, mnemonic, count) => {
  //   console.log("mnemonic, count---", mnemonic, count);
  //   let url;
  //   try {
  //     if (chain === 'EVM') {
  //       url = "https://erc.payglobal.co.in/erc20/generateAddress";
  //       console.log("erc url--", url)
  //     } else if (chain === 'TRON') {
  //       url = "https://trc.payglobal.co.in/trx/generateTronWallet";
  //       console.log("trc url--", url)
  //     } else {
  //       throw new Error('Unsupported chain type');
  //     }

  //     const response = await axios.post(url, {},{
  //       params: { mnemonic, count }, 
  //       headers: {
  //         'Content-Type': 'application/json',
  //       }
  //     });

  //     console.log("generate wallet response = ", response?.data);
  //     return response?.data;
  //   } catch (error) {
  //     throw new Error(`Wallet generation error: ${error.message}`); // Fixed error throwing
  //   }
  // }



generateWallet: async (chain = 'EVM') => {
  let url;

  try {
    if (chain === 'EVM') {
      url = "https://erc.payglobal.co.in/erc20/generateMnemonic";
    } else if (chain === 'TRON') {
      url = "https://trc.payglobal.co.in/trx/generateMnemonic";
    } else {
      throw new Error('Unsupported chain type');
    }

    console.log("inside url =", url);

    const response = await axios.get(url);

    return response.data.responseResult;

  } catch (error) {
    throw new Error(`Wallet generation error: ${error.message}`);
  }
},

generateAddress: async (chain, mnemonic, count) => {
  console.log("mnemonic--",mnemonic,", count ---", count);

  let url;

  try {
    if (chain === 'EVM') {
      url = "https://erc.payglobal.co.in/erc20/generateAddress";
      console.log("erc url --", url);
    } else if (chain === 'TRON') {
      url = "https://trc.payglobal.co.in/trx/generateTronWallet";
      console.log("trc url --", url);
    } else {
      throw new Error('Unsupported chain type');
    }

    const response = await axios.get(url, {
      params: { mnemonic, count },
      headers: {
        "Content-Type": "application/json"
      }
    });

    console.log("generate wallet response =", response?.data?.responseResult);
    if(chain === "TRON"){
      return response.data.responseResult.totalwallet[0]
    }
    return response.data.responseResult;

  } catch (error) {
    throw new Error(`Address generation error: ${error.message}`);
  }
},






  // getBalance: async (chain, network, address) => {
  //   try {
  //     const response = await cryptoApiClient.get(
  //       `/balance?chain=${chain}&network=${network}&address=${address}`
  //     );
  //     return response.data;
  //   } catch (error) {
  //     logger.error('Balance fetch error:', error.message);
  //     throw error;
  //   }
  // },

  // getPrice: async (crypto) => {
  //   try {
  //     const response = await cryptoApiClient.get(`/price?crypto=${crypto}`);
  //     return response.data;
  //   } catch (error) {
  //     logger.error('Price fetch error:', error.message);
  //     throw error;
  //   }
  // },

  // deposit: async (payload) => {
  //   try {
  //     const response = await cryptoApiClient.post('/deposit', payload);
  //     return response.data;
  //   } catch (error) {
  //     logger.error('Deposit error:', error.message);
  //     throw error;
  //   }
  // },

  // withdraw: async (payload) => {
  //   try {
  //     const response = await cryptoApiClient.post('/withdraw', payload);
  //     return response.data;
  //   } catch (error) {
  //     logger.error('Withdrawal error:', error.message);
  //     throw error;
  //   }
  // },

  // getTransaction: async (txHash) => {
  //   try {
  //     const response = await cryptoApiClient.get(`/tx?hash=${txHash}`);
  //     return response.data;
  //   } catch (error) {
  //     logger.error('Transaction fetch error:', error.message);
  //     throw error;
  //   }
  // },
};

export default cryptoAPI;