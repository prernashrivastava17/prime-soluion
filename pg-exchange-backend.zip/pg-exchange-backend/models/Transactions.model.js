import mongoose, { Schema } from "mongoose";

const transactionSchema = new Schema({
    userId: {
        type: Schema.Types.ObjectId,
        ref: "User",
        required: true,
    },
    userName: {
        type: String,
    },
    userEmail: {
        type: String
    },
    transactionId: {
        type: String,
        required: true,
    },
    transactionType: {
        type: String,
        enum: ["buy", "withdraw"],
        required: true,
    },
    toAddress: {
        type: String,
        required: true,
    },
    userFromAddress: { //for withdrow assets
        type: String,
    },
    paymentId: {
        type: String,
        required: true,
    },
    amount: {
        type: String,
        required: true,
    },
    chain: {
        type: String,
        // enum: ['EVM', 'TRON'],
        required: true,
    },
    network: {
        type: String,
        required: true,
    },
    fee: {
        type: Number,
        required: true,
    },
    token: {
        type: Number,
        required: true,
    },
    currency: {
        type: String,
        required: true,
    },
    contracktAddress: {
        type: String,
    },
    status: {
        type: String,
        enum: ['pending', 'success', 'failed', 'rejected'],
        default: 'pending',
    },
    walletAddress: {
        type: String,
    },
    txHash: {
        type: String
    },
    paymentMode: {
        type: String,
        enum: ["UPI", "CASH", "BANK"]
    },
    senderBankName: {
        type: String
    },
    senderBankAccountNo: {
        type: String
    },
    senderBankIfscNo: {
        type: String
    },
    senderBankAcountHolderName: {
        type: String
    },
    senderBankTxnId: {
        type: String
    },
    remark: {
        type: String,
        default: "Pending for approval",
    }

}, { timestamps: true });


export const transaction = mongoose.model("Transaction", transactionSchema);