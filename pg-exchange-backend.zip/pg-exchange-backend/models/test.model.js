const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema(
    {
        email: {
            type: String,
            required: true,
            unique: true,
            lowercase: true,
        },
        password: {
            type: String,
            required: true,
        },
        firstName: String,
        lastName: String,
        phone: String,
        kycStatus: {
            type: String,
            enum: ['pending', 'verified', 'rejected'],
            default: 'pending',
        },
        kycDocuments: {
            aadhar: String,
            pan: String,
            address: String,
        },
        wallets: [
            {
                chain: { type: String, enum: ['EVM', 'TRON'] },
                address: String,
                type: { type: String, enum: ['custodial', 'non-custodial'] },
                walletType: { type: String, enum: ['metamask', 'walletconnect', 'platform'] },
            },
        ],
        isActive: { type: Boolean, default: true },
        createdAt: { type: Date, default: Date.now },
    },
    { timestamps: true }
);

userSchema.pre('save', async function (next) {
    if (!this.isModified('password')) return next();
    this.password = await bcrypt.hash(this.password, 10);
    next();
});

userSchema.methods.matchPassword = async function (enteredPassword) {
    return await bcrypt.compare(enteredPassword, this.password);
};

module.exports = mongoose.model('User', userSchema);