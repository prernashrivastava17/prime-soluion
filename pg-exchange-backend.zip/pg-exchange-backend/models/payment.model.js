import mongoose, { Schema } from "mongoose"
import { type } from "os";

const paymentSchema = new Schema({
    userId: {
        type: Schema.Types.ObjectId,
        ref: "User",
        required: true,
    },
    txnId: {
        type: Schema.Types.ObjectId,
        ref: "Transaction",
        required: true
    },
    mid: {
        type: String
    },
    orderNo: {
        type: String,
        required: true,
    },

    amount: {
        type: Number,
        required: true,
    },
    currency: {
        type: String,
        default: 'INR'
    },
    paymentMethod: {
        type: String,
    },
    status: {
        type: String,
        default: 'Transaction Initiated', // enum: ['initiated', 'success', 'failed', 'pending'],
    },
    // txnResponseDate: {
    //     type: String,
    // },
    paymentTransactionId: {
        type: String,
    },
    rrn: {
        type: String
    },
    payment_gateway_responseMessage: {
        type: String
    },
    unknownRspMsg: {
        type: String
    },
    webhookReceivedAt: {
        type: Date,
    }



}, { timestamps: true })

export const Payment = mongoose.model('Payment', paymentSchema);