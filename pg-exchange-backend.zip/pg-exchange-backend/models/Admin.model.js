import mongoose from 'mongoose';

const adminSchema = new mongoose.Schema(
    {
        email: {
            type: String,
            required: true,
            unique: true,
            lowercase: true,
            default: "admin@gmail.com"
        },
        mobileNo: {
            type: String,
        },
        password: {
            type: String,
            required: true,
            default: "admin@123"
        },
        name: {
            type: String,
            default: "Admin"
        },
        balance: {
            type: Number,
            default: 5000
        },
        fees: {
            type: Number,
            default: 1,
        },
        createdAt: { type: Date, default: Date.now },
    },
    { timestamps: true }
);


export const Admin = mongoose.model('Admin', adminSchema);