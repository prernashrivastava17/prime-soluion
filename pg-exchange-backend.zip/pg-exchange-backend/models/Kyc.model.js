import mongoose from "mongoose";

const KYCSchema = new mongoose.Schema({
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },

    // mobileNo: {
    //     type: String,
    //     required: true,
    //     trim: true,
    //     match: [/^[0-9]{10}$/, 'Please enter a valid 10-digit mobile number']
    // },

    FullName: {
        type: String,
        required: [true, 'Full name is required'],
        trim: true,
        maxlength: [100, 'Full name cannot exceed 100 characters']
    },

    FathersName: {
        type: String,
        required: [true, "Father's name is required"],
        trim: true,
        maxlength: [100, "Father's name cannot exceed 100 characters"]
    },

    DoB: {
        type: Date,
        required: [true, 'Date of birth is required'],
        validate: {
            validator: function (value) {
                // Check if date is not in the future
                return value <= new Date();
            },
            message: 'Date of birth cannot be in the future'
        }
    },

    Gender: {
        type: String,
        required: [true, 'Gender is required'],
        enum: {
            values: ['male', 'female', 'other'],
            message: 'Gender must be male, female, or other'
        }
    },

    Email: {
        type: String,
        required: [true, 'Email is required'],
        trim: true,
        lowercase: true,
        match: [/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/, 'Please enter a valid email']
    },

    // Document URLs (from Cloudinary)
    aadharFrontImage: {
        type: String,
        required: [true, 'Aadhar front image is required'],
        trim: true
    },

    aadharBackImage: {
        type: String,
        required: [true, 'Aadhar back image is required'],
        trim: true
    },

    passportSizePhoto: {
        type: String,
        required: [true, 'Passport size photo is required'],
        trim: true
    },

    pancardImage: {
        type: String,
        required: [true, 'PAN card image is required'],
        trim: true
    },

    passbookFrontImage: {
        type: String,
        required: [true, 'Passbook front image is required'],
        trim: true
    },
    kycStatus: {
        type: String,
        enum: ['pending', 'inProgress', 'verified', 'rejected'],
        default: 'pending',
    },



    // Review information (for admin use)
    reviewedBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    },

    reviewedAt: {
        type: Date
    },

    rejectionReason: {
        type: String,
        trim: true,
        maxlength: [500, 'Rejection reason cannot exceed 500 characters']
    },


}, {
    timestamps: true
});

export const Kyc = mongoose.model('KYC', KYCSchema);