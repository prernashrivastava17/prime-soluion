import mongoose from 'mongoose';
const { Schema } = mongoose;

const OTPSchema = new Schema({
    identifier: {
        type: String,
        required: true,
        index: true
    },
    otp: {
        type: String,
        required: true
    },
    type: {
        type: String,
        required: true,
        enum: ['phone_verification', 'forgot_password'],
        default: 'phone_verification'
    },
    purpose: {
        type: String,
        required: true,
        enum: ['signup', 'login', 'password_reset', "transaction", 'Admin-login', 'admin_forget_password'],
        default: 'signup'
    },
    expiresAt: {
        type: Date,
        required: true
    },
    attempts: {
        type: Number,
        default: 0,
        max: 4 // Increased to 4 as per requirement
    },
    isUsed: {
        type: Boolean,
        default: false
    },
    isBlocked: {
        type: Boolean,
        default: false
    }
}, {
    timestamps: true
});

// TTL index for automatic expiry cleanup
OTPSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 });

// Compound index for efficient queries
OTPSchema.index({ identifier: 1, type: 1, purpose: 1 });

export const OTP = mongoose.model("OTP", OTPSchema);