// const priceHistorySchema = new mongoose.Schema({
//     network: {
//         type: String,
//         enum: ['ERC20', 'TRC20'],
//         required: true
//     },
//     price: Number,
//     createdAt: {
//         type: Date,
//         default: Date.now
//     }
// });

// priceHistorySchema.index({ network: 1, createdAt: 1 });

// export default mongoose.model('PriceHistory', priceHistorySchema);


import mongoose from 'mongoose';

const priceHistorySchema = new mongoose.Schema({
    chain: {
        type: String,
        enum: ['EVM', 'TRON'],
        required: true
    },
    price: {
        type: Number,
        required: true
    },
    createdAt: {
        type: Date,
        default: Date.now
    }
});

priceHistorySchema.index({ network: 1, createdAt: 1 });

export default mongoose.model('PriceHistory', priceHistorySchema);
