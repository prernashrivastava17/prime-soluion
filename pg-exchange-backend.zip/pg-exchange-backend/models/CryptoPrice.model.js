import mongoose from 'mongoose';

const cryptoPriceSchema = new mongoose.Schema({
    currentUsdtEVMPrice: {
        type: Number,
        default: 0
    },
    currentUsdtTRONPrice: {
        type: Number,
        default: 0
    }
});

export default mongoose.model('CryptoPrice', cryptoPriceSchema);
