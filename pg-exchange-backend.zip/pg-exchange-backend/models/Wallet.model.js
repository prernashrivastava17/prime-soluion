import mongoose from 'mongoose';

const walletSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      unique: true
    },

    wallets: [
      {
        chain: {
          type: String,
          enum: ['EVM', 'TRON', 'PGL'],
          required: true
        },
        address: {
          type: String,
          required: true
        },
        privateKey: {
          type: String,
          required: true
        },
        balance: {
          type: Number,
          default: 0
        },
        walletType: {
          type: String,
          enum: ['metamask', 'platform'],
          default: 'platform',
        },
        isActive: {
          type: Boolean,
          default: true
        },
        createdAt: {
          type: Date,
          default: Date.now
        }
      }
    ],
    createdAt: {
      type: Date,
      default: Date.now
    },
    updatedAt: {
      type: Date,
      default: Date.now
    }
  },
  {
    timestamps: true
  }
);

// walletSchema.pre('save', function (next) {
//   const wallets = this.wallets;
//   const seen = new Set();

//   for (const wallet of wallets) {
//     const key = `${wallet.chain}_${wallet.walletType}`;

//     console.log("key--", key)
//     console.log("seen--", seen)

//     if (seen.has(key)) {
//       return next(new Error("Wallet Allready Exists. A user can have only one wallet per chain and type."));
//     }
//     seen.add(key);
//   }
//   next();
// });

walletSchema.index({ userId: 1 });
walletSchema.index({ "wallets.chain": 1 });
walletSchema.index({ "wallets.walletType": 1 });
export const Wallet = mongoose.model('Wallet', walletSchema);