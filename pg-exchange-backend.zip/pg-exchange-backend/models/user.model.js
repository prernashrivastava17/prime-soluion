import mongoose from 'mongoose';

const { Schema } = mongoose;

const userSchema = new Schema({
    name: {
        type: String,
        required: true,
        trim: true
    },
    email: {
        type: String,
        required: true,
        unique: true,
        lowercase: true,
        trim: true
    },

    password: {
        type: String,
        required: true
    },
    isVerified: {
        type: Boolean,
        default: false
    },
    kycStatus: {
        type: String,
        enum: ['pending', 'inProgress', 'verified', 'rejected'],
        default: 'pending',
    },
    isActive: { type: Boolean, default: true },
    kycDocuments: {
        aadhar: String,
        pan: String,
        address: String,
    },
    wallets: [
        {
            chain: { type: String, enum: ['EVM', 'TRON', 'PGL'] },
            address: String,
            createdAt: { type: Date, default: Date.now },
        },
    ],
    createdAt: { type: Date, default: Date.now },
}, {
    timestamps: true
});

export const User = mongoose.model("User", userSchema);

